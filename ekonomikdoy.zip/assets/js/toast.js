/* toast.js — MV3 uyumlu, Shadow DOM'lu toast helper
 *
 * Özellikler:
 * - SVG ikonlar (currentColor ile tip rengine uyar)
 * - Shadow DOM: Sayfa CSS’inden etkilenmez
 * - Konumlar: top-right | top-left | bottom-right | bottom-left
 * - Kuyruk: Her konum için ayrı kuyruk + maxVisible kontrolü
 * - Süre çubuğu (progress) ve otomatik kapanma
 * - Hover/focus'ta süreyi durdur, ayrılınca kaldığı yerden devam
 * - API: Toast.show(text, options), Toast.success/info/warning/error,
 *        Toast.setDefaults(partial), Toast.dismissAll()
 *
 * Örnek:
 *   Toast.show("Merhaba", { title: "Selam", type: "info", duration: 4000 });
 *   Toast.success("Kayıt tamam", { title: "Başarılı" });
 */

(function () {
  'use strict';

  const Toast = (() => {
    const DEFAULTS = {
      position: "top-right", // top-right | top-left | bottom-right | bottom-left
      duration: 3500, // ms; 0/null => otomatik kapanma yok
      maxVisible: 4, // ekranda aynı anda en fazla toast (konum başına)
      dismissible: true, // kapatma butonu
      icon: true, // true => varsayılan SVG; SVGElement verirsen onu kullanır; false => ikon yok
      type: "info", // info | success | warning | error
      pauseOnHover: true, // hover/focus'ta süreyi durdur
      progress: true // süre çubuğu göster
    };

    let root, shadow, containers, queues;

    // ---- SVG helpers ----
    const NS = "http://www.w3.org/2000/svg";
    const svg = (name, attrs = {}) => {
      const el = document.createElementNS(NS, name);
      for (const k in attrs) el.setAttribute(k, attrs[k]);
      return el;
    };

    function makeIcon(type) {
      const s = svg("svg", {
        viewBox: "0 0 20 20",
        width: "18",
        height: "18",
        "aria-hidden": "true"
      });
      s.style.display = "block";
      s.style.flexShrink = "0";
      const common = {
        fill: "none",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
      };
      if (type === "success") {
        s.append(svg("circle", {
            ...common,
            cx: "10",
            cy: "10",
            r: "8"
          }),
          svg("path", {
            ...common,
            d: "M6 10.5l2.5 2.5L14 8.5"
          }));
      } else if (type === "warning") {
        s.append(svg("path", {
            ...common,
            d: "M10 3l8 14H2l8-14z"
          }),
          svg("line", {
            ...common,
            x1: "10",
            y1: "7.5",
            x2: "10",
            y2: "11.5"
          }),
          svg("circle", {
            ...common,
            cx: "10",
            cy: "14.5",
            r: "1"
          }));
      } else if (type === "error") {
        s.append(svg("circle", {
            ...common,
            cx: "10",
            cy: "10",
            r: "8"
          }),
          svg("path", {
            ...common,
            d: "M7 7l6 6M13 7l-6 6"
          }));
      } else {
        s.append(svg("circle", {
            ...common,
            cx: "10",
            cy: "10",
            r: "8"
          }),
          svg("circle", {
            ...common,
            cx: "10",
            cy: "6.5",
            r: "0.7"
          }),
          svg("line", {
            ...common,
            x1: "10",
            y1: "9",
            x2: "10",
            y2: "13.5"
          }));
      }
      return s;
    }

    // ---- DOM root + stil ----
    function ensureRoot() {
      if (root) return;
      root = document.createElement("div");
      root.id = "ext-toast-root";
      root.style.all = "initial";
      root.style.position = "fixed";
      root.style.zIndex = "2147483647";
      root.style.pointerEvents = "none";
      document.documentElement.appendChild(root);
      shadow = root.attachShadow({
        mode: "open"
      });

      const style = document.createElement("style");
      style.textContent = `
        :host { all: initial; }
        .wrap { position: fixed; inset: 0; pointer-events:none; }
        .stack { position: fixed; display: flex; flex-direction: column; gap: 10px; pointer-events:none; }
        .pos-top-right    { top: 16px; right: 16px; align-items: flex-end; }
        .pos-top-left     { top: 16px; left: 16px;  align-items: flex-start; }
        .pos-bottom-right { bottom: 16px; right: 16px; align-items: flex-end; }
        .pos-bottom-left  { bottom: 16px; left: 16px;  align-items: flex-start; }

        .toast {
          pointer-events: auto;
          display: grid;
          grid-template-columns: auto 1fr auto;
          gap: 8px;
          min-width: 240px; max-width: 380px;
          background: #111827F2;      /* koyu arka plan */
          color: #F9FAFB;
          border: 1px solid #374151;
          border-radius: 10px;
          padding: 10px 12px;
          box-shadow: 0 10px 25px rgba(0,0,0,0.35);
          font: 14px/1.35 -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
          transform: translateY(-6px);
          opacity: 0;
          animation: toast-in 150ms ease-out forwards;
        }
        .toast[data-leaving="true"] { animation: toast-out 180ms ease-in forwards; }
        @keyframes toast-in  { to { transform: translateY(0);   opacity: 1; } }
        @keyframes toast-out { to { transform: translateY(-6px); opacity: 0; } }

        .icon  { align-self: start; display:flex; align-items:center; justify-content:center; margin-top: 2px; }
        .title { font-weight: 600; margin: 0; }
        .msg   { margin: 0; opacity: 0.95; }
        .body  { display: grid; gap: 2px; }
        .close {
          background: none; border: 0; color: inherit; cursor: pointer;
          font-size: 16px; opacity: 0.7; padding: 0 2px; line-height: 1;
        }
        .close:hover { opacity: 1; }

        .bar { grid-column: 1 / -1; height: 2px; border-radius: 2px; overflow: hidden; background: #374151; }
        .bar > i { display: block; height: 100%; background: currentColor; opacity: 0.8; transform-origin: left center; animation: bar linear forwards; }
        @keyframes bar { from { transform: scaleX(1) } to { transform: scaleX(0) } }

        /* tip renkleri (ikon + progress currentColor kullandığı için uyumlu) */
        .toast[data-type="success"] { color: #86efac; }
        .toast[data-type="warning"] { color: #fde68a; }
        .toast[data-type="error"]   { color: #fca5a5; }
        .toast[data-type="info"]    { color: #bfdbfe; }

        .sr { position: absolute; width: 1px; height: 1px; padding:0; margin:-1px; overflow:hidden; clip:rect(0,0,0,0); border:0; }
      `;
      shadow.appendChild(style);

      const wrap = document.createElement("div");
      wrap.className = "wrap";
      shadow.appendChild(wrap);

      containers = {
        "top-right": makeStack("pos-top-right"),
        "top-left": makeStack("pos-top-left"),
        "bottom-right": makeStack("pos-bottom-right"),
        "bottom-left": makeStack("pos-bottom-left"),
      };
      Object.values(containers).forEach(c => wrap.appendChild(c));

      // konum başına ayrı kuyruk
      queues = {
        "top-right": [],
        "top-left": [],
        "bottom-right": [],
        "bottom-left": [],
      };
    }

    function makeStack(cls) {
      const el = document.createElement("div");
      el.className = `stack ${cls}`;
      return el;
    }

    function normalizePos(pos) {
      return (pos && containers && containers[pos]) ? pos : DEFAULTS.position;
    }

    function getContainer(pos) {
      ensureRoot();
      const key = normalizePos(pos);
      return {
        el: containers[key],
        key
      };
    }

    function visibleCount(containerEl) {
      return containerEl.querySelectorAll(".toast:not([data-leaving='true'])").length;
    }

    function enqueue(key, job) {
      queues[key].push(job);
    }

    function tryDequeue(key) {
      const containerEl = containers[key];
      if (!queues[key].length) return;
      const max = DEFAULTS.maxVisible; // en güncel default
      if (visibleCount(containerEl) >= max) return;

      const jobIndex = queues[key].findIndex(Boolean);
      if (jobIndex === -1) return;
      const job = queues[key].splice(jobIndex, 1)[0];
      renderToast(job.text, job.opts, containerEl, key);
    }

    function jobDefaults() {
      return DEFAULTS;
    }

    // ---- render ----
    function renderToast(text, opts, containerEl, queueKey) {
      const {
        type,
        title,
        duration,
        dismissible,
        icon,
        pauseOnHover,
        progress
      } = opts;

      const toast = document.createElement("div");
      toast.className = "toast";
      toast.dataset.type = type;
      toast.setAttribute("role", "status");
      toast.setAttribute("aria-live", "polite");

      // ikon
      const iconWrap = document.createElement("div");
      iconWrap.className = "icon";
      if (icon === true) {
        iconWrap.appendChild(makeIcon(type));
      } else if (icon && icon.nodeType === 1 && icon.namespaceURI === NS) {
        iconWrap.appendChild(icon.cloneNode(true));
      } else {
        iconWrap.style.display = "none";
      }
      toast.appendChild(iconWrap);

      // metin gövdesi
      const body = document.createElement("div");
      body.className = "body";
      if (title) {
        const h = document.createElement("p");
        h.className = "title";
        h.textContent = title;
        body.appendChild(h);
      }
      const p = document.createElement("p");
      p.className = "msg";
      p.textContent = text;
      body.appendChild(p);
      toast.appendChild(body);

      // kapatma butonu
      const close = document.createElement("button");
      close.className = "close";
      close.setAttribute("aria-label", "Kapat");
      close.textContent = "×";
      close.style.display = dismissible ? "block" : "none";
      close.addEventListener("click", () => leave());
      toast.appendChild(close);

      // süre/progress
      let autoTimer = null;
      let startAt = 0;
      let remaining = 0;
      let fill = null;

      if (progress && duration && duration > 0) {
        const bar = document.createElement("div");
        bar.className = "bar";
        fill = document.createElement("i");
        fill.style.animationDuration = `${duration}ms`;
        bar.appendChild(fill);
        body.appendChild(bar);
      }

      if (duration && duration > 0) {
        remaining = duration;
        startTimer();
      }

      function startTimer() {
        if (!(duration && duration > 0)) return;
        startAt = performance.now();
        if (fill) fill.style.animationPlayState = "running";
        autoTimer = setTimeout(leave, remaining);
      }

      function pauseTimer() {
        if (!autoTimer) return; // zaten duruyor
        clearTimeout(autoTimer);
        autoTimer = null;
        const now = performance.now();
        remaining = Math.max(0, remaining - (now - startAt));
        if (fill) fill.style.animationPlayState = "paused";
      }

      function resumeTimer() {
        if (!(duration && duration > 0)) return;
        if (toast.dataset.leaving === "true") return;
        if (remaining <= 0) {
          leave();
          return;
        }
        startTimer();
      }

      // kapatma akışı
      function leave() {
        if (toast.dataset.leaving === "true") return;
        if (autoTimer) clearTimeout(autoTimer);
        autoTimer = null;
        toast.dataset.leaving = "true";
        setTimeout(() => {
          toast.remove();
          tryDequeue(queueKey);
        }, 200);
      }

      if (pauseOnHover) {
        toast.addEventListener("mouseenter", pauseTimer);
        toast.addEventListener("mouseleave", resumeTimer);
        // klavye odak için de durdur/başlat
        toast.addEventListener("focusin", pauseTimer);
        toast.addEventListener("focusout", resumeTimer);
      }

      containerEl.appendChild(toast);

      return {
        close: leave,
        el: toast,
        update: (newText) => {
          p.textContent = newText;
        }
      };
    }

    // ---- API ----
    function show(text, options = {}) {
      ensureRoot();
      const opts = {
        ...jobDefaults(),
        ...options
      };
      const {
        el: containerEl,
        key
      } = getContainer(opts.position);
      if (visibleCount(containerEl) >= opts.maxVisible) {
        enqueue(key, {
          text,
          opts
        });
        return {
          close: () => {},
          el: null,
          update: () => {}
        };
      }
      return renderToast(text, opts, containerEl, key);
    }

    function typed(type) {
      return (text, options = {}) => show(text, {
        ...options,
        type
      });
    }

    return {
      show,
      success: typed("success"),
      info: typed("info"),
      warning: typed("warning"),
      error: typed("error"),
      setDefaults: (next) => Object.assign(DEFAULTS, next),
      dismissAll: () => {
        if (!shadow) return;
        shadow.querySelectorAll(".toast").forEach(t => t.remove());
        if (queues) {
          Object.keys(queues).forEach(k => queues[k] = []);
        }
      }
    };
  })();

  // Global'e yayıyoruz (MAIN veya content world fark etmeksizin)
  if (typeof window !== "undefined") {
    window.Toast = window.Toast || Toast;
  }
})();