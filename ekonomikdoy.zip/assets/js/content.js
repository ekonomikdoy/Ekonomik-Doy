function applyMergedLocalStoragePreset(preset) {
  try {
    const pairs = (preset && typeof preset.kv === 'object') ? preset.kv : {};

    for (const [k, v] of Object.entries(pairs)) {
      localStorage.setItem(k, typeof v === 'string' ? v : String(v));
    }

    return true;
  } catch (e) {
    console.warn('applyMergedLocalStoragePreset failed:', e);
    return false;
  }
}

async function applyPendingLocalStorageMerged() {
  try {
    const origin = location.origin.replace(/\/+$/, '');

    const res = await chrome.runtime.sendMessage({
      action: 'consumePresetLocalStorageMerged',
      origin
    });

    if (!res?.ok || !res?.preset) return false;

    const createdAt = Number(res.preset?.createdAt || 0);
    if (createdAt && (Date.now() - createdAt) > 60 * 1000) {
      return false;
    }

    return applyMergedLocalStoragePreset(res.preset);
  } catch (e) {
    console.warn('preset localStorage merged apply failed:', e);
    return false;
  }
}

(async function () {
  const manifest = chrome.runtime.getManifest();
  const extensionName = manifest.name;

  await applyPendingLocalStorageMerged();

  console.log('Eklenti: ', extensionName);

  if (extensionName === 'Ekonomik Doy') {
    window.addEventListener('message', (event) => {
      if (event.source !== window) return;

      const data = event.data;
      if (!data) return;

      if (data.type === 'EKO_BG_REQ') {
        const {
          reqId,
          action,
          payload
        } = data;
        if (!reqId || !action) return;

        chrome.runtime.sendMessage({
          action,
          ...(payload || {})
        }, (res) => {
          const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;

          window.postMessage({
              type: 'EKO_BG_RES',
              reqId,
              res,
              err
            },
            event.origin || location.origin
          );
        });

        return;
      }

      if (data.source === 'EKO_YS' && data.action === 'ysProxyRequest') {
        const {
          requestId,
          url,
          method,
          headers,
          body
        } = data;
        if (!requestId || !url) return;

        console.log('🔵 Content: YS Proxy isteği alındı, background\'a iletiliyor', {
          requestId,
          url,
          method
        });

        sendToBackgroundWithRetry({
            action: 'ysProxyRequest',
            url,
            method,
            headers,
            body
          },
          requestId
        );

        return;
      }
    });

    function injectScript(file) {
      return new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.setAttribute('type', 'text/javascript');
        script.setAttribute('src', chrome.runtime.getURL(`assets/js/${file}`));

        script.onload = () => {
          console.log(`✅ ${file} yüklendi`);
          script.remove();
          resolve();
        };
        script.onerror = (e) => {
          console.error(`❌ ${file} yüklenemedi:`, e);
          reject(new Error(`Script yüklenemedi: ${file}`));
        };
        (document.head || document.documentElement).appendChild(script);
      });
    }

    function sendToBackgroundWithRetry(message, requestId, retryCount = 0) {
      const MAX_RETRIES = 2;
      const RETRY_DELAY = 500;

      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          console.warn(`⚠️ Content: Background mesaj hatası (deneme ${retryCount + 1}/${MAX_RETRIES + 1}):`, chrome.runtime.lastError.message);

          if (retryCount < MAX_RETRIES) {
            setTimeout(() => {
              console.log(`🔄 Content: Retry #${retryCount + 1} - ${message.url}`);
              sendToBackgroundWithRetry(message, requestId, retryCount + 1);
            }, RETRY_DELAY);
            return;
          }

          response = {
            success: false,
            error: chrome.runtime.lastError.message,
            headers: {}
          };
        }

        if (!response) {
          if (retryCount < MAX_RETRIES) {
            setTimeout(() => {
              console.log(`🔄 Content: Retry #${retryCount + 1} (boş yanıt) - ${message.url}`);
              sendToBackgroundWithRetry(message, requestId, retryCount + 1);
            }, RETRY_DELAY);
            return;
          }
          response = {
            success: false,
            error: 'Background scriptinden yanıt alınamadı',
            headers: {}
          };
        }

        console.log('✅ Content: Yanıt alındı, web sayfasına iletiliyor', {
          requestId,
          success: response.success
        });

        window.postMessage({
          source: 'EKO_YS_RESPONSE',
          action: 'proxyResponse',
          requestId: requestId,
          response: response
        }, '*');
      });
    }

    const url = location.hostname;

    const scripts = {
      'yemeksepeti.com': ['y_graphql.js', 'logger.js', 'crypto-js.min.js', 'generate-rsig.js', 'toast.js', 'y_cart.js', 'y_script.js'],
      'migros.com.tr': ['m_script.js'],
      'uber.com': ['logger.js', 'u_script.js']
    };

    const matched = Object.keys(scripts).find(domain => url.includes(domain));

    if (matched) {
      const files = scripts[matched];

      for (const file of files) {
        await injectScript(file);
      }
    }
  }
})();