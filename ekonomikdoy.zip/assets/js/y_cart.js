(function () {
  'use strict';

  const SAVED_KEY = 'saved_carts';
  const CART_KEY = 'cart';

  /*** Utils ***/
  const j = {
    parse(v, fb = null) {
      if (!v) return fb;
      try {
        return JSON.parse(v);
      } catch (_) {
        try {
          return JSON.parse(JSON.parse(v));
        } catch (__) {
          return fb;
        }
      }
    },
    str(o) {
      try {
        return JSON.stringify(o);
      } catch {
        return '';
      }
    },
    clone(o) {
      return JSON.parse(JSON.stringify(o || null));
    }
  };

  function bg(action, payload = {}) {
    return new Promise((resolve, reject) => {
      const reqId = Math.random().toString(36).slice(2);
      const onMsg = (ev) => {
        if (ev.source !== window) return;
        const data = ev.data;
        if (!data || data.type !== 'EKO_BG_RES' || data.reqId !== reqId) return;
        window.removeEventListener('message', onMsg);
        if (data.err) return reject(new Error(data.err));
        const res = data.res || {};
        if ('ok' in res && !res.ok) return reject(new Error(res.error || 'Background error'));
        resolve(res);
      };
      window.addEventListener('message', onMsg);
      window.postMessage({
        type: 'EKO_BG_REQ',
        reqId,
        action,
        payload
      }, location.origin);
    });
  }

  function getCurrentCart() {
    const c = j.parse(localStorage.getItem(CART_KEY));
    return c && typeof c === 'object' ? c : null;
  }

  function getVendorCode(cart) {
    return cart?.vendor_cart?. [0]?.vendor_code || null;
  }

  function getVendorName(cart) {
    return cart?.vendor_cart?. [0]?.vendorInfo?.name || getVendorCode(cart) || 'Bilinmeyen';
  }

  const nowMs = () => Date.now();

  function cartsAnyToDict(carts) {
    if (!carts) return {};
    if (Array.isArray(carts)) {
      const out = {};
      carts.forEach(e => {
        if (e && e.vendor_code) out[e.vendor_code] = {
          cart: e.cart,
          lastInactive: e.lastInactive || 0
        };
      });
      return out;
    }
    if (typeof carts === 'object') {
      const out = {};
      Object.entries(carts).forEach(([code, val]) => {
        if (!code) return;
        if (val && typeof val === 'object' && 'cart' in val) {
          out[code] = {
            cart: val.cart,
            lastInactive: val.lastInactive || 0
          };
        } else {
          out[code] = {
            cart: val,
            lastInactive: 0
          };
        }
      });
      return out;
    }
    return {};
  }

  function getSavedMap() {
    const parsed = j.parse(localStorage.getItem(SAVED_KEY), {});
    if (parsed && typeof parsed === 'object') return cartsAnyToDict(parsed);
    return {};
  }

  function setSavedMap(map) {
    const obj = map && typeof map === 'object' ? map : {};
    localStorage.setItem(SAVED_KEY, j.str(obj));
  }

  function sanitizeVoucherFieldsDeep(input) {
    if (Array.isArray(input)) {
      return input.map(sanitizeVoucherFieldsDeep);
    }

    if (!input || typeof input !== 'object') {
      return input;
    }

    const out = {};
    for (const [key, value] of Object.entries(input)) {
      if (key === 'voucher') {
        out[key] = [];
        continue;
      }

      if (key === 'voucher_total') {
        out[key] = 0;
        continue;
      }

      out[key] = sanitizeVoucherFieldsDeep(value);
    }

    return out;
  }

  function deleteSavedCart(vendorCode) {
    const map = getSavedMap();
    if (!map[vendorCode]) return false;
    delete map[vendorCode];
    setSavedMap(map);
    notify('Kayıt silindi.');
    return true;
  }

  function getUnifiedMap() {
    const saved = getSavedMap();
    const cart = getCurrentCart();
    const code = getVendorCode(cart);
    if (cart && code && !saved[code]) {
      return {
        ...saved,
        [code]: {
          cart,
          lastInactive: nowMs()
        }
      };
    }
    return saved;
  }

  async function getListsArr() {
    const res = await bg('cartsGet');
    return Array.isArray(res?.data) ? res.data : [];
  }

  async function setListsArr(arr) {
    await bg('cartsSet', {
      arr: Array.isArray(arr) ? arr : []
    });
  }

  async function getActiveListId() {
    const res = await bg('cartSelectGet');
    return (res && typeof res.data === 'string') ? res.data : '';
  }

  async function setActiveListId(id) {
    await bg('cartSelectSet', {
      id
    });
  }

  async function ensureList(name) {
    if (!name) return null;
    const lists = await getListsArr();
    const found = lists.find(l => l.name === name);
    if (found) return found.id;

    const nowIso = new Date().toISOString();
    const rec = {
      id: ('cart:' + Date.now()),
      name,
      carts: {},
      created_at: nowIso,
      updated_at: nowIso
    };
    lists.unshift(rec);
    await setListsArr(lists);
    return rec.id;
  }

  async function saveUnifiedToActiveList() {
    let listId = await getActiveListId();
    if (!listId) {
      const name = prompt('Liste adı?') || '';
      if (!name) return notify('Liste adı gerekli.');
      listId = await ensureList(name);
      await setActiveListId(listId);
    }
    const lists = await getListsArr();
    const idx = lists.findIndex(l => l.id === listId);
    if (idx === -1) return notify('Liste bulunamadı.');

    const unified = getUnifiedMap();
    const cleanedUnified = sanitizeVoucherFieldsDeep(unified);

    const next = j.clone(lists);
    next[idx].carts = cleanedUnified;
    next[idx].updated_at = new Date().toISOString();
    await setListsArr(next);
    notify(`Sepet listeye çekildi → ${next[idx].name}`);
    return true;
  }

  async function loadListToSaved(listId, {
    mode = 'replace',
    reloadOnSuccess = false
  } = {}) {
    const lists = await getListsArr();
    const idx = lists.findIndex(l => l.id === listId);
    if (idx === -1) return notify('Liste bulunamadı.');
    const list = lists[idx];
    const dict = cartsAnyToDict(list.carts);

    if (mode === 'replace') {
      setSavedMap(dict);
      notify(`Sepet, ${list.name} ile değiştirildi.`);
      if (reloadOnSuccess) location.reload();
      return true;
    }

    const saved = getSavedMap();
    const next = {
      ...saved
    };
    for (const [code, val] of Object.entries(dict)) {
      if (!next[code]) next[code] = {
        cart: val.cart,
        lastInactive: val.lastInactive || 0
      };
    }
    setSavedMap(next);
    notify(`Sepet, ${list.name} ile birleştirildi.`);
    if (reloadOnSuccess) location.reload();
    return true;
  }

  async function renameList(listId, newName) {
    const lists = await getListsArr();
    const idx = lists.findIndex(l => l.id === listId);
    if (idx === -1) return notify('Liste bulunamadı.');
    const name = (newName || '').trim();
    if (!name) return notify('Liste adı gerekli.');

    if (lists.some(l => l.name === name && l.id !== listId)) {
      return notify('Bu isim zaten kullanılıyor.');
    }

    const next = j.clone(lists);
    next[idx] = {
      ...next[idx],
      name,
      updated_at: new Date().toISOString()
    };
    await setListsArr(next);
    notify('Liste adı güncellendi.');
    return true;
  }

  async function deleteList(listId) {
    const lists = await getListsArr();
    const idx = lists.findIndex(l => l.id === listId);
    if (idx === -1) return false;
    const next = j.clone(lists);
    next.splice(idx, 1);
    await setListsArr(next);
    if ((await getActiveListId()) === listId) await setActiveListId('');
    notify('Liste silindi.');
    return true;
  }

  async function updateListFromCurrent(listId, vendorCode) {
    const lists = await getListsArr();
    const idx = lists.findIndex(l => l.id === listId);
    if (idx === -1) return notify('Liste bulunamadı.');
    const activeCart = getCurrentCart();
    const activeCode = getVendorCode(activeCart);

    let sourceCart = null;
    let sourceLastInactive = nowMs();

    if (activeCart && activeCode === vendorCode) {
      sourceCart = activeCart;
      sourceLastInactive = nowMs();
    } else {
      const saved = getSavedMap();
      const hit = saved[vendorCode];
      if (hit) {
        sourceCart = hit.cart || hit;
        sourceLastInactive = hit.lastInactive || 0;
      }
    }

    if (!sourceCart) {
      return notify('Bu restoran aktif sepette ya da kayıtlarda bulunamadı.');
    }

    const cleanedSourceCart = sanitizeVoucherFieldsDeep(sourceCart);

    const list = j.clone(lists[idx]);
    list.carts = cartsAnyToDict(list.carts);
    list.carts[vendorCode] = {
      cart: cleanedSourceCart,
      lastInactive: sourceLastInactive
    };
    list.updated_at = new Date().toISOString();

    const next = j.clone(lists);
    next[idx] = list;
    await setListsArr(next);
    notify('Liste kaydı aktif sepete göre güncellendi.');
    return true;
  }

  async function deleteListEntry(listId, vendorCode) {
    const lists = await getListsArr();
    const idx = lists.findIndex(l => l.id === listId);
    if (idx === -1) return notify('Liste bulunamadı.');
    const list = j.clone(lists[idx]);
    list.carts = cartsAnyToDict(list.carts);
    if (!list.carts[vendorCode]) return notify('Bu restoran listede yok.');
    delete list.carts[vendorCode];
    list.updated_at = new Date().toISOString();

    const next = j.clone(lists);
    next[idx] = list;
    await setListsArr(next);
    notify('Liste kaydı silindi.');
    return true;
  }

  /*** UI helpers ***/
  function notify(message, {
    timeout = 2200,
    maxVisible = 3,
    size = 'lg'
  } = {}) {
    try {
      const panel = document.getElementById('ys-saved-manager');
      if (panel) {
        const SIZES = {
          sm: {
            fs: 13,
            pad: '8px 12px',
            radius: 8,
            maxW: 420
          },
          md: {
            fs: 14,
            pad: '10px 14px',
            radius: 9,
            maxW: 460
          },
          lg: {
            fs: 16,
            pad: '12px 16px',
            radius: 10,
            maxW: 520
          },
          xl: {
            fs: 18,
            pad: '14px 18px',
            radius: 12,
            maxW: 560
          }
        };
        const SZ = SIZES[size] || SIZES.lg;

        let overlay = document.getElementById('ys-toast-overlay');
        const ensurePos = () => {
          const r = panel.getBoundingClientRect();
          overlay.style.left = r.left + 'px';
          overlay.style.width = r.width + 'px';
          overlay.style.bottom = (window.innerHeight - r.top + 8) + 'px';
          overlay.style.top = '';
        };

        if (!overlay) {
          overlay = document.createElement('div');
          overlay.id = 'ys-toast-overlay';
          Object.assign(overlay.style, {
            position: 'fixed',
            zIndex: '1000001',
            pointerEvents: 'none',
            display: 'flex',
            flexDirection: 'column',
            gap: '8px',
            alignItems: 'center'
          });
          document.body.appendChild(overlay);

          overlay.__reposition = ensurePos;
          overlay.__onScroll = () => ensurePos();
          window.addEventListener('scroll', overlay.__onScroll, {
            passive: true
          });
          window.addEventListener('resize', overlay.__onScroll);
          ensurePos();
        } else if (overlay.__reposition) {
          overlay.__reposition();
        }

        while (overlay.children.length >= maxVisible) {
          overlay.firstElementChild?.remove();
        }

        const item = document.createElement('div');
        Object.assign(item.style, {
          background: '#111',
          color: '#fff',
          borderRadius: SZ.radius + 'px',
          padding: SZ.pad,
          boxShadow: '0 8px 20px rgba(0,0,0,.22)',
          fontSize: SZ.fs + 'px',
          fontWeight: '500',
          lineHeight: '1.35',
          letterSpacing: '0.2px',
          pointerEvents: 'auto',
          maxWidth: `min(${SZ.maxW}px, 92%)`,
          textAlign: 'center'
        });
        item.textContent = message;
        overlay.appendChild(item);

        item.animate(
          [{
            opacity: 0,
            transform: 'translateY(-6px)'
          }, {
            opacity: 1,
            transform: 'translateY(0)'
          }], {
            duration: 180,
            easing: 'ease-out'
          }
        );

        setTimeout(() => {
          const anim = item.animate([{
            opacity: 1
          }, {
            opacity: 0
          }], {
            duration: 160
          });
          anim.onfinish = () => {
            item.remove();
            if (!overlay.children.length) {
              window.removeEventListener('scroll', overlay.__onScroll);
              window.removeEventListener('resize', overlay.__onScroll);
              overlay.remove();
            }
          };
        }, timeout);

        return;
      }

      const container = document.querySelector('.bds-c-toast-container');
      if (container) {
        const item = document.createElement('div');
        item.className = 'bds-c-toast bg-white br-container bc-neutral-border pa-sm mb-sm';
        item.textContent = message;
        container.appendChild(item);
        setTimeout(() => item.remove(), timeout);
        return;
      }
    } catch {}

    alert(message);
  }


  function injectSaveButtonOnce() {
    const drawerBody = document.querySelector(
      '.drawer__body.cart-listing-sidebar__body .drawer__content'
    );
    if (!drawerBody) return;

    const header = drawerBody.querySelector(
      '.box-flex.ai-center.jc-space-between.fd-row'
    );
    if (!header || header.dataset.ysEnhanced === '1') return;

    header.dataset.ysEnhanced = '1';

    const wrap = document.createElement('div');
    wrap.className = 'bds-c-btn-circular-cursor';

    const manageBtn = document.createElement('button');
    manageBtn.type = 'button';
    manageBtn.id = 'ys-manage-carts-btn';
    manageBtn.className = 'bds-c-btn bds-c-btn-secondary bds-c-btn--size-small';
    manageBtn.style.marginInlineStart = '8px';
    manageBtn.textContent = 'Listeleri yönet';
    manageBtn.addEventListener('click', openManager);

    wrap.style.display = 'flex';
    wrap.style.gap = '8px';
    wrap.style.flexShrink = '0';
    wrap.appendChild(manageBtn);
    header.appendChild(wrap);
  }

  async function openManager() {
    const old = document.getElementById('ys-saved-manager');
    if (old) old.remove();

    const panel = document.createElement('div');
    panel.id = 'ys-saved-manager';
    Object.assign(panel.style, {
      position: 'fixed',
      right: '16px',
      bottom: '16px',
      zIndex: '999999',
      background: 'white',
      padding: '12px',
      width: 'min(480px, calc(100vw - 32px))',
      maxHeight: '78vh',
      overflowX: 'hidden',
      overflowY: 'auto',
      border: '1px solid #ddd',
      borderRadius: '12px',
      boxShadow: '0 8px 24px rgba(0,0,0,.12)',
      fontFamily: 'Inter, system-ui, sans-serif',
      fontSize: '14px',
    });

    // HEADER
    const headerRow = document.createElement('div');
    Object.assign(headerRow.style, {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: '8px'
    });
    const title = document.createElement('div');
    title.textContent = 'Kaydedilmiş Sepetler';
    Object.assign(title.style, {
      fontWeight: '600'
    });
    const closeBtn = document.createElement('button');
    closeBtn.setAttribute('aria-label', 'Kapat');
    closeBtn.textContent = '×';
    Object.assign(closeBtn.style, {
      fontSize: '20px',
      lineHeight: '20px',
      width: '28px',
      height: '28px',
      borderRadius: '8px',
      border: '1px solid #eee',
      background: 'white',
      cursor: 'pointer'
    });
    closeBtn.onclick = () => panel.remove();
    headerRow.appendChild(title);
    headerRow.appendChild(closeBtn);

    // LIST SECTION
    const listWrap = document.createElement('div');
    listWrap.style.margin = '6px 0 12px';

    const lists = await getListsArr();
    const activeId = await getActiveListId();

    const rowTop = document.createElement('div');
    Object.assign(rowTop.style, {
      display: 'grid',
      gridTemplateColumns: '1fr auto',
      gap: '8px',
      alignItems: 'center'
    });

    const sel = document.createElement('select');
    sel.style.padding = '6px';
    sel.style.width = '100%';
    sel.style.maxWidth = '100%';
    sel.style.boxSizing = 'border-box';

    function rebuildSelect(allLists, active) {
      sel.innerHTML = '';
      const opt0 = document.createElement('option');
      opt0.value = '';
      opt0.textContent = '— Aktif liste yok —';
      sel.appendChild(opt0);
      (allLists || []).forEach((l) => {
        const o = document.createElement('option');
        o.value = l.id;
        o.textContent = `${l.name} (${Object.keys(l.carts || {}).length})`;
        if (l.id === active) o.selected = true;
        sel.appendChild(o);
      });
      sel.value = active || '';
    }

    rebuildSelect(lists, activeId);

    sel.addEventListener('change', async () => {
      await setActiveListId(sel.value);
      await renderRows();
    });
    rowTop.appendChild(sel);

    function refreshSelectCounts(allLists) {
      const labelMap = new Map(
        (allLists || []).map(l => [l.id, `${l.name} (${Object.keys(l.carts || {}).length})`])
      );
      Array.from(sel.options).forEach(opt => {
        if (!opt.value) return;
        const label = labelMap.get(opt.value);
        if (label) opt.textContent = label;
      });
    }

    const btnNew = document.createElement('button');
    btnNew.className = 'bds-c-btn bds-c-btn-primary bds-c-btn--size-xsmall';
    btnNew.textContent = 'Yeni liste';
    btnNew.onclick = async () => {
      const name = prompt('Yeni liste adı?');
      if (name) {
        const id = await ensureList(name);
        await setActiveListId(id);
        const fresh = await getListsArr();
        rebuildSelect(fresh, id);
        await renderRows();
      }
    };
    rowTop.appendChild(btnNew);

    listWrap.appendChild(rowTop);

    const rowBottom = document.createElement('div');
    Object.assign(rowBottom.style, {
      display: 'grid',
      gridTemplateColumns: 'auto auto auto 1fr auto',
      gap: '8px',
      marginTop: '8px',
      alignItems: 'center'
    });

    const btnPullToList = document.createElement('button');
    btnPullToList.className = 'bds-c-btn bds-c-btn-secondary bds-c-btn--size-xsmall';
    btnPullToList.textContent = 'Listeye çek';
    btnPullToList.onclick = async () => {
      const ok = await saveUnifiedToActiveList();
      if (ok) {
        const fresh = await getListsArr();
        const curId = await getActiveListId();
        rebuildSelect(fresh, curId);
        await renderRows();
      }
    };

    const btnLoadReplace = document.createElement('button');
    btnLoadReplace.className = 'bds-c-btn bds-c-btn-secondary bds-c-btn--size-xsmall';
    btnLoadReplace.textContent = 'Listeyi yükle';
    btnLoadReplace.onclick = async () => {
      const id = await getActiveListId();
      if (!id) return;
      await loadListToSaved(id, {
        mode: 'replace',
        reloadOnSuccess: true
      });
    };

    const btnRenameList = document.createElement('button');
    btnRenameList.className = 'bds-c-btn bds-c-btn-secondary bds-c-btn--size-xsmall';
    btnRenameList.textContent = 'Adını değiştir';
    btnRenameList.onclick = async () => {
      const id = await getActiveListId();
      if (!id) return;

      const all = await getListsArr();
      const cur = all.find(l => l.id === id);
      const suggested = cur?.name || '';

      const name = prompt('Yeni liste adı?', suggested);
      if (!name || name.trim() === suggested.trim()) return;

      const ok = await renameList(id, name.trim());
      if (ok) {
        const fresh = await getListsArr();
        const curId = await getActiveListId();
        rebuildSelect(fresh, curId);
        await renderRows();
      }
    };

    const btnDeleteList = document.createElement('button');
    btnDeleteList.className = 'bds-c-btn bds-c-btn-secondary bds-c-btn--size-xsmall';
    btnDeleteList.textContent = 'Listeyi sil';
    btnDeleteList.onclick = async () => {
      const id = await getActiveListId();
      if (id && confirm('Liste silinsin mi?')) {
        await deleteList(id);
        await setActiveListId('');
        const fresh = await getListsArr();
        rebuildSelect(fresh, '');
        await renderRows();
      }
    };

    function updateActionButtonsState(activeList) {
      const disabled = !activeList || Object.keys(activeList.carts || {}).length === 0;
      btnLoadReplace.disabled = disabled;
      btnRenameList.disabled = !activeList;
      btnDeleteList.disabled = !activeList;
    }

    rowBottom.appendChild(btnPullToList);
    rowBottom.appendChild(btnLoadReplace);
    rowBottom.appendChild(btnRenameList);
    rowBottom.appendChild(btnDeleteList);
    listWrap.appendChild(rowBottom);

    // SAVED VIEW
    const list = document.createElement('div');

    function rowsFromMap(map) {
      return Object.entries(map || {}).map(([vendor_code, entry]) => {
        const cart = entry?.cart || entry;
        return {
          vendor_code,
          vendor_name: cart?.vendor_cart?. [0]?.vendorInfo?.name || vendor_code || 'Bilinmeyen',
          items: cart?.vendor_cart?. [0]?.products?.length || 0,
          subtotal: cart?.subtotal ?? 0,
          lastInactive: entry?.lastInactive || 0
        };
      });
    }

    async function renderRows() {
      list.innerHTML = '';

      const activeId2 = await getActiveListId();
      const all = await getListsArr();

      refreshSelectCounts(all);

      const caption = document.createElement('div');
      caption.style.fontWeight = '600';
      caption.style.margin = '6px 0 8px';

      const active = all.find(l => l.id === activeId2);

      updateActionButtonsState(active);

      if (!active) {
        caption.textContent = 'Bir liste seçin veya “Listeye çek” ile mevcut görünümü bir listeye alın.';
        list.appendChild(caption);
        const empty = document.createElement('div');
        empty.textContent = 'Henüz bir kayıt yok.';
        list.appendChild(empty);
        return;
      }

      const rows = rowsFromMap(active.carts).sort((a, b) => (b.lastInactive || 0) - (a.lastInactive || 0));
      caption.textContent = `Seçili liste: ${active.name}`;
      list.appendChild(caption);

      if (rows.length === 0) {
        const empty = document.createElement('div');
        empty.textContent = 'Bu listede kayıt yok.';
        list.appendChild(empty);
        return;
      }

      rows.forEach((row) => {
        const r = document.createElement('div');
        Object.assign(r.style, {
          display: 'grid',
          gridTemplateColumns: '1fr auto auto',
          gap: '8px',
          alignItems: 'center',
          padding: '6px 0',
          borderBottom: '1px dashed #eee'
        });

        const label = document.createElement('div');
        label.textContent = `${row.vendor_name} (${row.items} ürün)`;
        r.appendChild(label);

        const btnUpdate = document.createElement('button');
        btnUpdate.className = 'bds-c-btn bds-c-btn-secondary bds-c-btn--size-xsmall';
        btnUpdate.textContent = 'Güncelle';
        btnUpdate.onclick = async () => {
          const ok = await updateListFromCurrent(active.id, row.vendor_code);
          if (ok) await renderRows();
        };
        r.appendChild(btnUpdate);

        const btnDelete = document.createElement('button');
        btnDelete.className = 'bds-c-btn bds-c-btn-secondary bds-c-btn--size-xsmall';
        btnDelete.textContent = 'Sil';
        btnDelete.onclick = async () => {
          if (confirm('Bu kaydı listeden silmek istiyor musunuz?')) {
            const ok = await deleteListEntry(active.id, row.vendor_code);
            if (ok) await renderRows();
          }
        };
        r.appendChild(btnDelete);

        list.appendChild(r);
      });
    }

    await renderRows();

    panel.appendChild(headerRow);
    panel.appendChild(listWrap);
    panel.appendChild(list);

    document.body.appendChild(panel);
  }

  function makeDisabledCartButtonClickable() {
    const nodes = document.querySelectorAll('.bds-c-btn-circular-cursor.bds-is-disabled, .bds-c-btn-circular-cursor');
    nodes.forEach((wrap) => {
      if (wrap.dataset.ysClickable === '1') return;

      const hasMultiCartIcon = !!wrap.querySelector('use[href$="#IcMulticart"]');
      const btn = wrap.querySelector('button.bds-c-btn-circular');
      if (!hasMultiCartIcon || !btn) return;

      wrap.style.pointerEvents = 'auto';

      wrap.addEventListener('click', async (e) => {
        const isDisabledNow =
          wrap.classList.contains('bds-is-disabled') ||
          btn.disabled ||
          btn.getAttribute('disabled') !== null ||
          btn.getAttribute('aria-disabled') === 'true';

        if (isDisabledNow) {
          e.preventDefault();
          e.stopPropagation();
          await openManager();
          return;
        }
      });

      wrap.dataset.ysClickable = '1';
    });
  }

  const mo = new MutationObserver(() => {
    injectSaveButtonOnce();
    makeDisabledCartButtonClickable();
  });
  mo.observe(document.documentElement, {
    subtree: true,
    childList: true
  });
  injectSaveButtonOnce();
  makeDisabledCartButtonClickable();

  window.__ysSavedAPI = {
    getSavedMap,
    setSavedMap,
    getUnifiedMap,
    deleteSavedCart,
    getListsArr,
    setListsArr,
    getActiveListId,
    setActiveListId,
    ensureList,
    loadListToSaved,
    renameList,
    deleteList,
    updateListFromCurrent,
    deleteListEntry
  };
})();