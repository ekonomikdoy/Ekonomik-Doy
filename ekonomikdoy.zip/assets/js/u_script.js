(function () {
  'use strict';

  const ERROR_MESSAGES = [
    'Promosyon kodları bu hesap için kullanılamamaktadır',
    'Başka bir ödeme yöntemi kullanmayı deneyin',
    'error_promotions_revoked',
    'tüm yolculuklar tam fiyat üzerinden'
  ];

  let rotateTriggered = false;
  let checkCount = 0;
  const MAX_CHECKS = 30;
  let nameUpdateRunning = false;

  Logger.set({
    tag: 'UBER',
    level: 'debug',
    enabled: true,
    withTimestamp: true
  });

  function readPayloadFromUrl() {
    const u = new URL(window.location.href);
    const raw = u.searchParams.get('__nu');
    if (!raw) return null;
    try {
      const payload = JSON.parse(decodeURIComponent(raw));
      u.searchParams.delete('__nu');
      history.replaceState({}, '', u.toString());
      return payload;
    } catch {
      return null;
    }
  }

  async function processNameUpdateIfAny() {
    if (!window.location.href.startsWith('https://account.uber.com/')) return;
    if (nameUpdateRunning) return;

    const payload = readPayloadFromUrl();
    if (!payload) return;
    const firstname = (payload && (payload.first || payload.firstname)) || '';
    const lastname = (payload && (payload.last || payload.lastname)) || '';

    if (!firstname && !lastname) {
      Logger.e('İsim payload boş/hatalı');
      return;
    }

    nameUpdateRunning = true;
    Logger.d(`Hesap yüklendi. İsim güncelleniyor: ${firstname} ${lastname}`);

    try {
      const res = await fetch('https://account.uber.com/api/updateUserInfo?localeCode=tr-TR', {
        method: 'POST',
        headers: {
          'accept': '*/*',
          'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
          'content-type': 'application/json',
          'x-csrf-token': 'x'
        },
        credentials: 'include',
        body: JSON.stringify({
          userInfoUpdate: {
            userInfoUpdateType: 'NAME',
            name: {
              firstname,
              lastname
            }
          }
        })
      });

      const ct = res.headers.get('content-type') || '';
      const data = ct.includes('application/json') ? await res.json() : await res.text();

      if (res.ok) {
        Logger.d('İsim güncellendi m.uber.com’a dönülüyor...');
      } else {
        Logger.e(`İsim güncellenemedi (HTTP ${res.status})`);
      }
    } catch (e) {
      Logger.e('İsim güncelleme hatası ' + String((e && e.message) || e));
    } finally {
      setTimeout(() => {
        window.location.href = 'https://m.uber.com/';
      }, 300);
    }
  }


  function whenDomReady(callback) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', callback);
    } else {
      callback();
    }
  }

  function checkForPromoError() {
    if (rotateTriggered || checkCount >= MAX_CHECKS) return false;

    checkCount++;

    const pageText = document.body ? document.body.innerText : '';
    for (const msg of ERROR_MESSAGES) {
      if (pageText.includes(msg)) {
        console.log('[UBER-PAY] HATA MESAJI TESPİT EDİLDİ:', msg);
        triggerUARotate();
        return true;
      }
    }

    return false;
  }

  function triggerUARotate() {
    if (rotateTriggered) return;

    rotateTriggered = true;
    console.log('[UBER-PAY] UA rotate tetikleniyor...');

    try {
      chrome.runtime.sendMessage({
        action: 'uberRotateUserAgent'
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.log(
            '[UBER-PAY] Message error:',
            chrome.runtime.lastError.message
          );
          return;
        }

        if (response && response.success) {
          console.log('[UBER-PAY] Yeni UA:', response.userAgent.substring(0, 60));

          setTimeout(() => {
            window.location.href = 'https://m.uber.com/go/home';
          }, 1000);
        }
      });
    } catch (err) {
      console.log('[UBER-PAY] Hata:', err.message);
    }
  }

  whenDomReady(() => {
    processNameUpdateIfAny();

    checkForPromoError();

    const intervalId = setInterval(() => {
      if (checkForPromoError() || checkCount >= MAX_CHECKS) {
        clearInterval(intervalId);
      }
    }, 1000);
  });

  const observer = new MutationObserver(() => {
    const selectors = [
      'a[aria-label="Sign out"]',
      'a[aria-label="Çıkış yap"]',
      'a[href*="auth.uber.com/login/logout"]',
      'a[href*="auth.uber.com/v2/logout"]',
      '[data-testid*="logout"]',
      '[data-testid*="sign-out"]',
      'button[aria-label="Sign out"]',
      'button[aria-label="Çıkış yap"]',
      'button[aria-label="Oturumu kapatın"]',
      'button[data-buttonkey="logOut"]',
      'button[data-tracking-name="LOG_OUT"]'
    ];

    selectors.forEach((selector) => {
      document.querySelectorAll(selector).forEach((element) => {
        element.remove();
      });
    });

    if (!rotateTriggered) {
      checkForPromoError();
    }
  });

  observer.observe(document, {
    attributes: true,
    childList: true,
    subtree: true
  });
})();