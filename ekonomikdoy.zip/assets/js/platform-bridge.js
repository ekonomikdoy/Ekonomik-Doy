/**
 * Platform Bridge - Cross-Platform API Adapter
 * Provides fallback implementations for platform-specific APIs
 */

// Global state for request/session rules
const requestHeaderRules = new Map();
const sessionHeaderRules = new Map();
let webRequestListenersSetup = false;

/**
 * Check if declarativeNetRequest API is available
 */
function isDeclarativeNetRequestSupported() {
  return !!(
    chrome.declarativeNetRequest &&
    chrome.declarativeNetRequest.updateSessionRules &&
    chrome.declarativeNetRequest.updateDynamicRules
  );
}

/**
 * Check if webRequest API is available
 */
function isWebRequestSupported() {
  return !!(
    chrome.webRequest &&
    chrome.webRequest.onBeforeRequest &&
    chrome.webRequest.onBeforeSendHeaders
  );
}

/**
 * Check if browsingData API is available
 */
function isBrowsingDataSupported() {
  return !!(
    chrome.browsingData &&
    chrome.browsingData.remove
  );
}

/**
 * Unified API for request rules
 * Uses declarativeNetRequest if available, falls back to webRequest
 */
const RequestHeaderManager = {
  async updateSessionRules(options) {
    const {
      addRules = [], removeRuleIds = []
    } = options || {};

    if (isDeclarativeNetRequestSupported()) {
      try {
        await chrome.declarativeNetRequest.updateSessionRules({
          addRules,
          removeRuleIds
        });
        console.log('✅ Using declarativeNetRequest for session rules');
        return;
      } catch (error) {
        console.warn('⚠️ declarativeNetRequest.updateSessionRules failed, falling back to webRequest:', error);
      }
    }

    if (isWebRequestSupported()) {
      removeRuleIds.forEach((id) => sessionHeaderRules.delete(id));
      addRules.forEach((rule) => sessionHeaderRules.set(rule.id, rule));
      this._setupWebRequestListener();
      console.log('✅ Using webRequest fallback for session rules');
      return;
    }

    throw new Error('Neither declarativeNetRequest nor webRequest is supported');
  },

  async updateDynamicRules(options) {
    const {
      addRules = [], removeRuleIds = []
    } = options || {};

    if (isDeclarativeNetRequestSupported()) {
      try {
        await chrome.declarativeNetRequest.updateDynamicRules({
          addRules,
          removeRuleIds
        });
        console.log('✅ Using declarativeNetRequest for dynamic rules');
        return;
      } catch (error) {
        console.warn('⚠️ declarativeNetRequest.updateDynamicRules failed, falling back to webRequest:', error);
      }
    }

    if (isWebRequestSupported()) {
      removeRuleIds.forEach((id) => requestHeaderRules.delete(id));
      addRules.forEach((rule) => requestHeaderRules.set(rule.id, rule));
      this._setupWebRequestListener();
      console.log('✅ Using webRequest fallback for dynamic rules');
      return;
    }

    throw new Error('Neither declarativeNetRequest nor webRequest is supported');
  },

  async getSessionRules() {
    if (isDeclarativeNetRequestSupported()) {
      try {
        return await chrome.declarativeNetRequest.getSessionRules();
      } catch (error) {
        console.warn('⚠️ getSessionRules failed:', error);
      }
    }
    return Array.from(sessionHeaderRules.values());
  },

  async getDynamicRules() {
    if (isDeclarativeNetRequestSupported()) {
      try {
        return await chrome.declarativeNetRequest.getDynamicRules();
      } catch (error) {
        console.warn('⚠️ getDynamicRules failed:', error);
      }
    }
    return Array.from(requestHeaderRules.values());
  },

  _setupWebRequestListener() {
    if (webRequestListenersSetup) return;
    webRequestListenersSetup = true;

    console.log('🔧 Setting up webRequest listeners for fallback rules...');

    const getAllRules = () => {
      return [
        ...Array.from(sessionHeaderRules.values()),
        ...Array.from(requestHeaderRules.values())
      ].sort((a, b) => (b?.priority || 1) - (a?.priority || 1));
    };

    chrome.webRequest.onBeforeRequest.addListener(
      (details) => {
        const rules = getAllRules();

        for (const rule of rules) {
          if (!this._matchesCondition(details, rule.condition)) {
            continue;
          }

          if (rule.action?.type === 'block') {
            console.log('🚫 Blocking request:', details.url);
            return {
              cancel: true
            };
          }

          if (rule.action?.type === 'redirect') {
            const redirectUrl = this._buildRedirectUrl(details.url, rule.action.redirect);
            if (redirectUrl && redirectUrl !== details.url) {
              console.log('↪️ Redirecting request:', details.url, '->', redirectUrl);
              return {
                redirectUrl
              };
            }
          }
        }

        return {};
      }, {
        urls: ['<all_urls>']
      },
      ['blocking']
    );

    const onBeforeSendHeadersHandler = (details) => {
      const rules = getAllRules();
      let headers = [...(details.requestHeaders || [])];

      for (const rule of rules) {
        if (!this._matchesCondition(details, rule.condition)) {
          continue;
        }

        if (rule.action?.type !== 'modifyHeaders' || !Array.isArray(rule.action.requestHeaders)) {
          continue;
        }

        for (const headerMod of rule.action.requestHeaders) {
          const headerName = String(headerMod?.header || '').toLowerCase();
          if (!headerName) continue;

          if (headerMod.operation === 'set') {
            headers = headers.filter((h) => String(h?.name || '').toLowerCase() !== headerName);
            headers.push({
              name: headerMod.header,
              value: headerMod.value ?? ''
            });
          } else if (headerMod.operation === 'remove') {
            headers = headers.filter((h) => String(h?.name || '').toLowerCase() !== headerName);
          } else if (headerMod.operation === 'append') {
            const existing = headers.find((h) => String(h?.name || '').toLowerCase() === headerName);
            if (existing) {
              existing.value = `${existing.value || ''}, ${headerMod.value ?? ''}`;
            } else {
              headers.push({
                name: headerMod.header,
                value: headerMod.value ?? ''
              });
            }
          }
        }
      }

      return {
        requestHeaders: headers
      };
    };

    try {
      chrome.webRequest.onBeforeSendHeaders.addListener(
        onBeforeSendHeadersHandler, {
          urls: ['<all_urls>']
        },
        ['blocking', 'requestHeaders', 'extraHeaders']
      );
    } catch (error) {
      console.warn('⚠️ extraHeaders not supported, retrying without it:', error);
      chrome.webRequest.onBeforeSendHeaders.addListener(
        onBeforeSendHeadersHandler, {
          urls: ['<all_urls>']
        },
        ['blocking', 'requestHeaders']
      );
    }

    console.log('✅ webRequest fallback listeners registered');
  },

  _matchesCondition(details, condition) {
    if (!condition) return false;

    const method = String(details?.method || '').toLowerCase();
    const type = this._normalizeResourceType(details?.type);
    const url = String(details?.url || '');

    if (condition.requestMethods?.length) {
      const allowed = condition.requestMethods.map((x) => String(x).toLowerCase());
      if (!allowed.includes(method)) return false;
    }

    if (condition.excludedRequestMethods?.length) {
      const excluded = condition.excludedRequestMethods.map((x) => String(x).toLowerCase());
      if (excluded.includes(method)) return false;
    }

    if (condition.resourceTypes?.length) {
      const allowedTypes = condition.resourceTypes.map((x) => String(x).toLowerCase());
      if (!allowedTypes.includes(type)) return false;
    }

    if (condition.urlFilter) {
      if (!this._matchesUrlFilter(url, condition.urlFilter)) {
        return false;
      }
    }

    return true;
  },

  _normalizeResourceType(type) {
    const value = String(type || 'other').toLowerCase();

    const map = {
      xmlhttprequest: 'xmlhttprequest',
      xhr: 'xmlhttprequest',
      sub_frame: 'sub_frame',
      main_frame: 'main_frame',
      script: 'script',
      stylesheet: 'stylesheet',
      image: 'image',
      font: 'font',
      media: 'media',
      websocket: 'websocket',
      ping: 'ping',
      object: 'object',
      csp_report: 'csp_report',
      webtransport: 'webtransport',
      webbundle: 'webbundle',
      other: 'other'
    };

    return map[value] || value || 'other';
  },

  _matchesUrlFilter(rawUrl, filter) {
    const url = String(rawUrl || '');
    const rule = String(filter || '');

    if (!url || !rule) return false;

    try {
      const parsedUrl = new URL(url);

      // DNR style: ||domain.com or ||domain.com/path*
      if (rule.startsWith('||')) {
        const remainder = rule.slice(2);
        const firstSlash = remainder.indexOf('/');
        const domainPart = (firstSlash === -1 ? remainder : remainder.slice(0, firstSlash)).toLowerCase();
        const pathPart = firstSlash === -1 ? '' : remainder.slice(firstSlash);

        const host = parsedUrl.hostname.toLowerCase();
        const hostMatches = host === domainPart || host.endsWith(`.${domainPart}`);
        if (!hostMatches) return false;

        if (!pathPart) return true;

        const rest = `${parsedUrl.pathname}${parsedUrl.search}${parsedUrl.hash}`;
        return this._wildcardMatch(rest, pathPart);
      }

      // DNR style: |https://example.com/path
      if (rule.startsWith('|')) {
        const prefix = rule.slice(1);
        return url.toLowerCase().startsWith(prefix.toLowerCase());
      }

      if (rule.includes('*')) {
        return this._wildcardMatch(url, rule);
      }

      return url.toLowerCase().includes(rule.toLowerCase());
    } catch {
      if (rule.startsWith('||')) {
        const domain = rule.slice(2).toLowerCase();
        return url.toLowerCase().includes(domain);
      }

      if (rule.startsWith('|')) {
        return url.toLowerCase().startsWith(rule.slice(1).toLowerCase());
      }

      if (rule.includes('*')) {
        return this._wildcardMatch(url, rule);
      }

      return url.toLowerCase().includes(rule.toLowerCase());
    }
  },

  _wildcardMatch(input, pattern) {
    const escaped = String(pattern)
      .replace(/[.+?^${}()|[\]\\]/g, '\\$&')
      .replace(/\*/g, '.*');
    return new RegExp(escaped, 'i').test(String(input || ''));
  },

  _buildRedirectUrl(rawUrl, redirect) {
    if (!redirect) return null;

    try {
      if (redirect.url) {
        return redirect.url;
      }

      if (redirect.extensionPath && chrome.runtime?.getURL) {
        return chrome.runtime.getURL(String(redirect.extensionPath).replace(/^\/+/, ''));
      }

      if (redirect.transform) {
        const url = new URL(rawUrl);
        const transform = redirect.transform;

        if (transform.scheme) {
          url.protocol = `${String(transform.scheme).replace(/:$/, '')}:`;
        }

        if (transform.host) {
          url.hostname = transform.host;
        }

        if (transform.port !== undefined && transform.port !== null) {
          url.port = String(transform.port);
        }

        if (transform.path) {
          const path = String(transform.path);
          url.pathname = path.startsWith('/') ? path : `/${path}`;
        }

        if (transform.queryTransform) {
          this._applyQueryTransform(url, transform.queryTransform);
        }

        if (transform.fragment !== undefined && transform.fragment !== null) {
          const frag = String(transform.fragment);
          url.hash = frag.startsWith('#') ? frag : `#${frag}`;
        }

        return url.toString();
      }
    } catch (error) {
      console.warn('⚠️ Failed to build redirect URL:', error);
    }

    return null;
  },

  _applyQueryTransform(urlObj, queryTransform) {
    const removeParams = Array.isArray(queryTransform?.removeParams) ?
      queryTransform.removeParams : [];

    const addOrReplaceParams = Array.isArray(queryTransform?.addOrReplaceParams) ?
      queryTransform.addOrReplaceParams : [];

    for (const key of removeParams) {
      if (key) urlObj.searchParams.delete(String(key));
    }

    for (const entry of addOrReplaceParams) {
      if (!entry?.key) continue;
      urlObj.searchParams.set(String(entry.key), entry.value ?? '');
    }
  }
};

/**
 * Browsing Data Manager
 * Provides fallback for browsingData API
 */
const BrowsingDataManager = {
  async remove(options, dataToRemove) {
    if (isBrowsingDataSupported()) {
      try {
        await chrome.browsingData.remove(options, dataToRemove);
        console.log('✅ Using browsingData API');
        return true;
      } catch (error) {
        console.warn('⚠️ browsingData API failed, using fallback:', error);
      }
    }

    console.log('🔄 Using manual cleanup fallback');

    const {
      origins
    } = options || {};
    const promises = [];

    if (dataToRemove?.cookies && origins?.length) {
      for (const origin of origins) {
        try {
          const domain = new URL(origin).hostname;
          promises.push(this._clearCookiesForDomain(domain));
        } catch (e) {
          console.warn('⚠️ Invalid origin for cookie cleanup:', origin, e);
        }
      }
    }

    if (dataToRemove?.localStorage && origins?.length) {
      for (const origin of origins) {
        promises.push(this._clearLocalStorageForOrigin(origin));
      }
    }

    if (dataToRemove?.indexedDB && origins?.length) {
      for (const origin of origins) {
        promises.push(this._clearIndexedDBForOrigin(origin));
      }
    }

    await Promise.allSettled(promises);
    return true;
  },

  async _clearCookiesForDomain(domain) {
    try {
      const cookies = await chrome.cookies.getAll({
        domain
      });

      const promises = cookies.map((cookie) => {
        const host = String(cookie.domain || '').replace(/^\./, '');
        const url = `http${cookie.secure ? 's' : ''}://${host}${cookie.path || '/'}`;
        const details = {
          url,
          name: cookie.name
        };
        if (cookie.storeId) details.storeId = cookie.storeId;
        if (cookie.partitionKey) details.partitionKey = cookie.partitionKey;
        return chrome.cookies.remove(details);
      });

      await Promise.allSettled(promises);
      console.log(`✅ Cleared ${cookies.length} cookies for ${domain}`);
    } catch (error) {
      console.error(`❌ Error clearing cookies for ${domain}:`, error);
    }
  },

  async _clearLocalStorageForOrigin(origin) {
    let tabId = null;
    let createdTempTab = false;

    try {
      const tabs = await chrome.tabs.query({
        url: origin + '/*'
      });

      if (tabs.length > 0) {
        tabId = tabs[0].id;
      } else {
        const tab = await chrome.tabs.create({
          url: origin,
          active: false
        });
        tabId = tab.id;
        createdTempTab = true;

        await new Promise((resolve) => {
          const listener = (updatedTabId, info) => {
            if (updatedTabId === tabId && info.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(listener);
              resolve();
            }
          };
          chrome.tabs.onUpdated.addListener(listener);
        });
      }

      await chrome.scripting.executeScript({
        target: {
          tabId
        },
        func: () => {
          try {
            localStorage.clear();
            sessionStorage.clear();
            console.log('localStorage and sessionStorage cleared');
          } catch (e) {
            console.error('Error clearing storage:', e);
          }
        }
      });

      console.log(`✅ Cleared localStorage for ${origin}`);
    } catch (error) {
      console.error(`❌ Error clearing localStorage for ${origin}:`, error);
    } finally {
      if (createdTempTab && tabId) {
        try {
          await chrome.tabs.remove(tabId);
        } catch (_) {}
      }
    }
  },

  async _clearIndexedDBForOrigin(origin) {
    let tabId = null;
    let createdTempTab = false;

    try {
      const tabs = await chrome.tabs.query({
        url: origin + '/*'
      });

      if (tabs.length > 0) {
        tabId = tabs[0].id;
      } else {
        const tab = await chrome.tabs.create({
          url: origin,
          active: false
        });
        tabId = tab.id;
        createdTempTab = true;

        await new Promise((resolve) => {
          const listener = (updatedTabId, info) => {
            if (updatedTabId === tabId && info.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(listener);
              resolve();
            }
          };
          chrome.tabs.onUpdated.addListener(listener);
        });
      }

      await chrome.scripting.executeScript({
        target: {
          tabId
        },
        func: async () => {
          try {
            if (window.indexedDB && indexedDB.databases) {
              const databases = await indexedDB.databases();
              await Promise.all(
                (databases || []).map((db) => {
                  return new Promise((resolve) => {
                    if (!db?.name) return resolve();
                    const req = indexedDB.deleteDatabase(db.name);
                    req.onsuccess = () => resolve();
                    req.onerror = () => resolve();
                    req.onblocked = () => resolve();
                  });
                })
              );
            }
          } catch (e) {
            console.error('Error clearing IndexedDB:', e);
          }
        }
      });

      console.log(`✅ Cleared IndexedDB for ${origin}`);
    } catch (error) {
      console.error(`❌ Error clearing IndexedDB for ${origin}:`, error);
    } finally {
      if (createdTempTab && tabId) {
        try {
          await chrome.tabs.remove(tabId);
        } catch (_) {}
      }
    }
  }
};

/**
 * Export unified API
 */
if (typeof self !== 'undefined') {
  self.RequestHeaderManager = RequestHeaderManager;
  self.BrowsingDataManager = BrowsingDataManager;
  self.isDeclarativeNetRequestSupported = isDeclarativeNetRequestSupported;
  self.isWebRequestSupported = isWebRequestSupported;
  self.isBrowsingDataSupported = isBrowsingDataSupported;
}