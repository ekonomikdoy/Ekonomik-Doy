/**
 * Platform Bridge - Cross-Platform API Adapter
 * Provides fallback implementations for platform-specific APIs
 */

// Global state for request header modifications
const requestHeaderRules = new Map();
const sessionHeaderRules = new Map();
let webRequestListenersSetup = false;

/**
 * Check if declarativeNetRequest API is available
 */
function isDeclarativeNetRequestSupported() {
  return !!(chrome.declarativeNetRequest && 
            chrome.declarativeNetRequest.updateSessionRules);
}

/**
 * Check if webRequest API is available
 */
function isWebRequestSupported() {
  return !!(chrome.webRequest && 
            chrome.webRequest.onBeforeSendHeaders);
}

/**
 * Check if browsingData API is available
 */
function isBrowsingDataSupported() {
  return !!(chrome.browsingData && 
            chrome.browsingData.remove);
}

/**
 * Unified API for modifying request headers
 * Uses declarativeNetRequest if available, falls back to webRequest
 */
const RequestHeaderManager = {
  /**
   * Update session rules (add/remove header modification rules)
   */
  async updateSessionRules(options) {
    const { addRules = [], removeRuleIds = [] } = options;

    // Try declarativeNetRequest first
    if (isDeclarativeNetRequestSupported()) {
      try {
        await chrome.declarativeNetRequest.updateSessionRules(options);
        console.log('✅ Using declarativeNetRequest for header modification');
        return;
      } catch (error) {
        console.warn('⚠️ declarativeNetRequest failed, falling back to webRequest:', error);
      }
    }

    // Fallback to webRequest
    if (isWebRequestSupported()) {
      console.log('🔄 Using webRequest fallback for header modification');
      
      // Remove old rules
      removeRuleIds.forEach(id => {
        sessionHeaderRules.delete(id);
      });

      // Add new rules
      addRules.forEach(rule => {
        sessionHeaderRules.set(rule.id, rule);
      });

      // Setup webRequest listener if not already set
      this._setupWebRequestListener();
      return;
    }

    throw new Error('Neither declarativeNetRequest nor webRequest is supported');
  },

  /**
   * Update dynamic rules
   */
  async updateDynamicRules(options) {
    const { addRules = [], removeRuleIds = [] } = options;
    
    console.log(`📋 updateDynamicRules called: ${addRules.length} rules to add, ${removeRuleIds.length} to remove`);

    if (isDeclarativeNetRequestSupported()) {
      try {
        console.log('🔄 Attempting declarativeNetRequest.updateDynamicRules...');
        await chrome.declarativeNetRequest.updateDynamicRules(options);
        console.log('✅ Using declarativeNetRequest for dynamic rules');
        return;
      } catch (error) {
        console.warn('⚠️ declarativeNetRequest failed, falling back to webRequest:', error);
      }
    }

    // Fallback to webRequest
    if (isWebRequestSupported()) {
      console.log('🔄 Using webRequest fallback for dynamic rules');
      
      removeRuleIds.forEach(id => {
        requestHeaderRules.delete(id);
      });

      addRules.forEach(rule => {
        requestHeaderRules.set(rule.id, rule);
      });

      this._setupWebRequestListener();
      console.log('✅ webRequest fallback completed');
      return;
    }

    throw new Error('Neither declarativeNetRequest nor webRequest is supported');
  },

  /**
   * Get session rules
   */
  async getSessionRules() {
    if (isDeclarativeNetRequestSupported()) {
      try {
        return await chrome.declarativeNetRequest.getSessionRules();
      } catch (error) {
        console.warn('⚠️ getSessionRules failed:', error);
      }
    }

    // Return our stored rules
    return Array.from(sessionHeaderRules.values());
  },

  /**
   * Get dynamic rules
   */
  async getDynamicRules() {
    if (isDeclarativeNetRequestSupported()) {
      try {
        return await chrome.declarativeNetRequest.getDynamicRules();
      } catch (error) {
        console.warn('⚠️ getDynamicRules failed:', error);
      }
    }

    // Return our stored rules
    return Array.from(requestHeaderRules.values());
  },

  /**
   * Setup webRequest listener for header modification
   */
  _setupWebRequestListener() {
    if (webRequestListenersSetup) return;
    webRequestListenersSetup = true;
    
    console.log('🔧 Setting up webRequest listeners for blocking and header modification...');

    // Combine all rules
    const getAllRules = () => {
      return [
        ...Array.from(sessionHeaderRules.values()),
        ...Array.from(requestHeaderRules.values())
      ];
    };

    // onBeforeRequest listener for blocking
    chrome.webRequest.onBeforeRequest.addListener(
      (details) => {
        const rules = getAllRules();

        for (const rule of rules) {
          // Check if this is a blocking rule
          if (rule.action && rule.action.type === 'block') {
            // Check if URL matches the rule condition
            if (this._matchesCondition(details.url, rule.condition)) {
              console.log('🚫 Blocking request:', details.url);
              return { cancel: true };
            }
          }
        }

        return { cancel: false };
      },
      { urls: ['<all_urls>'] },
      ['blocking']
    );

    // onBeforeSendHeaders listener
    chrome.webRequest.onBeforeSendHeaders.addListener(
      (details) => {
        const rules = getAllRules();
        let headers = details.requestHeaders || [];

        for (const rule of rules) {
          // Check if URL matches the rule condition
          if (!this._matchesCondition(details.url, rule.condition)) {
            continue;
          }

          // Apply header modifications
          if (rule.action && rule.action.requestHeaders) {
            for (const headerMod of rule.action.requestHeaders) {
              const headerName = headerMod.header.toLowerCase();

              if (headerMod.operation === 'set') {
                // Remove existing header
                headers = headers.filter(h => h.name.toLowerCase() !== headerName);
                // Add new header
                headers.push({
                  name: headerMod.header,
                  value: headerMod.value
                });
              } else if (headerMod.operation === 'remove') {
                headers = headers.filter(h => h.name.toLowerCase() !== headerName);
              } else if (headerMod.operation === 'append') {
                const existing = headers.find(h => h.name.toLowerCase() === headerName);
                if (existing) {
                  existing.value += ', ' + headerMod.value;
                } else {
                  headers.push({
                    name: headerMod.header,
                    value: headerMod.value
                  });
                }
              }
            }
          }
        }

        return { requestHeaders: headers };
      },
      { urls: ['<all_urls>'] },
      ['blocking', 'requestHeaders', 'extraHeaders']
    );

    console.log('✅ webRequest listeners setup complete (blocking + headers)');
  },

  /**
   * Check if URL matches rule condition
   */
  _matchesCondition(url, condition) {
    if (!condition) return false;

    // Check urlFilter
    if (condition.urlFilter) {
      const filter = condition.urlFilter;
      
      // Simple substring matching for patterns without wildcards
      // This matches how declarativeNetRequest urlFilter works
      if (url.includes(filter)) {
        return true;
      }
      
      // Try regex matching for more complex patterns
      try {
        const regexPattern = filter
          .replace(/[.+?^${}()|[\]\\]/g, '\\$&') // Escape special chars
          .replace(/\*/g, '.*'); // Convert * to .*
        const regex = new RegExp(regexPattern, 'i');
        if (!regex.test(url)) return false;
      } catch (e) {
        // If regex fails, fall back to simple includes check
        if (!url.includes(filter)) return false;
      }
    }

    // Check resourceTypes (simplified check)
    if (condition.resourceTypes) {
      // For simplicity, we'll assume it matches
      // In a real implementation, you'd check the request type
    }

    return true;
  }
};

/**
 * Browsing Data Manager
 * Provides fallback for browsingData API
 */
const BrowsingDataManager = {
  /**
   * Remove browsing data
   */
  async remove(options, dataToRemove) {
    if (isBrowsingDataSupported()) {
      try {
        await chrome.browsingData.remove(options, dataToRemove);
        console.log('✅ Using browsingData API');
        return true;
      } catch (error) {
        console.warn('⚠️ browsingData API failed, using fallback:', error);
      }
    }

    // Fallback: Manual cleanup
    console.log('🔄 Using manual cleanup fallback');
    
    const { origins } = options;
    const promises = [];

    // Clear cookies
    if (dataToRemove.cookies) {
      if (origins && origins.length > 0) {
        for (const origin of origins) {
          const domain = new URL(origin).hostname;
          promises.push(this._clearCookiesForDomain(domain));
        }
      }
    }

    // Clear localStorage (via content script injection)
    if (dataToRemove.localStorage) {
      if (origins && origins.length > 0) {
        for (const origin of origins) {
          promises.push(this._clearLocalStorageForOrigin(origin));
        }
      }
    }

    // Clear indexedDB (via content script injection)
    if (dataToRemove.indexedDB) {
      if (origins && origins.length > 0) {
        for (const origin of origins) {
          promises.push(this._clearIndexedDBForOrigin(origin));
        }
      }
    }

    await Promise.allSettled(promises);
    return true;
  },

  /**
   * Clear cookies for a specific domain
   */
  async _clearCookiesForDomain(domain) {
    try {
      const cookies = await chrome.cookies.getAll({ domain });
      const promises = cookies.map(cookie => {
        const url = `http${cookie.secure ? 's' : ''}://${cookie.domain}${cookie.path}`;
        return chrome.cookies.remove({ url, name: cookie.name });
      });
      await Promise.all(promises);
      console.log(`✅ Cleared ${cookies.length} cookies for ${domain}`);
    } catch (error) {
      console.error(`❌ Error clearing cookies for ${domain}:`, error);
    }
  },

  /**
   * Clear localStorage for origin (requires tab injection)
   */
  async _clearLocalStorageForOrigin(origin) {
    try {
      // Find or create a tab with this origin
      const tabs = await chrome.tabs.query({ url: origin + '/*' });
      let tabId;

      if (tabs.length > 0) {
        tabId = tabs[0].id;
      } else {
        // Create a temporary tab
        const tab = await chrome.tabs.create({ url: origin, active: false });
        tabId = tab.id;
        
        // Wait for tab to load
        await new Promise(resolve => {
          const listener = (updatedTabId, info) => {
            if (updatedTabId === tabId && info.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(listener);
              resolve();
            }
          };
          chrome.tabs.onUpdated.addListener(listener);
        });
      }

      // Inject script to clear localStorage
      await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          try {
            localStorage.clear();
            sessionStorage.clear();
            console.log('localStorage and sessionStorage cleared');
          } catch (e) {
            console.error('Error clearing storage:', e);
          }
        }
      });

      console.log(`✅ Cleared localStorage for ${origin}`);
    } catch (error) {
      console.error(`❌ Error clearing localStorage for ${origin}:`, error);
    }
  },

  /**
   * Clear indexedDB for origin (requires tab injection)
   */
  async _clearIndexedDBForOrigin(origin) {
    try {
      const tabs = await chrome.tabs.query({ url: origin + '/*' });
      let tabId;

      if (tabs.length > 0) {
        tabId = tabs[0].id;
      } else {
        const tab = await chrome.tabs.create({ url: origin, active: false });
        tabId = tab.id;
        
        await new Promise(resolve => {
          const listener = (updatedTabId, info) => {
            if (updatedTabId === tabId && info.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(listener);
              resolve();
            }
          };
          chrome.tabs.onUpdated.addListener(listener);
        });
      }

      await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          try {
            if (window.indexedDB && indexedDB.databases) {
              indexedDB.databases().then(databases => {
                databases.forEach(db => {
                  if (db.name) {
                    indexedDB.deleteDatabase(db.name);
                    console.log(`Deleted IndexedDB: ${db.name}`);
                  }
                });
              });
            }
          } catch (e) {
            console.error('Error clearing IndexedDB:', e);
          }
        }
      });

      console.log(`✅ Cleared IndexedDB for ${origin}`);
    } catch (error) {
      console.error(`❌ Error clearing IndexedDB for ${origin}:`, error);
    }
  }
};

/**
 * Export unified API
 */
if (typeof self !== 'undefined') {
  self.RequestHeaderManager = RequestHeaderManager;
  self.BrowsingDataManager = BrowsingDataManager;
  self.isDeclarativeNetRequestSupported = isDeclarativeNetRequestSupported;
  self.isWebRequestSupported = isWebRequestSupported;
  self.isBrowsingDataSupported = isBrowsingDataSupported;
}
