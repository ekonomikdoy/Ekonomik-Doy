(() => {
  /* ==== SABİTLER ==== */
  const MAP_IFRAME_URL = 'https://ekonomikdoy.org/map.html';
  const IFRAME_ORIGIN = new URL(MAP_IFRAME_URL).origin;
  const SKEY = {
    THEME: 'ekonomik_doy_theme',
    NAMES: 'ekonomik_doy_names',
    NAME_SELECT: 'ekonomik_doy_selected_name',
    ADDR: 'ekonomik_doy_addresses',
    ADDR_SELECT: 'ekonomik_doy_selected_address',
    CARTS: 'ekonomik_doy_carts',
    CART_SELECT: 'ekonomik_doy_selected_cart'
  };
  const DEFAULT_CENTER = {
    lat: 41.0082,
    lng: 28.9784
  }; // İstanbul

  /* ==== Ülke kodları (kısaltılmış değil) ==== */
  const COUNTRY_CODES = [{
      code: '+90',
      name: 'Türkiye'
    }, {
      code: '+1',
      name: 'ABD/Kanada'
    }, {
      code: '+7',
      name: 'Rusya/Kazakistan'
    },
    {
      code: '+20',
      name: 'Mısır'
    }, {
      code: '+30',
      name: 'Yunanistan'
    }, {
      code: '+31',
      name: 'Hollanda'
    },
    {
      code: '+32',
      name: 'Belçika'
    }, {
      code: '+33',
      name: 'Fransa'
    }, {
      code: '+34',
      name: 'İspanya'
    },
    {
      code: '+36',
      name: 'Macaristan'
    }, {
      code: '+39',
      name: 'İtalya'
    }, {
      code: '+40',
      name: 'Romanya'
    },
    {
      code: '+41',
      name: 'İsviçre'
    }, {
      code: '+43',
      name: 'Avusturya'
    }, {
      code: '+44',
      name: 'Birleşik Krallık'
    },
    {
      code: '+45',
      name: 'Danimarka'
    }, {
      code: '+46',
      name: 'İsveç'
    }, {
      code: '+47',
      name: 'Norveç'
    },
    {
      code: '+48',
      name: 'Polonya'
    }, {
      code: '+49',
      name: 'Almanya'
    }, {
      code: '+52',
      name: 'Meksika'
    },
    {
      code: '+54',
      name: 'Arjantin'
    }, {
      code: '+55',
      name: 'Brezilya'
    }, {
      code: '+56',
      name: 'Şili'
    },
    {
      code: '+57',
      name: 'Kolombiya'
    }, {
      code: '+60',
      name: 'Malezya'
    }, {
      code: '+61',
      name: 'Avustralya'
    },
    {
      code: '+62',
      name: 'Endonezya'
    }, {
      code: '+63',
      name: 'Filipinler'
    }, {
      code: '+64',
      name: 'Yeni Zelanda'
    },
    {
      code: '+65',
      name: 'Singapur'
    }, {
      code: '+66',
      name: 'Tayland'
    }, {
      code: '+81',
      name: 'Japonya'
    },
    {
      code: '+82',
      name: 'Güney Kore'
    }, {
      code: '+84',
      name: 'Vietnam'
    }, {
      code: '+86',
      name: 'Çin'
    },
    {
      code: '+92',
      name: 'Pakistan'
    }, {
      code: '+94',
      name: 'Sri Lanka'
    }, {
      code: '+98',
      name: 'İran'
    },
    {
      code: '+212',
      name: 'Fas'
    }, {
      code: '+213',
      name: 'Cezayir'
    }, {
      code: '+216',
      name: 'Tunus'
    },
    {
      code: '+218',
      name: 'Libya'
    }, {
      code: '+351',
      name: 'Portekiz'
    }, {
      code: '+352',
      name: 'Lüksemburg'
    },
    {
      code: '+353',
      name: 'İrlanda'
    }, {
      code: '+354',
      name: 'İzlanda'
    }, {
      code: '+355',
      name: 'Arnavutluk'
    },
    {
      code: '+356',
      name: 'Malta'
    }, {
      code: '+357',
      name: 'Kıbrıs'
    }, {
      code: '+358',
      name: 'Finlandiya'
    },
    {
      code: '+359',
      name: 'Bulgaristan'
    }, {
      code: '+370',
      name: 'Litvanya'
    }, {
      code: '+371',
      name: 'Letonya'
    },
    {
      code: '+372',
      name: 'Estonya'
    }, {
      code: '+380',
      name: 'Ukrayna'
    }, {
      code: '+381',
      name: 'Sırbistan'
    },
    {
      code: '+382',
      name: 'Karadağ'
    }, {
      code: '+386',
      name: 'Slovenya'
    }, {
      code: '+387',
      name: 'Bosna-Hersek'
    },
    {
      code: '+389',
      name: 'Kuzey Makedonya'
    }, {
      code: '+420',
      name: 'Çekya'
    }, {
      code: '+421',
      name: 'Slovakya'
    },
    {
      code: '+852',
      name: 'Hong Kong'
    }, {
      code: '+853',
      name: 'Makao'
    }, {
      code: '+855',
      name: 'Kamboçya'
    },
    {
      code: '+856',
      name: 'Laos'
    }, {
      code: '+880',
      name: 'Bangladeş'
    }, {
      code: '+961',
      name: 'Lübnan'
    },
    {
      code: '+962',
      name: 'Ürdün'
    }, {
      code: '+964',
      name: 'Irak'
    }, {
      code: '+965',
      name: 'Kuveyt'
    },
    {
      code: '+966',
      name: 'Suudi Arabistan'
    }, {
      code: '+971',
      name: 'BAE'
    }, {
      code: '+972',
      name: 'İsrail'
    },
    {
      code: '+973',
      name: 'Bahreyn'
    }, {
      code: '+974',
      name: 'Katar'
    }, {
      code: '+975',
      name: 'Butan'
    },
    {
      code: '+976',
      name: 'Moğolistan'
    }, {
      code: '+977',
      name: 'Nepal'
    }
  ];

  /* ==== Helpers ==== */
  const el = (id) => document.getElementById(id);
  const qs = (sel) => document.querySelector(sel);
  const debounce = (fn, ms = 300) => {
    let t;
    return (...a) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...a), ms);
    }
  };
  const digits = (s = '') => (s || '').replace(/\D+/g, '');
  const sanitizeToken = (s = '') => s.replace(/[^A-Za-z0-9]/g, '');
  const escapeHtml = (s = '') => s.replace(/[&<>"']/g, m => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  } [m]));
  const genFormId = () => 'mi' + Math.random().toString(36).slice(2, 12);
  const setSelectValue = (sel, val) => {
    const o = [...sel.options].find(x => x.value === val);
    if (o) {
      sel.value = val;
      return;
    }
    const n = document.createElement('option');
    n.value = val;
    n.textContent = val;
    sel.appendChild(n);
    sel.value = val;
  };
  const show = (n) => n?.classList.remove('d-none');
  const hide = (n) => n?.classList.add('d-none');
  const clone = (o) => JSON.parse(JSON.stringify(o || null));
  const addAnim = (el, cls) => {
    el.classList.add('animate__animated', cls);
    el.addEventListener('animationend', () => el.classList.remove('animate__animated', cls), {
      once: true
    });
  };
  const numberIsSufficient = (v) => ((v || '').trim().length >= 2);
  const atLeastOne = (s = '') => (s || '').trim().length >= 1;
  const markField = (input, ok) => {
    if (!input) return false;
    input.classList.remove('input-valid', 'input-invalid');
    input.classList.add(ok ? 'input-valid' : 'input-invalid');
    return !!ok;
  };

  function cartEntryCount(rec) {
    try {
      return Object.keys(rec?.carts || {}).length;
    } catch {
      return 0;
    }
  }

  function safeQty(p) {
    return p?.quantity ?? p?.qty ?? p?.amount ?? p?.count ?? p?.quantityAmount ?? 1;
  }

  /* ==== Label helpers ==== */
  const LABEL_KEYS = {
    'Ev': 'Home',
    'İş': 'Work',
    'Eş': 'Partner',
    'Diğer': 'Other'
  };

  const TYPE_MAP = {
    Other: 0,
    Home: 1,
    Work: 2,
    Partner: 3
  };

  function makeLabelPair(selectedLabel, customInput) {
    if (selectedLabel === 'Diğer') {
      const key = (customInput || '').trim() || 'Other';
      const display = (customInput || '').trim() || 'Diğer';
      return {
        label: display,
        label_key: key
      };
    }
    return {
      label: selectedLabel,
      label_key: LABEL_KEYS[selectedLabel] || selectedLabel
    };
  }

  function deriveUiFromRecord(rec) {
    const k = rec.label_key || rec.label || '';
    if (k === 'Home') return {
      pill: 'Ev',
      custom: ''
    };
    if (k === 'Work') return {
      pill: 'İş',
      custom: ''
    };
    if (k === 'Partner') return {
      pill: 'Eş',
      custom: ''
    };
    // Diğer: custom anahtar
    return {
      pill: 'Diğer',
      custom: (k && k !== 'Other') ? k : (rec.label || '')
    };
  }

  function getTypeFromRecord(rec) {
    const keyMaybeEng = (rec?.label_key || '').trim();
    if (keyMaybeEng && TYPE_MAP[keyMaybeEng] != null) return TYPE_MAP[keyMaybeEng];

    const tr = (rec?.label || '').trim();
    const eng = LABEL_KEYS[tr];
    if (eng && TYPE_MAP[eng] != null) return TYPE_MAP[eng];

    return 0;
  }

  // --- Max length sınırları (istediğin gibi ayarlayabilirsin)
  const MAXLEN = {
    firstName: 30,
    lastName: 30,
    number: 60, // Sokak numarası
    building: 60, // Apartman
    flat: 60, // Daire
    floor: 60, // Kat
    company: 60, // Şirket
    note: 350, // Kuryeye Not
    customLabel: 30, // Özel Etiket
    search: 60 // Adres arama kutusu
  };

  function setMax(el, n) {
    if (el && n) el.setAttribute('maxlength', String(n));
  }

  function applyMaxLengths() {
    setMax(inpFirstName, MAXLEN.firstName);
    setMax(inpLastName, MAXLEN.lastName);
    setMax(inpNumber, MAXLEN.number);
    setMax(inpBuilding, MAXLEN.building);
    setMax(inpFlat, MAXLEN.flat);
    setMax(inpFloor, MAXLEN.floor);
    setMax(inpCompany, MAXLEN.company);
    setMax(inpNote, MAXLEN.note);
    setMax(inpCustomLabel, MAXLEN.customLabel);
    setMax(searchInput, MAXLEN.search);
  }

  function bindDigitsOnly(input, getMaxLen = () => 14) {
    if (!input) return;

    const allowKey = (e) => {
      if (e.ctrlKey || e.metaKey || e.altKey) return true;
      const k = e.key;
      return (
        k === 'Backspace' || k === 'Delete' || k === 'Tab' ||
        k === 'ArrowLeft' || k === 'ArrowRight' || k === 'Home' || k === 'End' ||
        /^\d$/.test(k)
      );
    };

    input.addEventListener('keydown', (e) => {
      if (!allowKey(e)) e.preventDefault();
    });

    input.addEventListener('beforeinput', (e) => {
      if (e.inputType?.startsWith('insert') && e.data && /\D/.test(e.data)) {
        e.preventDefault();
      }
    });

    input.addEventListener('paste', (e) => {
      e.preventDefault();
      const t = (e.clipboardData || window.clipboardData).getData('text') || '';
      const ins = digits(t);
      const s = input.selectionStart ?? input.value.length;
      const epos = input.selectionEnd ?? input.value.length;
      const max = getMaxLen();
      input.value = (input.value.slice(0, s) + ins + input.value.slice(epos)).replace(/\D+/g, '').slice(0, max);
      const caret = Math.min(s + ins.length, input.value.length);
      requestAnimationFrame(() => input.setSelectionRange(caret, caret));
    });

    input.addEventListener('input', () => {
      const max = getMaxLen();
      const raw = input.value;
      const clean = digits(raw).slice(0, max);
      if (raw !== clean) {
        const s = input.selectionStart ?? clean.length;
        input.value = clean;
        requestAnimationFrame(() => input.setSelectionRange(Math.min(s, clean.length), Math.min(s, clean.length)));
      }
    });
  }

  function phoneBoundsFor(cc = '+90') {
    return (cc === '+90') ? {
      min: 10,
      max: 10
    } : {
      min: 6,
      max: 14
    };
  }

  function updatePhoneConstraints() {
    if (!selCountryCode || !inpPhoneLocal) return;
    const cc = selCountryCode.value || '+90';
    const {
      min,
      max
    } = phoneBoundsFor(cc);

    inpPhoneLocal.maxLength = max;
    inpPhoneLocal.setAttribute('pattern', `\\d{${min},${max}}`);
    inpPhoneLocal.setAttribute('autocomplete', 'tel-national');
    inpPhoneLocal.setAttribute('inputmode', 'numeric');
    inpPhoneLocal.placeholder = (cc === '+90') ? '5xx xxx xx xx' : 'Yerel numara';

    const clean = digits(inpPhoneLocal.value).slice(0, max);
    if (inpPhoneLocal.value !== clean) inpPhoneLocal.value = clean;
  }

  /* ==== Theme ==== */
  const htmlEl = document.documentElement;
  const btnTheme = el('btnTheme');

  function applyTheme(theme) {
    htmlEl.setAttribute('data-bs-theme', theme);
    writeTheme(theme).catch(() => {});
    if (btnTheme) {
      btnTheme.innerHTML = theme === 'dark' ?
        '<i class="fa-solid fa-sun"></i>' :
        '<i class="fa-solid fa-moon"></i>';
      btnTheme.setAttribute('title', theme === 'dark' ? 'Açık tema' : 'Koyu tema');
    }
  }

  async function initTheme() {
    let saved = await readTheme();
    if (!saved) {
      await writeTheme(saved).catch(() => {});
    }
    const theme = (saved === 'dark' || saved === 'light') ? saved : 'dark';
    applyTheme(theme);
  }

  btnTheme?.addEventListener('click', () => {
    const next = htmlEl.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
    applyTheme(next);
  });

  /* ==== Storage ==== */
  const getLocal = (key) =>
    new Promise((res) => chrome.storage.local.get([key], (o) => res(o?. [key])));

  const setLocal = (obj) =>
    new Promise((res, rej) =>
      chrome.storage.local.set(obj, () => {
        const err = chrome.runtime.lastError;
        err ? rej(err) : res(true);
      })
    );

  const removeLocal = (key) =>
    new Promise((res) =>
      chrome.storage.local.remove(key, () => res(!chrome.runtime.lastError))
    );

  async function storageGet(key, defVal) {
    const v = await getLocal(key);
    return v ?? defVal;
  }

  async function storageSet(key, value) {
    await setLocal({
      [key]: value
    }).catch((e) => {
      console.log('storageSet local error:', e);
      throw new Error('storageSet failed');
    });
    return true;
  }

  async function storageSetMany(obj) {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) {
      throw new Error('storageSetMany expects a plain object');
    }
    try {
      await setLocal(obj);
      return true;
    } catch (e) {
      console.log('storageSetMany local error:', e);
      throw new Error('storageSetMany failed');
    }
  }

  async function storageRemove(key) {
    return await removeLocal(key);
  }

  const readTheme = async () => await storageGet(SKEY.THEME, '');
  const writeTheme = async (v) => v ? storageSet(SKEY.THEME, v) : storageRemove(SKEY.THEME);

  const readNames = async () => await storageGet(SKEY.NAMES, []);
  const writeNames = async (arr) => (Array.isArray(arr) && arr.length) ?
    storageSet(SKEY.NAMES, arr) :
    storageRemove(SKEY.NAMES);

  const readSelectedName = async () => await storageGet(SKEY.NAME_SELECT, '');
  const writeSelectedName = async (id) => id ?
    storageSet(SKEY.NAME_SELECT, id) :
    storageRemove(SKEY.NAME_SELECT);

  const readAddresses = async () => await storageGet(SKEY.ADDR, []);
  const writeAddresses = async (arr) => (Array.isArray(arr) && arr.length) ?
    storageSet(SKEY.ADDR, arr) :
    storageRemove(SKEY.ADDR);

  const readSelectedAddress = async () => await storageGet(SKEY.ADDR_SELECT, '');
  const writeSelectedAddress = async (id) => id ?
    storageSet(SKEY.ADDR_SELECT, id) :
    storageRemove(SKEY.ADDR_SELECT);

  const readCarts = async () => await storageGet(SKEY.CARTS, []);
  const writeCarts = async (arr) => (Array.isArray(arr) && arr.length) ?
    storageSet(SKEY.CARTS, arr) :
    storageRemove(SKEY.CARTS);

  const readSelectedCart = async () => await storageGet(SKEY.CART_SELECT, '');
  const writeSelectedCart = async (id) => id ?
    storageSet(SKEY.CART_SELECT, id) :
    storageRemove(SKEY.CART_SELECT);

  /* ==== Limit ==== */
  async function updateNameHeaderCounter(count = null) {
    if (!nameHeaderTitle) return;
    const span = nameCountSpan || nameHeaderTitle.querySelector('#nameCount');
    if (!span) return;
    const current = count != null ? count : await getNameCount();
    span.textContent = `(${current})`;
  }

  async function updateAddrHeaderCounter(count = null) {
    if (!addrHeaderTitle) return;
    const span = addrCountSpan || addrHeaderTitle.querySelector('#addrCount');
    if (!span) return;
    const current = count != null ? count : await getAddrCount();
    span.textContent = `(${current})`;
  }

  async function updateCartHeaderCounter(count = null) {
    if (!cartHeaderTitle) return;
    const span = cartCountSpan || cartHeaderTitle.querySelector('#cartCount');
    if (!span) return;
    const current = count != null ? count : await getCartCount();
    span.textContent = `(${current})`;
  }

  async function getNameCount() {
    const arr = await readNames();
    return Array.isArray(arr) ? arr.length : 0;
  }

  async function getAddrCount() {
    const arr = await readAddresses();
    return Array.isArray(arr) ? arr.length : 0;
  }

  async function getCartCount() {
    const arr = await readCarts();
    return Array.isArray(arr) ? arr.length : 0;
  }

  /* ==== Bootstrap Toast ==== */
  const toastHostId = 'toastHost';

  function ensureToastHost() {
    if (!el(toastHostId)) {
      const div = document.createElement('div');
      div.id = toastHostId;
      div.className = 'toast-container position-fixed top-0 end-0 p-3';
      document.body.appendChild(div);
    }
  }

  function showToast(title, msg, variant = 'primary') {
    ensureToastHost();
    const host = el(toastHostId);
    const wrap = document.createElement('div');
    wrap.className = 'toast text-bg-' + (variant === 'dark-soft' ? 'dark' : variant) + ' border-0';
    wrap.role = 'alert';
    wrap.ariaLive = 'assertive';
    wrap.ariaAtomic = 'true';
    wrap.innerHTML = `
      <div class="toast-header bg-transparent border-0 text-white-50">
        <i class="fa-solid ${variant==='danger'?'fa-circle-exclamation':variant==='warning'?'fa-triangle-exclamation':variant==='success'?'fa-circle-check':'fa-circle-info'} me-2"></i>
        <strong class="me-auto">${escapeHtml(title || 'Bilgi')}</strong>
        <small>şimdi</small>
        <button type="button" class="btn-close btn-close-white ms-2" data-bs-dismiss="toast" aria-label="Kapat"></button>
      </div>
      <div class="toast-body">${escapeHtml(msg || '')}</div>`;
    host.appendChild(wrap);
    const t = new bootstrap.Toast(wrap, {
      delay: 3000
    });
    t.show();
    wrap.addEventListener('hidden.bs.toast', () => wrap.remove());
  }

  /* ==== Bootstrap Confirm (geri eklendi) ==== */
  let _confirmModal;
  let _confirmEl;
  let _prevFocus = null;

  const confirmDialog = ({
    title = 'Onay',
    message = 'Emin misiniz?',
    okText = 'Evet',
    cancelText = 'Vazgeç',
    variant = 'danger'
  } = {}) => {
    return new Promise((resolve) => {
      if (!_confirmModal) {
        _confirmEl = el('confirmModal');
        _confirmModal = new bootstrap.Modal(_confirmEl, {
          backdrop: 'static',
          keyboard: true
        });
        _confirmEl.addEventListener('shown.bs.modal', () => {
          _prevFocus = document.activeElement;
          el('confirmCancel')?.focus();
        });

        _confirmEl.addEventListener('hide.bs.modal', () => {
          if (_confirmEl.contains(document.activeElement)) {
            try {
              document.activeElement.blur();
            } catch {}
          }
        });

        _confirmEl.addEventListener('hidden.bs.modal', () => {
          _prevFocus?.focus?.();
        });
      }

      // Dinamik içerik/renkler
      el('confirmTitle').textContent = title;
      el('confirmMessage').textContent = message;

      const ok = el('confirmOk');
      const cancel = el('confirmCancel');

      ok.textContent = okText;
      cancel.textContent = cancelText;
      ok.classList.remove('btn-danger', 'btn-warning', 'btn-primary');
      ok.classList.add(variant === 'warning' ? 'btn-warning' :
        variant === 'primary' ? 'btn-primary' : 'btn-danger');

      const cleanup = () => {
        ok.onclick = null;
        cancel.onclick = null;
        try {
          document.activeElement?.blur();
        } catch {}
        _confirmModal.hide();
      };

      ok.onclick = () => {
        cleanup();
        resolve(true);
      };
      cancel.onclick = () => {
        cleanup();
        resolve(false);
      };

      _confirmModal.show();
    });
  };

  const AddressBook = {
    list: () => readAddresses(),
    getById: async (id) => (await readAddresses()).find(x => x.id === id) || null,
    buildPayload: async (idOrRecord) => {
      const rec = typeof idOrRecord === 'string' ?
        await AddressBook.getById(idOrRecord) :
        idOrRecord;
      return rec ? buildPayloadFromRecord(rec) : null;
    },
    export: () => exportAddresses(),
    import: (json) => importAddressesFromJson(json)
  };

  /* ==== UI Refs ==== */
  const root = el('appRoot');
  const blocker = el('appBlocker');
  let blockerPanelRef = blocker?.querySelector('.blocker-panel') || null;
  const textEl = el('blockerText');

  const selCurrentName = el('selCurrentName');
  const btnNewNameLink = el('btnNewNameLink');
  const noNameHint = el('noNameHint');

  const selCurrentAddress = el('selCurrentAddress');
  const btnNewAddressLink = el('btnNewAddressLink');
  const noAddrHint = el('noAddrHint');

  const selCurrentCart = el('selCurrentCart');
  const noCartHint = el('noCartHint');

  const modal = el('modal'),
    modalTitle = el('modalTitle');
  const inpToken = el('inpToken');
  const btnLogin = el('btnLogin');
  const btnRevealToken = el('btnRevealToken');
  const footForm = el('footForm');
  const btnSave = el('btnSave'),
    btnCancelForm = el('btnCancelForm');

  const viewNameManage = el('viewNameManage');
  const viewNameForm = el('viewNameForm');

  const btnNewNameTop = el('btnNewNameTop');
  const nameHeaderTitle = el('nameHeaderTitle');
  const nameCountSpan = el('nameCount');
  const btnExportNameTop = el('btnExportNameTop');
  const btnImportNameTop = el('btnImportNameTop');
  const fileImportNameTop = el('fileImportNameTop');

  const nameListWrap = el('nameListWrap'),
    nameList = el('nameList');

  const inpFirstName = el('inpFirstName');
  const inpLastName = el('inpLastName');

  const viewAddrManage = el('viewAddrManage');
  const viewAddrForm = el('viewAddrForm');

  const btnNewAddrTop = el('btnNewAddrTop');
  const addrHeaderTitle = el('addrHeaderTitle');
  const addrCountSpan = el('addrCount');
  const btnExportAddrTop = el('btnExportAddrTop');
  const btnImportAddrTop = el('btnImportAddrTop');
  const fileImportAddrTop = el('fileImportAddrTop');

  const addrListWrap = el('addrListWrap'),
    addrList = el('addrList');

  const infoLine1 = el('infoLine1'),
    infoLine2 = el('infoLine2');
  const badgeMissingStreet = el('badgeMissingStreet'),
    badgeMissingNumber = el('badgeMissingNumber'),
    badgeOk = el('badgeOk');
  const searchInput = el('searchInput'),
    searchClear = el('searchClear'),
    suggestions = el('suggestions');
  const mapFrame = el('mapFrame');
  const fieldNumber = el('fieldNumber'),
    inpNumber = el('inpNumber');
  const inpBuilding = el('inpBuilding'),
    inpFlat = el('inpFlat'),
    inpFloor = el('inpFloor'),
    inpCompany = el('inpCompany');
  const selCountryCode = el('selCountryCode'),
    inpPhoneLocal = el('inpPhoneLocal');
  const inpNote = el('inpNote');
  const pills = el('labelPills'),
    fieldCustomLabel = el('fieldCustomLabel'),
    inpCustomLabel = el('inpCustomLabel');

  const viewCartManage = el('viewCartManage');
  const viewCartForm = el('viewCartForm');

  const cartHeaderTitle = el('cartHeaderTitle');
  const cartCountSpan = el('cartCount');
  const btnExportCartTop = el('btnExportCartTop');
  const btnImportCartTop = el('btnImportCartTop');
  const fileImportCartTop = el('fileImportCartTop');

  const cartListWrap = el('cartListWrap'),
    cartList = el('cartList');

  const cartVendor = el('cartInspectVendor');
  const cartBody = el('cartInspectBody');

  /* ==== State ==== */
  let viewMode = 'nameManage';
  let mapCenter = {
    ...DEFAULT_CENTER
  };
  let formContext = 'name',
    editingNameId = null,
    editingAddrId = null,
    editingCartId = null,
    currentAddr = null,
    missingStreet = false,
    missingNumber = false,
    selectedLabel = 'Ev';
  let isMapReady = false;
  let pendingCenter = null;
  let skipInitialMapEvent = false;

  /* ==== Görünüm ==== */
  const showView = async (mode) => {
    viewMode = mode;
    [viewNameManage, viewNameForm, viewAddrManage, viewAddrForm, viewCartManage, viewCartForm].forEach(n => hide(n));

    if (mode === 'nameForm') {
      formContext = 'name';
      show(viewNameForm);
      show(footForm);
      modalTitle.textContent = editingNameId ? 'İsmi Düzenle' : 'İsim Ekle';
    } else if (mode === 'nameManage') {
      formContext = 'name';
      show(viewNameManage);
      hide(footForm);
      modalTitle.textContent = 'İsim Yönetimi';
      await renderNameList();
    } else if (mode === 'addrForm') {
      formContext = 'address';
      show(viewAddrForm);
      show(footForm);
      modalTitle.textContent = editingAddrId ? 'Adresi Düzenle' : 'Adres Ekle';
    } else if (mode === 'addrManage') {
      formContext = 'address';
      show(viewAddrManage);
      hide(footForm);
      modalTitle.textContent = 'Adres Yönetimi';
      await renderAddressList();
    } else if (mode === 'cartForm') {
      formContext = 'cart';
      show(viewCartForm);
      show(footForm);
      modalTitle.textContent = editingCartId ? 'Sepeti İncele' : '';
    } else if (mode === 'cartManage') {
      formContext = 'cart';
      show(viewCartManage);
      hide(footForm);
      modalTitle.textContent = 'Sepet Yönetimi';
      await renderCartList();
    }
  };

  /* ==== Map köprüsü ==== */
  const sendToFrame = (type, payload = {}) => {
    if (!mapFrame?.contentWindow) return;
    mapFrame.contentWindow.postMessage({
      type,
      ...payload
    }, IFRAME_ORIGIN);
  };

  const centerMap = (lat, lng, zoom = 18) => {
    const payload = {
      lat,
      lng,
      zoom
    };
    pendingCenter = payload;
    if (isMapReady) {
      sendToFrame('setLocation', payload);
      pendingCenter = null;
    }
  };

  window.addEventListener('message', (e) => {
    if (IFRAME_ORIGIN !== '*' && e.origin !== IFRAME_ORIGIN) return;
    const d = e.data || {};

    if (d.type === 'mapReady') {
      console.log('Harita hazır');
      isMapReady = true;
      if (pendingCenter) {
        console.log('Bekleyen konuma git:', pendingCenter);
        sendToFrame('setLocation', pendingCenter);
        pendingCenter = null;
      }
      return;
    }

    if (d.type === 'locationChanged') {
      console.log('Harita konumu değişti:', d);
      if (d.source === 'programmatic') return;
      if (skipInitialMapEvent) {
        skipInitialMapEvent = false;
        return;
      }
      console.log('Yeni konum:', d.lat, d.lng);

      mapCenter = {
        lat: d.lat,
        lng: d.lng
      };
      if (viewMode === 'addrForm') reverseLookup(d.lat, d.lng);
    }
  });

  /* ==== Badge/Header ==== */
  const setBadges = (mode) => {
    [badgeMissingStreet, badgeMissingNumber, badgeOk].forEach(hide);
    if (mode === 'missingStreet') show(badgeMissingStreet);
    else if (mode === 'missingNumber') show(badgeMissingNumber);
    else if (mode === 'ok') show(badgeOk);
  };
  const updateInfoHeader = () => {
    if (!currentAddr) {
      infoLine1.textContent = 'Seçim bekleniyor…';
      infoLine2.textContent = '';
      return;
    }
    infoLine1.textContent = (currentAddr.street || currentAddr.formatted || currentAddr.place_name || 'Seçim');
    const c2 = [
      currentAddr.number && `No: ${currentAddr.number}`,
      currentAddr.area, currentAddr.suburb, currentAddr.city, currentAddr.zipcode
    ].filter(Boolean).join(' • ');
    infoLine2.textContent = c2;
  };

  /* ==== API ==== */
  const api = async (endpoint, params) => {
    const qstr = new URLSearchParams(params).toString();
    const url = `https://ekonomikdoy.org/geo_proxy.php?endpoint=${encodeURIComponent(endpoint)}&${qstr}`;
    const r = await fetch(url);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  };

  /* ==== Autocomplete ==== */
  const doAutocomplete = debounce(async () => {
    const q = (searchInput?.value || '').trim();
    if (!q || !suggestions) {
      if (suggestions) suggestions.style.display = 'none';
      return;
    }
    try {
      const js = await api('autocomplete', {
        query: q,
        country: 'tr',
        language: 'tr_TR'
      });
      const rows = (js?.data || []).map(x => x.address);
      renderSuggestions(rows);
    } catch (e) {
      console.error(e);
      suggestions.innerHTML = '<div class="suggestion">Arama hatası</div>';
      suggestions.style.display = 'block';
      showToast('Arama Hatası', 'Adres arama sırasında bir sorun oluştu.', 'warning');
    }
  }, 250);

  const renderSuggestions = (rows) => {
    suggestions.innerHTML = '';
    rows.forEach(a => {
      const div = document.createElement('div');
      div.className = 'suggestion';
      div.innerHTML = `
        <div class="suggestion-main">${escapeHtml(a.main_text || a.formatted_address || '')}</div>
        <div class="suggestion-sec">${escapeHtml(a.secondary_text || '')}</div>`;
      div.onclick = () => pickSuggestion(a.id);
      suggestions.appendChild(div);
    });
    suggestions.style.display = rows.length ? 'block' : 'none';
  };

  const pickSuggestion = async (query_id) => {
    if (!query_id) return;
    suggestions.style.display = 'none';
    try {
      const js = await api('details', {
        query_id,
        language: 'tr_TR'
      });
      const first = js?.data?. [0]?.address || null;
      const provider = js?.meta?.provider || 'unknown';
      currentAddr = normalizeAddress(first, provider);
      updateInfoHeader();
      evaluateCompleteness(currentAddr);
      validateAll();
      if (currentAddr?.lat && currentAddr?.lng) {
        mapCenter = {
          lat: currentAddr.lat,
          lng: currentAddr.lng
        };
        centerMap(mapCenter.lat, mapCenter.lng, 18);
      }
    } catch (e) {
      console.error(e);
      showToast('Detay Hatası', 'Adres detayları alınamadı.', 'danger');
    }
  };

  const reverseLookup = async (lat, lng) => {
    try {
      const js = await api('reverse', {
        lat,
        lng,
        language: 'tr_TR'
      });
      const first = js?.data?. [0]?.address || null;
      const provider = js?.meta?.provider || 'unknown';
      currentAddr = normalizeAddress(first, provider);
      updateInfoHeader();
      evaluateCompleteness(currentAddr);
      validateAll();
    } catch (e) {
      console.error(e);
      infoLine2.textContent = 'Ters geocode başarısız';
      showToast('Harita', 'Konumdan adres çözümlenemedi.', 'warning');
    }
  };

  const normalizeAddress = (a, provider = 'unknown') => {
    if (!a) return null;
    return {
      provider,
      id: a.id,
      formatted: a.formatted_address,
      street: a.street || '',
      number: a.number || '',
      zipcode: a.zipcode || '',
      city: a.city || a.state || '',
      country: a.country || '',
      country_code: a.country_code || '',
      suburb: a.suburb || '',
      area: a.area || '',
      place_name: a.place_name || '',
      platform_city_id: a.platform_city_id || '',
      lat: a.latitude,
      lng: a.longitude
    };
  };

  const evaluateCompleteness = (a) => {
    if (!a) {
      setBadges('idle');
      hide(fieldNumber);
      return;
    }
    const hasStreet = !!(a.street && a.street.trim());
    const hasNumber = !!(a.number && a.number.trim());
    missingStreet = !hasStreet;
    missingNumber = hasStreet && !hasNumber;

    if (missingStreet) {
      setBadges('missingStreet');
      hide(fieldNumber);
      infoLine2.textContent = 'Sokak bulunamadı — haritayı sürükleyerek bir sokak merkezleyin';
    } else if (missingNumber) {
      setBadges('missingNumber');
      show(fieldNumber);
    } else {
      setBadges('ok');
      hide(fieldNumber);
    }
  };

  /* ==== Pills ==== */
  pills?.addEventListener('click', (e) => {
    const b = e.target.closest('.pill');
    if (!b) return;
    selectedLabel = b.dataset.label || 'Ev';
    syncPills();
  });
  const syncPills = () => {
    pills?.querySelectorAll('.pill').forEach(p => p.classList.toggle('active', p.dataset.label === selectedLabel));
    fieldCustomLabel?.classList.toggle('d-none', selectedLabel !== 'Diğer');
    if (selectedLabel !== 'Diğer') inpCustomLabel.value = '';
  };

  /* ==== Telefon doğrulama ==== */
  const applyPhoneStyle = (s) => {
    inpPhoneLocal?.classList.remove('input-valid', 'input-invalid');
    if (s === 'valid') inpPhoneLocal?.classList.add('input-valid');
    if (s === 'invalid') inpPhoneLocal?.classList.add('input-invalid');
  };

  const validatePhone = () => {
    if (!selCountryCode || !inpPhoneLocal) return false;
    const cc = selCountryCode.value || '+90';
    const {
      min,
      max
    } = phoneBoundsFor(cc);

    const local = digits(inpPhoneLocal.value);
    const ok = local.length >= min && local.length <= max;

    applyPhoneStyle(ok ? 'valid' : 'invalid');
    return ok;
  };

  inpPhoneLocal?.addEventListener('input', () => {
    validatePhone();
    validateAll();
  });

  /* ==== Validate ==== */
  const validateAll = () => {
    if (formContext === 'name') {
      const fnOk = markField(inpFirstName, numberIsSufficient(inpFirstName?.value));
      const lnOk = markField(inpLastName, numberIsSufficient(inpLastName?.value));

      btnSave.disabled = !(fnOk && lnOk);
      btnSave.style.display = '';
      return;
    }

    const needNumber = (!!currentAddr?.street && (!currentAddr?.number || missingNumber));
    fieldNumber?.classList.toggle('d-none', !needNumber);

    // Adres seçiminde sokak şartı
    const streetOk = !!currentAddr?.street;

    // Sokak numarası gerekiyorsa
    const manualOk = needNumber ? markField(inpNumber, numberIsSufficient(inpNumber?.value)) : true;

    // Zorunlu alanlar
    const buildingOk = markField(inpBuilding, numberIsSufficient(inpBuilding?.value));
    const flatOk = markField(inpFlat, atLeastOne(inpFlat?.value));
    const floorOk = markField(inpFloor, atLeastOne(inpFloor?.value));

    let companyOk = true;
    if ((inpCompany?.value || '').trim().length > 0) {
      companyOk = markField(inpCompany, numberIsSufficient(inpCompany?.value));
    } else {
      inpCompany?.classList.remove('input-valid', 'input-invalid');
    }

    // Telefon (zorunlu + kurala uygun)
    const phoneOk = validatePhone();

    let noteOk = true;
    if ((inpNote?.value || '').trim().length > 0) {
      noteOk = markField(inpNote, numberIsSufficient(inpNote?.value));
    } else {
      inpNote?.classList.remove('input-valid', 'input-invalid');
    }

    btnSave.disabled = !(streetOk && manualOk && buildingOk && flatOk && floorOk && companyOk && phoneOk && noteOk);
    btnSave.style.display = '';
  };

  [inpFirstName, inpLastName].forEach(i => i?.addEventListener('input', validateAll));

  [inpNumber, inpBuilding, inpFlat, inpFloor, inpCompany, inpNote].forEach(i => i?.addEventListener('input', validateAll));
  selCountryCode?.addEventListener('change', () => {
    updatePhoneConstraints();
    validateAll();
  });

  /* ==== Form reset (İstanbul) ==== */
  const clearNameForm = () => {
    if (inpFirstName) inpFirstName.value = '';
    if (inpLastName) inpLastName.value = '';
    validateAll();
  };

  const clearAddrForm = (opts = {
    keepMap: false
  }) => {
    const {
      keepMap
    } = opts;

    if (!keepMap) {
      currentAddr = null;
    }

    [searchInput, inpNumber, inpBuilding, inpFlat, inpFloor, inpCompany, inpPhoneLocal, inpNote, inpCustomLabel]
    .forEach(i => {
      if (i) i.value = '';
    });

    if (suggestions) {
      suggestions.innerHTML = '';
      suggestions.style.display = 'none';
      syncSearchClear();
    }

    selectedLabel = 'Ev'; // etiket reset
    syncPills();

    setBadges('idle');
    updateInfoHeader();
    populateCountryCodes();
    validateAll();

    if (!keepMap) {
      mapCenter = {
        ...DEFAULT_CENTER
      };
      centerMap(mapCenter.lat, mapCenter.lng, 18);
    }
  };

  function clearCartForm() {
    if (cartVendor) cartVendor.textContent = '';
    if (cartBody) cartBody.innerHTML = '';
    if (btnSave) {
      btnSave.disabled = true;
      btnSave.style.display = 'none';
    }
  }

  /* ==== Modal akışı ==== */
  const openNameManager = async () => {
    editingNameId = null;
    await showView('nameManage');
    modal?.classList.remove('d-none');
  };

  const openNameAdd = async () => {
    editingNameId = null;
    clearNameForm();
    await showView('nameForm');
    modal?.classList.remove('d-none');
  };

  const openAddrManager = async () => {
    editingAddrId = null;
    await showView('addrManage');
    modal?.classList.remove('d-none');
  };

  const openAddrAdd = async () => {
    editingAddrId = null;
    skipInitialMapEvent = true;
    clearAddrForm();
    await showView('addrForm');
    modal?.classList.remove('d-none');
  };

  const openCartManager = async () => {
    editingCartId = null;
    await showView('cartManage');
    modal?.classList.remove('d-none');
  };

  const closeModal = () => {
    modal?.classList.add('d-none');
    editingNameId = null;
    editingAddrId = null;
    editingCartId = null;
    inpPhoneLocal?.classList.remove('input-valid', 'input-invalid');
  };

  document.querySelectorAll('[data-close]')?.forEach(n => n.addEventListener('click', closeModal));
  btnCancelForm?.addEventListener('click', async () => {
    if (formContext === 'name') await showView('nameManage');
    else if (formContext === 'address') await showView('addrManage');
    else await showView('cartManage');
  });
  el('btnOpenNameManager')?.addEventListener('click', openNameManager);
  el('btnOpenAddressManager')?.addEventListener('click', openAddrManager);
  el('btnOpenCartManager')?.addEventListener('click', openCartManager);
  btnNewNameLink?.addEventListener('click', openNameAdd);
  btnNewAddressLink?.addEventListener('click', openAddrAdd);

  /* ==== Yönetim toolbar ==== */
  btnNewNameTop?.addEventListener('click', openNameAdd);
  btnExportNameTop?.addEventListener('click', () => {
    exportNames();
  });
  btnImportNameTop?.addEventListener('click', () => fileImportNameTop?.click());
  fileImportNameTop?.addEventListener('change', () => {
    const f = fileImportNameTop.files?. [0];
    if (!f) return;
    const r = new FileReader();
    r.onload = async () => {
      try {
        const json = JSON.parse(r.result);
        const {
          added,
          skipped,
          skippedByLimit
        } = await importNamesFromJson(json);
        let msg = `${added} yeni, ${skipped} atlandı.`;
        if (skippedByLimit) msg += ` (Limit nedeniyle ${skippedByLimit} atlandı)`;
        showToast('İçe Aktarım', msg, skippedByLimit ? 'warning' : 'success');
      } catch {
        showToast('İçe Aktarım', 'Geçersiz veya bozuk JSON.', 'danger');
      } finally {
        fileImportNameTop.value = '';
      }
    };
    r.readAsText(f);
  });

  btnNewAddrTop?.addEventListener('click', openAddrAdd);
  btnExportAddrTop?.addEventListener('click', () => {
    exportAddresses();
  });
  btnImportAddrTop?.addEventListener('click', () => fileImportAddrTop?.click());
  fileImportAddrTop?.addEventListener('change', () => {
    const f = fileImportAddrTop.files?. [0];
    if (!f) return;
    const r = new FileReader();
    r.onload = async () => {
      try {
        const json = JSON.parse(r.result);
        const {
          added,
          skipped,
          skippedByLimit
        } = await importAddressesFromJson(json);
        let msg = `${added} yeni, ${skipped} atlandı.`;
        if (skippedByLimit) msg += ` (Limit nedeniyle ${skippedByLimit} atlandı)`;
        showToast('İçe Aktarım', msg, skippedByLimit ? 'warning' : 'success');
      } catch {
        showToast('İçe Aktarım', 'Geçersiz veya bozuk JSON.', 'danger');
      } finally {
        fileImportAddrTop.value = '';
      }
    };
    r.readAsText(f);
  });

  btnExportCartTop?.addEventListener('click', () => {
    exportCarts();
  });
  btnImportCartTop?.addEventListener('click', () => fileImportCartTop?.click());
  fileImportCartTop?.addEventListener('change', () => {
    const f = fileImportCartTop.files?. [0];
    if (!f) return;
    const r = new FileReader();
    r.onload = async () => {
      try {
        const json = JSON.parse(r.result);
        const {
          added,
          skipped,
          skippedByLimit
        } = await importCartsFromJson(json);
        let msg = `${added} yeni, ${skipped} atlandı.`;
        if (skippedByLimit) msg += ` (Limit nedeniyle ${skippedByLimit} atlandı)`;
        showToast('İçe Aktarım', msg, skippedByLimit ? 'warning' : 'success');
      } catch {
        showToast('İçe Aktarım', 'Geçersiz veya bozuk JSON.', 'danger');
      } finally {
        fileImportCartTop.value = '';
      }
    };
    r.readAsText(f);
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !modal?.classList.contains('d-none')) closeModal();
  });

  modal?.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  /* ==== Yönetim listesi ==== */
  async function renderNameList() {
    if (!nameList) return;
    const arr = await readNames();
    const selectedId = await readSelectedName() || '';
    nameList.innerHTML = '';
    nameListWrap?.classList.remove('d-none');

    if (!arr.length) {
      const empty = document.createElement('div');
      empty.className = 'alert alert-dark-soft';
      empty.innerHTML = 'Kayıtlı isminiz yok. <b>Yeni İsim Ekle</b> ile başlayın.';
      nameList.append(empty);
      await updateNameHeaderCounter(arr.length);
      return;
    }

    const sorted = [...arr].sort((a, b) => (a.id === selectedId ? -1 : b.id === selectedId ? 1 : 0));

    sorted.forEach(rec => {
      const fullName = `${rec.first || ''} ${rec.last || ''}`.trim();
      const row = document.createElement('div');
      row.className = 'custom-card d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2';

      const info = document.createElement('div');
      info.innerHTML = `<div class="custom-title">${escapeHtml(fullName || rec.label || 'İsim')}</div>`;

      const actions = document.createElement('div');
      actions.className = 'd-flex flex-wrap align-items-center gap-2';

      const makeDel = () => {
        const b = document.createElement('button');
        b.className = 'btn btn-outline-secondary btn-sm';
        b.innerHTML = '<i class="fa-solid fa-trash"></i> Sil';
        b.onclick = async () => {
          const ok = await confirmDialog({
            title: 'İsmi Sil',
            message: 'Bu ismi silmek istiyor musunuz?',
            okText: 'Sil',
            variant: 'danger'
          });
          if (!ok) return;

          const all = await readNames();
          const rest = all.filter(x => x.id !== rec.id);
          await writeNames(rest);

          const selectedNow = await readSelectedName();
          if (selectedNow === rec.id) {
            await writeSelectedName('');
          }

          await renderNameList();
          await populateNameDropdown();
          showToast('Silindi', 'İsim kaldırıldı.', 'success');
        };
        return b;
      };

      const editBtn = document.createElement('button');
      editBtn.className = 'btn btn-primary btn-sm';
      editBtn.innerHTML = '<i class="fa-solid fa-pen-to-square"></i> Düzenle';
      editBtn.onclick = () => openNameEdit(rec.id);

      if (rec.id === selectedId) {
        const badge = document.createElement('span');
        badge.className = 'badge text-bg-success';
        badge.innerHTML = '<i class="fa-solid fa-check me-1"></i> Kullanılıyor';
        actions.appendChild(badge);

        actions.append(editBtn, makeDel());
      } else {
        const useBtn = document.createElement('button');
        useBtn.className = 'btn btn-outline-secondary btn-sm';
        useBtn.innerHTML = '<i class="fa-solid fa-check"></i> Kullan';
        useBtn.onclick = async () => {
          await writeSelectedName(rec.id);
          await renderNameList();
          await populateNameDropdown();
          showToast('Seçildi', 'Bu isim kullanılacak.', 'primary');
        };

        actions.append(useBtn, editBtn, makeDel());
      }

      row.append(info, actions);
      nameList.append(row);
    });

    await updateNameHeaderCounter(arr.length);
  };

  async function renderAddressList() {
    if (!addrList) return;
    const arr = await readAddresses();
    const selectedId = await readSelectedAddress() || '';
    addrList.innerHTML = '';
    addrListWrap?.classList.remove('d-none');

    if (!arr.length) {
      const empty = document.createElement('div');
      empty.className = 'alert alert-dark-soft';
      empty.innerHTML = 'Kayıtlı adresiniz yok. <b>Yeni Adres Ekle</b> ile başlayın.';
      addrList.append(empty);
      await updateAddrHeaderCounter(arr.length);
      return;
    }

    const sorted = [...arr].sort((a, b) => (a.id === selectedId ? -1 : b.id === selectedId ? 1 : 0));

    sorted.forEach(rec => {
      const a = rec.currentAddr || {};
      const row = document.createElement('div');
      row.className = 'custom-card d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2';

      const info = document.createElement('div');
      info.innerHTML = `<div class="custom-title">${escapeHtml(rec.label || 'Adres')}</div>
        <div class="custom-sub">${escapeHtml([a.street, a.number, a.area, a.city].filter(Boolean).join(', '))}</div>`;

      const actions = document.createElement('div');
      actions.className = 'd-flex flex-wrap align-items-center gap-2';

      const makeDel = () => {
        const b = document.createElement('button');
        b.className = 'btn btn-outline-secondary btn-sm';
        b.innerHTML = '<i class="fa-solid fa-trash"></i> Sil';
        b.onclick = async () => {
          const ok = await confirmDialog({
            title: 'Adresi Sil',
            message: 'Bu adresi silmek istiyor musunuz?',
            okText: 'Sil',
            variant: 'danger'
          });
          if (!ok) return;

          const all = await readAddresses();
          const rest = all.filter(x => x.id !== rec.id);
          await writeAddresses(rest);

          const selectedNow = await readSelectedAddress();
          if (selectedNow === rec.id) {
            await writeSelectedAddress('');
          }

          await renderAddressList();
          await populateAddressDropdown();
          showToast('Silindi', 'Adres kaldırıldı.', 'success');
        };
        return b;
      };

      const editBtn = document.createElement('button');
      editBtn.className = 'btn btn-primary btn-sm';
      editBtn.innerHTML = '<i class="fa-solid fa-pen-to-square"></i> Düzenle';
      editBtn.onclick = () => openAddrEdit(rec.id);

      if (rec.id === selectedId) {
        const badge = document.createElement('span');
        badge.className = 'badge text-bg-success';
        badge.innerHTML = '<i class="fa-solid fa-check me-1"></i> Kullanılıyor';
        actions.appendChild(badge);

        actions.append(editBtn, makeDel());
      } else {
        const useBtn = document.createElement('button');
        useBtn.className = 'btn btn-outline-secondary btn-sm';
        useBtn.innerHTML = '<i class="fa-solid fa-check"></i> Kullan';
        useBtn.onclick = async () => {
          await writeSelectedAddress(rec.id);
          await renderAddressList();
          await populateAddressDropdown();
          showToast('Seçildi', 'Bu adres kullanılacak.', 'primary');
        };

        actions.append(useBtn, editBtn, makeDel());
      }

      row.append(info, actions);
      addrList.append(row);
    });

    await updateAddrHeaderCounter(arr.length);
  };

  async function renderCartList() {
    if (!cartList) return;
    const arr = await readCarts();
    const selectedId = await readSelectedCart() || '';
    cartList.innerHTML = '';
    cartListWrap?.classList.remove('d-none');

    if (!arr.length) {
      const empty = document.createElement('div');
      empty.className = 'alert alert-dark-soft';
      empty.innerHTML = 'Kayıtlı sepetiniz yok.';
      cartList.append(empty);
      await updateCartHeaderCounter(arr.length);
      return;
    }

    const sorted = [...arr].sort((a, b) => (a.id === selectedId ? -1 : b.id === selectedId ? 1 : 0));

    sorted.forEach(rec => {
      const cnt = cartEntryCount(rec);
      const name = `${rec.name || ''} (${cnt})`.trim();
      const row = document.createElement('div');
      row.className = 'custom-card d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2';

      const info = document.createElement('div');
      info.innerHTML = `<div class="custom-title">${escapeHtml(name || 'Sepet')}</div>`;

      const actions = document.createElement('div');
      actions.className = 'd-flex flex-wrap align-items-center gap-2';

      const makeDel = () => {
        const b = document.createElement('button');
        b.className = 'btn btn-outline-secondary btn-sm';
        b.innerHTML = '<i class="fa-solid fa-trash"></i> Sil';
        b.onclick = async () => {
          const ok = await confirmDialog({
            title: 'Sepeti Sil',
            message: 'Bu sepeti silmek istiyor musunuz?',
            okText: 'Sil',
            variant: 'danger'
          });
          if (!ok) return;

          const all = await readCarts();
          const rest = all.filter(x => x.id !== rec.id);
          await writeCarts(rest);

          const selectedNow = await readSelectedCart();
          if (selectedNow === rec.id) {
            await writeSelectedCart('');
          }

          await renderCartList();
          await populateCartDropdown();
          showToast('Silindi', 'Sepet kaldırıldı.', 'success');
        };
        return b;
      };

      const viewBtn = document.createElement('button');
      viewBtn.className = 'btn btn-primary btn-sm';
      viewBtn.innerHTML = '<i class="fa-solid fa-eye"></i> İncele';
      viewBtn.onclick = () => openCartView(rec.id);

      if (rec.id === selectedId) {
        const badge = document.createElement('span');
        badge.className = 'badge text-bg-success';
        badge.innerHTML = '<i class="fa-solid fa-check me-1"></i> Kullanılıyor';
        actions.appendChild(badge);

        actions.append(viewBtn, makeDel());
      } else {
        const useBtn = document.createElement('button');
        useBtn.className = 'btn btn-outline-secondary btn-sm';
        useBtn.innerHTML = '<i class="fa-solid fa-check"></i> Kullan';
        useBtn.onclick = async () => {
          await writeSelectedCart(rec.id);
          await renderCartList();
          await populateCartDropdown();
          showToast('Seçildi', 'Bu sepet kullanılacak.', 'primary');
        };

        actions.append(useBtn, viewBtn, makeDel());
      }

      row.append(info, actions);
      cartList.append(row);
    });

    await updateCartHeaderCounter(arr.length);
  };

  /* ==== Kaydet ==== */
  btnSave?.addEventListener('click', async () => {
    if (formContext === 'name') {
      const first = (inpFirstName?.value || '').trim();
      const last = (inpLastName?.value || '').trim();
      if (!first || !last) {
        validateAll();
        return;
      }

      const arr = await readNames();
      const existing = editingNameId ? arr.find(a => a.id === editingNameId) : null;

      const createdAt = existing?.created_at || new Date().toISOString();
      const updatedAt = new Date().toISOString();

      const rec = {
        id: editingNameId || ('name:' + Date.now()),
        first,
        last,
        label: `${first} ${last}`,
        created_at: createdAt,
        updated_at: updatedAt
      };

      if (existing) arr[arr.findIndex(a => a.id === editingNameId)] = rec;
      else arr.unshift(rec);

      await storageSetMany({
        [SKEY.NAMES]: arr,
        [SKEY.NAME_SELECT]: rec.id
      });

      showToast('Kaydedildi', 'İsim kaydedildi ve seçildi.', 'success');
      editingNameId = null;
      await showView('nameManage');
      await renderNameList();
      await populateNameDropdown();
      await updateNameHeaderCounter();
      return;
    }

    if (!currentAddr?.street) {
      showToast('Eksik Bilgi', 'Lütfen sokak içeren bir adres seçin.', 'warning');
      return;
    }
    const finalNumber = (missingNumber || !currentAddr.number) ? (inpNumber?.value || '').trim() : (currentAddr.number || '').trim();
    const {
      label,
      label_key
    } = makeLabelPair(selectedLabel, inpCustomLabel?.value);

    const cc = selCountryCode?.value || '';
    const localDigits = digits(inpPhoneLocal?.value || '');
    const phoneE164 = localDigits ? (cc + localDigits) : '';

    const snap = clone(currentAddr) || {};

    const arr = await readAddresses();
    const existing = editingAddrId ? arr.find(a => a.id === editingAddrId) : null;

    const formId = existing?.form_id || genFormId();
    const createdAt = existing?.created_at || new Date().toISOString();
    const updatedAt = new Date().toISOString();

    const rec = {
      id: editingAddrId || (snap.id + ':' + Date.now()),
      provider_id: snap.id,
      label,
      label_key,
      formatted: snap.formatted || `${snap.street} ${finalNumber || ''}`.trim(),
      form_id: formId,

      number: (inpNumber?.value || '').trim(),
      building: (inpBuilding?.value || '').trim(),
      flat: (inpFlat?.value || '').trim(),
      floor: (inpFloor?.value || '').trim(),
      company: (inpCompany?.value || '').trim(),
      phone: phoneE164,
      phone_cc: cc,
      phone_local: localDigits,
      note: (inpNote?.value || '').trim(),

      currentAddr: snap,
      created_at: createdAt,
      updated_at: updatedAt
    };

    if (existing) arr[arr.findIndex(a => a.id === editingAddrId)] = rec;
    else arr.unshift(rec);

    await storageSetMany({
      [SKEY.ADDR]: arr,
      [SKEY.ADDR_SELECT]: rec.id
    });

    showToast('Kaydedildi', 'Adres başarıyla kaydedildi ve seçildi.', 'success');
    editingAddrId = null;
    await showView('addrManage');
    await renderAddressList();
    await populateAddressDropdown();
    await updateAddrHeaderCounter();
  });

  /* ==== Payload ==== */
  const buildPayloadFromRecord = (rec) => {
    const a = rec.currentAddr || {};
    const phone = rec.phone || ((rec.phone_cc || '') + (rec.phone_local || ''));
    const payloadLabel = (() => {
      const k = rec.label_key || '';
      if (k && k !== 'Other') return k;
      return rec.label || k || '';
    })();

    return {
      city_id: a.platform_city_id || '',
      city: a.city || '',
      city_name: a.city || '',
      areas: a.area || '',
      address_line1: a.street || '',
      address_line2: a.number || rec.number || '',
      address_line3: a.area || '',
      address_line4: a.suburb || '',
      building: rec.building || '',
      entrance: rec.flat || '',
      floor: rec.floor || '',
      postcode: a.zipcode || '',
      meta: JSON.stringify({
        provider: a.provider || 'unknown'
      }),
      company: rec.company || '',
      longitude: a.lng ?? null,
      latitude: a.lat ?? null,
      delivery_instructions: rec.note || '',
      label: payloadLabel,
      formatted_customer_address: `${a.area}, ${a.street}, ${a.number || rec.number || ''}, ${a.zipcode} ${a.suburb} ${a.city}`,
      form_id: rec.form_id || genFormId(),
      country_code: a.country_code || '',
      location_type: 'polygon',
      object_type: 'new address',
      place_id: a.id || '',
      type: getTypeFromRecord(rec),
      phone_number: phone || '',
      street: a.street || ''
    };
  };

  /* ==== Edit ==== */
  const openNameEdit = async (id) => {
    const arr = await readNames();
    const r = arr.find(x => x.id === id);
    if (!r) return;
    editingNameId = id;

    inpFirstName.value = r.first || '';
    inpLastName.value = r.last || '';

    validateAll();
    await showView('nameForm');
  };

  const openAddrEdit = async (id) => {
    const arr = await readAddresses();
    const r = arr.find(x => x.id === id);
    if (!r) return;
    editingAddrId = id;

    const fromRec = r.currentAddr || null;
    currentAddr = fromRec ? clone(fromRec) : null;
    skipInitialMapEvent = true;

    clearAddrForm({
      keepMap: true
    });

    if (currentAddr) {
      /*if (!currentAddr.street) {
        const oldStreet = r.currentAddr?.street || '';
        if (oldStreet) currentAddr.street = oldStreet;
        if (searchInput) searchInput.value = oldStreet || r.formatted || '';
      }*/
      if (!currentAddr.number) {
        if (inpNumber) inpNumber.value = r.number;
      }
      updateInfoHeader();
      const tgt = {
        lat: currentAddr.lat ?? DEFAULT_CENTER.lat,
        lng: currentAddr.lng ?? DEFAULT_CENTER.lng,
        zoom: 18
      };
      centerMap(tgt.lat, tgt.lng, tgt.zoom);
      pendingCenter = tgt;
    }

    if (inpBuilding) inpBuilding.value = r.building || '';
    if (inpFlat) inpFlat.value = r.flat || '';
    if (inpFloor) inpFloor.value = r.floor || '';
    if (inpCompany) inpCompany.value = r.company || '';
    if (inpNote) inpNote.value = r.note || '';

    if (r.phone_cc) setSelectValue(selCountryCode, r.phone_cc);
    else setSelectValue(selCountryCode, '+90');
    if (r.phone_local) inpPhoneLocal.value = r.phone_local;
    else if (r.phone?.startsWith('+')) {
      const m = r.phone.match(/^(\+\d{1,3})(\d+)$/);
      if (m) {
        setSelectValue(selCountryCode, m[1]);
        inpPhoneLocal.value = m[2];
      }
    }

    const ui = deriveUiFromRecord(r);
    selectedLabel = ui.pill;
    syncPills();
    if (selectedLabel === 'Diğer') {
      inpCustomLabel.value = ui.custom || '';
    }

    evaluateCompleteness(currentAddr);
    validateAll();
    await showView('addrForm');
  };

  /* ==== View ==== */
  const openCartView = async (id) => {
    const arr = await readCarts();
    const r = arr.find(x => x.id === id);
    if (!r) return;
    editingCartId = id;

    clearCartForm();

    const entries = Object.entries(r.carts || {});
    const totalVendors = entries.length;

    if (cartVendor) {
      cartVendor.textContent = `Toplam ${totalVendors} restoran`;
    }

    if (cartBody) {
      cartBody.innerHTML = '';
      if (!totalVendors) {
        cartBody.innerHTML = `<div class="text-muted">Bu listede kayıtlı restoran yok.</div>`;
      } else {
        entries
          .sort((a, b) => (b[1]?.lastInactive || 0) - (a[1]?.lastInactive || 0))
          .forEach(([vendor_code, entry]) => {
            const c = entry?.cart || entry;
            const v = c?.vendor_cart?. [0] || {};
            const vName = v?.vendorInfo?.name || vendor_code || 'Bilinmeyen';
            const items = Array.isArray(v?.products) ? v.products : [];
            const subtotal = (c?.subtotal ?? 0);

            const wrap = document.createElement('div');
            wrap.className = 'mb-3';

            const h = document.createElement('div');
            h.className = 'fw-semibold mb-1';
            h.textContent = `${vName} (${items.length} ürün)`;
            wrap.appendChild(h);

            const ul = document.createElement('ul');
            ul.className = 'mb-2';
            items.forEach(p => {
              const li = document.createElement('li');
              const name = p?.name || p?.title || 'Ürün';
              const qty = safeQty(p);
              li.textContent = (qty > 1) ? `${name} × ${qty}` : name;
              ul.appendChild(li);
            });
            if (!items.length) {
              const li = document.createElement('div');
              li.className = 'text-muted';
              li.textContent = 'Ürün yok';
              wrap.appendChild(li);
            } else {
              wrap.appendChild(ul);
            }

            const sub = document.createElement('div');
            sub.className = 'text-muted';
            sub.textContent = `Ara toplam: ${subtotal}`;
            wrap.appendChild(sub);

            const hr = document.createElement('hr');
            hr.className = 'my-2';

            cartBody.appendChild(wrap);
            cartBody.appendChild(hr);
          });
        if (cartBody.lastElementChild?.tagName === 'HR') cartBody.lastElementChild.remove();
      }
    }

    await showView('cartForm');
  };

  /* ==== Export / Import ==== */
  const exportNames = async () => {
    const arr = await readNames();
    if (!arr.length) {
      showToast('Dışa Aktarım', 'Kayıt yok.', 'warning');
      return;
    }
    showToast('Dışa Aktarıldı', 'JSON indiriliyor…', 'primary');
    const payload = {
      exported_at: new Date().toISOString(),
      names: arr
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ekonomik_doy_isimler_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  };

  function recordNameSignature(rec) {
    const f = (rec?.first || '').trim().toLowerCase();
    const l = (rec?.last || '').trim().toLowerCase();
    return `${f}|${l}`;
  }

  const importNamesFromJson = async (json) => {
    const arr = await readNames();
    const src = Array.isArray(json) ? json : Array.isArray(json?.names) ? json.names : [];
    const sigs = new Set(arr.map(recordNameSignature));

    let added = 0,
      skipped = 0,
      skippedByLimit = 0;

    for (const rec of src) {
      if (!rec || !rec.first || !rec.last) {
        skipped++;
        continue;
      }
      const sig = recordNameSignature(rec);
      if (sigs.has(sig)) {
        skipped++;
        continue;
      }

      let newId = rec.id || ('name:' + Date.now());
      if (arr.some(x => x.id === newId)) newId = newId + ':' + Math.random().toString(36).slice(2, 6);

      arr.push({
        ...rec,
        id: newId
      });
      added++;
      sigs.add(sig);
    }

    await writeNames(arr);
    await renderNameList();
    await populateNameDropdown();
    await updateNameHeaderCounter();

    return {
      added,
      skipped,
      skippedByLimit
    };
  };

  const exportAddresses = async () => {
    const arr = await readAddresses();
    if (!arr.length) {
      showToast('Dışa Aktarım', 'Kayıt yok.', 'warning');
      return;
    }
    showToast('Dışa Aktarıldı', 'JSON indiriliyor…', 'primary');
    const payload = {
      exported_at: new Date().toISOString(),
      addresses: arr
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ekonomik_doy_adresler_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  };

  const recordAddrSignature = (rec) => {
    const a = rec?.currentAddr || {};
    const pid = a.id || '';
    const ll = (a.lat ?? '') + ',' + (a.lng ?? '');
    const num = (a.number || '').trim();
    return [pid, ll, num].join('|');
  };

  const importAddressesFromJson = async (json) => {
    const arr = await readAddresses();
    const src = Array.isArray(json) ? json : Array.isArray(json?.addresses) ? json.addresses : [];
    const sigs = new Set(arr.map(recordAddrSignature));

    let added = 0,
      skipped = 0,
      skippedByLimit = 0;

    for (const rec of src) {
      if (!rec || !rec.currentAddr) {
        skipped++;
        continue;
      }
      const sig = recordAddrSignature(rec);
      if (sigs.has(sig)) {
        skipped++;
        continue;
      }

      let newId = rec.id || ((rec.currentAddr.id || 'addr') + ':' + Date.now());
      if (arr.some(x => x.id === newId)) newId = newId + ':' + Math.random().toString(36).slice(2, 6);

      arr.push({
        ...rec,
        id: newId
      });
      added++;
      sigs.add(sig);
    }

    await writeAddresses(arr);
    await renderAddressList();
    await populateAddressDropdown();
    await updateAddrHeaderCounter();

    return {
      added,
      skipped,
      skippedByLimit
    };
  };

  const exportCarts = async () => {
    const arr = await readCarts();
    if (!arr.length) {
      showToast('Dışa Aktarım', 'Kayıt yok.', 'warning');
      return;
    }
    showToast('Dışa Aktarıldı', 'JSON indiriliyor…', 'primary');
    const payload = {
      exported_at: new Date().toISOString(),
      carts: arr
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ekonomik_doy_sepetler_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  };

  function recordCartSignature(rec) {
    return String(rec?.name || '').trim().toLowerCase();
  }

  const importCartsFromJson = async (json) => {
    const arr = await readCarts();
    const src = Array.isArray(json) ? json : Array.isArray(json?.carts) ? json.carts : [];
    const sigs = new Set(arr.map(recordCartSignature));

    let added = 0,
      skipped = 0,
      skippedByLimit = 0;

    for (const rec of src) {
      if (!rec || !rec.name) {
        skipped++;
        continue;
      }
      const sig = recordCartSignature(rec);
      if (sigs.has(sig)) {
        skipped++;
        continue;
      }

      let newId = rec.id || ('cart:' + Date.now());
      if (arr.some(x => x.id === newId)) newId = newId + ':' + Math.random().toString(36).slice(2, 6);

      arr.push({
        ...rec,
        id: newId
      });
      added++;
      sigs.add(sig);
    }

    await writeCarts(arr);
    await renderCartList();
    await populateCartDropdown();
    await updateCartHeaderCounter();

    return {
      added,
      skipped,
      skippedByLimit
    };
  };

  /* ==== Dropdown ==== */
  async function populateNameDropdown() {
    if (!selCurrentName) return;
    const arr = await readNames();
    let selectedId = await readSelectedName() || '';

    if (selectedId && !arr.some(x => x.id === selectedId)) {
      await writeSelectedName('');
      selectedId = '';
    }

    selCurrentName.innerHTML = '';
    const opt0 = document.createElement('option');
    opt0.value = '';
    opt0.textContent = 'İsim seçin (opsiyonel)';
    selCurrentName.appendChild(opt0);

    if (!arr.length) {
      if (noNameHint) show(noNameHint);
      selCurrentName.value = '';
      selCurrentName.setAttribute('disabled', 'disabled');
      return;
    }
    if (noNameHint) hide(noNameHint);
    selCurrentName.removeAttribute('disabled');

    const sorted = [...arr].sort((a, b) => (a.id === selectedId ? -1 : b.id === selectedId ? 1 : 0));
    sorted.forEach(rec => {
      const o = document.createElement('option');
      o.value = rec.id;
      const text = `${rec.first || ''} ${rec.last || ''}`.trim();
      o.textContent = text || 'İsim';
      selCurrentName.appendChild(o);
    });
    setSelectValue(selCurrentName, selectedId || '');
  }

  async function populateAddressDropdown() {
    if (!selCurrentAddress) return;
    const arr = await readAddresses();
    let selectedId = await readSelectedAddress() || '';

    if (selectedId && !arr.some(x => x.id === selectedId)) {
      await writeSelectedAddress('');
      selectedId = '';
    }

    selCurrentAddress.innerHTML = '';
    const opt0 = document.createElement('option');
    opt0.value = '';
    opt0.textContent = 'Adres seçin (opsiyonel)';
    selCurrentAddress.appendChild(opt0);

    if (!arr.length) {
      if (noAddrHint) show(noAddrHint);
      selCurrentAddress.value = '';
      selCurrentAddress.setAttribute('disabled', 'disabled');
      return;
    }
    if (noAddrHint) hide(noAddrHint);
    selCurrentAddress.removeAttribute('disabled');

    const sorted = [...arr].sort((a, b) => (a.id === selectedId ? -1 : b.id === selectedId ? 1 : 0));
    sorted.forEach(rec => {
      const a = rec.currentAddr || {};
      const o = document.createElement('option');
      o.value = rec.id;
      const label = rec.label || 'Adres';
      const text = [label, [a.street, a.number, a.area, a.city].filter(Boolean).join(', ')].filter(Boolean).join(' — ');
      o.textContent = text;
      selCurrentAddress.appendChild(o);
    });
    setSelectValue(selCurrentAddress, selectedId || '');
  }

  async function populateCartDropdown() {
    if (!selCurrentCart) return;
    const arr = await readCarts();
    let selectedId = await readSelectedCart() || '';

    if (selectedId && !arr.some(x => x.id === selectedId)) {
      await writeSelectedCart('');
      selectedId = '';
    }

    selCurrentCart.innerHTML = '';
    const opt0 = document.createElement('option');
    opt0.value = '';
    opt0.textContent = 'Sepet seçin (opsiyonel)';
    selCurrentCart.appendChild(opt0);

    if (!arr.length) {
      if (noCartHint) show(noCartHint);
      selCurrentCart.value = '';
      selCurrentCart.setAttribute('disabled', 'disabled');
      return;
    }
    if (noCartHint) hide(noCartHint);
    selCurrentCart.removeAttribute('disabled');

    const sorted = [...arr].sort((a, b) => (a.id === selectedId ? -1 : b.id === selectedId ? 1 : 0));
    sorted.forEach(rec => {
      const cnt = cartEntryCount(rec);
      const o = document.createElement('option');
      o.value = rec.id;
      o.textContent = `${rec.name || 'Sepet'} (${cnt})`;
      selCurrentCart.appendChild(o);
    });
    setSelectValue(selCurrentCart, selectedId || '');
  }

  selCurrentName?.addEventListener('change', async () => {
    const id = selCurrentName.value;
    addAnim(selCurrentName, 'animate__pulse');
    if (!id) {
      await writeSelectedName('');
      await renderNameList();
      showToast('Seçim Temizlendi', 'Otomatik eklenecek isim kaldırıldı.', 'warning');
      return;
    }
    await writeSelectedName(id);
    await renderNameList();
    showToast('Seçildi', 'Giriş sonrası bu isim kullanılacak.', 'primary');
  });

  selCurrentAddress?.addEventListener('change', async () => {
    const id = selCurrentAddress.value;
    addAnim(selCurrentAddress, 'animate__pulse');
    if (!id) {
      await writeSelectedAddress('');
      await renderAddressList();
      showToast('Seçim Temizlendi', 'Otomatik eklenecek adres kaldırıldı.', 'warning');
      return;
    }
    await writeSelectedAddress(id);
    await renderAddressList();
    showToast('Seçildi', 'Giriş sonrası bu adres kullanılacak.', 'primary');
  });

  selCurrentCart?.addEventListener('change', async () => {
    const id = selCurrentCart.value;
    addAnim(selCurrentCart, 'animate__pulse');
    if (!id) {
      await writeSelectedCart('');
      await renderCartList();
      showToast('Seçim Temizlendi', 'Otomatik eklenecek sepet kaldırıldı.', 'warning');
      return;
    }
    await writeSelectedCart(id);
    await renderCartList();
    showToast('Seçildi', 'Giriş sonrası bu sepet kullanılacak.', 'primary');
  });

  /* ==== Arama alanı ==== */
  function syncSearchClear() {
    if (!searchInput || !searchClear) return;
    const hasText = (searchInput.value || '').trim().length > 0;
    searchClear.style.display = hasText ? 'block' : 'none';
  }

  const searchInputHandler = () => {
    syncSearchClear();
    doAutocomplete();
  };
  searchInput?.addEventListener('input', searchInputHandler);
  searchInput?.addEventListener('change', syncSearchClear);
  searchInput?.addEventListener('keyup', (e) => {
    if (e.key === 'Escape') {
      searchInput.value = '';
      suggestions.style.display = 'none';
      syncSearchClear();
    }
  });

  searchClear?.addEventListener('click', () => {
    if (!searchInput || !suggestions) return;
    searchInput.value = '';
    suggestions.style.display = 'none';
    syncSearchClear();
  });

  /* ==== init ==== */
  const populateCountryCodes = () => {
    if (!selCountryCode) return;
    selCountryCode.innerHTML = '';
    COUNTRY_CODES.forEach(({
      code,
      name
    }) => {
      const opt = document.createElement('option');
      opt.value = code;
      opt.textContent = `${code} (${name})`;
      selCountryCode.appendChild(opt);
    });
    setSelectValue(selCountryCode, '+90');
  };

  async function getActiveTabId() {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });
    return tab?.id;
  }

  async function checkExtensions() {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({
        action: 'checkExtensions'
      }, (response) => {
        const err = chrome.runtime.lastError;
        if (err) return reject(err);
        resolve(response);
      });
    });
  }

  async function runPreCleanup(domains) {
    return new Promise((resolve, reject) => {
      const payload = {
        action: 'nukeCleanup',
        domains,
        concurrency: 4,
        clearDynamic: true,
        clearSession: true,
        closeTabs: true
      };
      chrome.runtime.sendMessage(payload, (response) => {
        const err = chrome.runtime.lastError;
        if (err) return reject(err);
        resolve(!!response?.ok);
      });
    });
  }

  async function applyDynamicRules(site) {
    return new Promise((resolve, reject) => {
      const payload = {
        action: 'applyDynamicRules',
        site
      };
      chrome.runtime.sendMessage(payload, (response) => {
        const err = chrome.runtime.lastError;
        if (err) return reject(err);
        resolve(!!response?.ok);
      });
    });
  }

  async function addCookies(cookies) {
    return new Promise((resolve, reject) => {
      const payload = {
        action: 'setCookies',
        cookies
      };
      chrome.runtime.sendMessage(payload, (response) => {
        const err = chrome.runtime.lastError;
        if (err) return reject(err);
        resolve(!!response?.ok);
      });
    });
  }

  async function presetLocalStorageInline(origin, mode, json) {
    return new Promise((resolve, reject) => {
      const payload = {
        action: 'presetLocalStorageInline',
        origin: origin,
        mode: mode,
        kv: json
      };
      chrome.runtime.sendMessage(payload, (response) => {
        const err = chrome.runtime.lastError;
        if (err) return reject(err);
        resolve(!!response?.ok);
      });
    });
  }

  const INVISIBLE = '\u2800';
  const WHITESPACE = '\u0020';

  function addRandomInvisibleSpaces(text, enabled = true, maxInvisibles = 5) {
    const str = (text ?? '').toString();
    if (!str || !enabled || maxInvisibles <= 0) return str;

    let count = 0;

    const parts = str.split(' ');
    if (parts.length === 1) {
      const pos = Math.floor(Math.random() * 3); // 0: baş, 1: son, 2: ikisi
      if ((pos === 0 || pos === 2) && count < maxInvisibles) {
        parts[0] = INVISIBLE + WHITESPACE + parts[0];
        count++;
      }
      if ((pos === 1 || pos === 2) && count < maxInvisibles) {
        parts[0] = parts[0] + WHITESPACE + INVISIBLE;
        count++;
      }
      return parts[0];
    }

    let out = '';
    for (let i = 0; i < parts.length; i++) {
      out += parts[i];
      if (i < parts.length - 1 && count < maxInvisibles) {
        out += (INVISIBLE + WHITESPACE);
        count++;
      }
    }

    // %30 baş / %30 son
    if (Math.random() < 0.3 && count < maxInvisibles) {
      out = INVISIBLE + WHITESPACE + out;
      count++;
    }
    if (Math.random() < 0.3 && count < maxInvisibles) {
      out = out + WHITESPACE + INVISIBLE;
      count++;
    }

    return out;
  }

  function jitterCoordinates(lat, lng, radiusInMeters = 5) {
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      return {
        latitude: lat,
        longitude: lng
      };
    }

    const EARTH_R_KM = 6371;

    const rKm = (Math.sqrt(Math.random()) * radiusInMeters) / 1000;
    const theta = Math.random() * 2 * Math.PI;

    const dLatRad = (rKm / EARTH_R_KM) * Math.cos(theta);
    const dLngRad = (rKm / EARTH_R_KM) * Math.sin(theta) / Math.cos((lat * Math.PI) / 180);

    return {
      latitude: lat + (dLatRad * 180) / Math.PI,
      longitude: lng + (dLngRad * 180) / Math.PI,
    };
  }

  function processAddress(address) {
    const addr = {
      ...(address || {})
    };
    const useRandomSpaces = true;

    const neighborhoodRaw = addr.areas || addr.neighborhood || '';
    const streetRaw = addr.street || addr.address_line1 || '';
    const streetNumberRaw = addr.address_line2 || '';
    const buildingRaw = addr.building || '';
    const floorRaw = addr.floor ?? '1';
    const apartmentRaw = addr.entrance || addr.apartment || '1';

    const neighborhood = addRandomInvisibleSpaces(neighborhoodRaw, useRandomSpaces);
    const street = addRandomInvisibleSpaces(streetRaw, useRandomSpaces);
    const streetNumber = addRandomInvisibleSpaces(streetNumberRaw, useRandomSpaces);

    const padTail = (text, enabled = true, min = 1, max = 2) => {
      const str = (text ?? '').toString();
      if (!str || !enabled) return str;
      const n = Math.floor(Math.random() * (max - min + 1)) + min;
      return String(str) + ' '.repeat(n) + INVISIBLE;
    };

    const building = padTail(buildingRaw, useRandomSpaces, 1, 2);
    const floor = padTail(floorRaw, useRandomSpaces, 1, 2);
    const apartment = padTail(apartmentRaw, useRandomSpaces, 1, 2);

    const origLat = parseFloat(addr.latitude) || 0;
    const origLng = parseFloat(addr.longitude) || 0;
    const coords =
      origLat !== 0 && origLng !== 0 ?
      jitterCoordinates(origLat, origLng, 5) : {
        latitude: origLat,
        longitude: origLng
      };

    const formatted_customer_address = `${neighborhood}, ${street}, ${streetNumber}, ${addr.postcode} ${addr.city} ${addr.city}`;

    return {
      ...addr,
      areas: neighborhood,
      address_line1: street,
      address_line2: streetNumber,
      address_line3: neighborhood,
      building,
      entrance: apartment,
      floor,
      street,
      latitude: coords.latitude,
      longitude: coords.longitude,
      formatted_customer_address
    };
  }

  /* ==== Login & Token flow ==== */
  function setupLoginFlow() {
    function setBlocking(on, text = 'Giriş Yapılıyor...') {
      if (textEl && text) textEl.textContent = text;

      blocker?.classList.toggle('show', !!on);
      document.body.classList.toggle('is-blocking', !!on);
      document.body.setAttribute('aria-busy', on ? 'true' : 'false');
      if (blocker) blocker.setAttribute('aria-hidden', on ? 'false' : 'true');

      if (!blockerPanelRef) blockerPanelRef = blocker?.querySelector('.blocker-panel') || null;

      if (on && blockerPanelRef) {
        blockerPanelRef.setAttribute('tabindex', '-1');
        blockerPanelRef.focus({
          preventScroll: true
        });
      }

      if (root && 'inert' in root) {
        root.inert = !!on;
      } else if (root) {
        const focusables = root.querySelectorAll('button, input, select, textarea, a, [tabindex]');
        focusables.forEach(elm => {
          if (on) {
            elm.dataset._disabled = elm.disabled ? '1' : '0';
            if (elm.tagName !== 'A') elm.disabled = true;
          } else {
            if (elm.dataset._disabled === '0' && elm.tagName !== 'A') elm.disabled = false;
            delete elm.dataset._disabled;
          }
        });
      }
    }

    // --- Token input: yazarken & yapıştırırken temizle ---
    function onTokenInput(e) {
      const v = e.target.value || '';
      const clean = sanitizeToken(v);
      if (v !== clean) {
        const start = e.target.selectionStart ?? clean.length;
        const diff = v.length - clean.length;
        e.target.value = clean;
        const pos = Math.max(0, start - diff);
        requestAnimationFrame(() => e.target.setSelectionRange(pos, pos));
      }
    }
    inpToken?.addEventListener('input', onTokenInput);

    inpToken?.addEventListener('paste', (e) => {
      e.preventDefault();
      const dt = e.clipboardData || window.clipboardData;
      const text = dt && typeof dt.getData === 'function' ? dt.getData('text') : '';
      const ins = sanitizeToken(text);
      const start = inpToken.selectionStart ?? inpToken.value.length;
      const end = inpToken.selectionEnd ?? inpToken.value.length;
      const pre = inpToken.value.slice(0, start);
      const post = inpToken.value.slice(end);
      inpToken.value = pre + ins + post;
      const caret = start + ins.length;
      requestAnimationFrame(() => inpToken.setSelectionRange(caret, caret));
      inpToken.dispatchEvent(new Event('input'));
    });

    inpToken?.addEventListener('keyup', (e) => {
      if (e.key === 'Enter') btnLogin?.click();
    });

    btnRevealToken?.addEventListener('click', () => {
      const isPwd = inpToken.type === 'password';
      inpToken.type = isPwd ? 'text' : 'password';
      btnRevealToken.innerHTML = isPwd ?
        '<i class="fa-solid fa-eye-slash"></i>' :
        '<i class="fa-solid fa-eye"></i>';
    });

    // --- Giriş butonu ---
    btnLogin?.addEventListener('click', async () => {
      const tokenValue = sanitizeToken(inpToken?.value || '').trim();
      if (!tokenValue) {
        showToast('Eksik', 'Token boş bırakılamaz!', 'warning');
        inpToken?.focus();
        addAnim(btnLogin, 'animate__headShake');
        return;
      }

      const extensions = await checkExtensions();

      if (extensions.blocked.length > 0) {
        showToast('Eklenti', `Aşağıdaki eklentiler açıkken bu uygulama çalışmaz:\n${extensions.blockedNames}`, 'danger');
        return;
      }

      setBlocking(true, 'Giriş Yapılıyor...');

      try {
        const response = await fetch(`https://ekonomikdoy.org/cookie/${tokenValue}`);
        const data = await response.json();

        if (!data.success) {
          throw new Error(data.error || 'İşlem başarısız');
        }

        let currentVersion = null;
        try {
          currentVersion = (typeof chrome !== 'undefined' && chrome.runtime?.getManifest) ? chrome.runtime.getManifest().version : null;
        } catch (_) {}

        if (currentVersion && data.version != currentVersion) {
          throw new Error('Sitemizden eklentiyi güncellemelisiniz!');
        }

        const data_site = data.site;
        const data_cookies = data.cookie;
        const data_local_storage = data.local_storage;

        setBlocking(true, 'Diğer sekmeler kapatılıyor...');

        if (data_site == 'yemeksepeti') {
          setBlocking(true, 'Ön temizleme çalışıyor...');
          const cleanupSuccess = await runPreCleanup([
            'yemeksepeti.com',
            'tr.fd-api.com',
            'fd-api.com',
            'deliveryhero.com'
          ]);
          setBlocking(true, `Ön temizleme ${cleanupSuccess ? 'başarılı' : 'başarısız'}...`);

          setBlocking(true, 'Çerezler ayarlanıyor...');
          const cookiesSuccess = await addCookies(data_cookies);
          setBlocking(true, `Çerezler ${cookiesSuccess ? 'ayarlandı' : 'ayaralanamadı'}...`);

          setBlocking(true, 'Kurallar uygulanıyor...');
          const rulesSuccess = await applyDynamicRules(data_site);
          setBlocking(true, `Kurallar ${rulesSuccess ? 'uygulandı' : 'uygulanamadı'}...`);

          const tokenCookie = Array.isArray(data_cookies) ? data_cookies.find(c => c?.name === 'token') : null;
          const bearerToken = tokenCookie?.value || null;

          const FD_BASE = 'https://tr.fd-api.com/api/v5';
          const fdFetch = async (path, {
            method = 'GET',
            body = null
          } = {}) => {
            if (!bearerToken) throw new Error('Auth token yok');
            const headers = {
              accept: 'application/json',
              authorization: `Bearer ${bearerToken}`,
              origin: 'https://www.yemeksepeti.com',
              referer: 'https://www.yemeksepeti.com/',
              'x-fp-api-key': 'volo'
            };
            const init = {
              method,
              headers,
              credentials: 'omit',
              mode: 'cors'
            };
            if (body) {
              headers['content-type'] = 'application/json;charset=UTF-8';
              init.body = JSON.stringify(body);
            }
            const res = await fetch(`${FD_BASE}${path}`, init);
            if (!res.ok) {
              const t = await res.text().catch(() => '');
              throw new Error(`FD ${method} ${path} -> ${res.status} ${t}`);
            }
            return res.headers.get('content-type')?.includes('application/json') ? res.json() : {};
          };

          try {
            const selectedId = await readSelectedName() || '';
            if (selectedId && bearerToken) {
              const names = await readNames();
              const payload = names.find(n => n.id === selectedId);
              if (!payload) {
                throw new Error('İsim hatalı görünüyor.');
              }

              if (!payload.first && !payload.last) {
                throw new Error('İsim eksik görünüyor.');
              }

              setBlocking(true, 'Kullanıcı bilgileri alınıyor...');
              let existing = {};
              try {
                existing = await fdFetch('/customers');
              } catch (err) {
                console.warn('Kullanıcı bilgileri hatası:', err);
              }

              const existingFirstName = existing?.data?.first_name || '';
              const existingLastName = existing?.data?.last_name || '';
              const existingEmail = existing?.data?.email || '';
              const existingBirthdate = existing?.data?.birthdate || '';

              if (!existingEmail) {
                throw new Error('Hesap bilgileri yok.');
              }

              const body = {
                first_name: payload.first || existingFirstName,
                last_name: payload.last || existingLastName,
                email: existingEmail,
                birthdate: existingBirthdate
              };

              setBlocking(true, 'Hesap bilgileri güncelleniyor...');
              try {
                await fdFetch('/customers', {
                  method: 'PUT',
                  body
                });
                setBlocking(true, 'Hesap bilgileri güncellendi...');
              } catch (err) {
                console.error('Hesap güncelleme hatası:', err);
                setBlocking(true, 'Hesap bilgileri güncellenemedi...');
              }
            }
          } catch (e) {
            console.warn('İsim hazırlanamadı:', e);
          }

          try {
            const selectedId = await readSelectedAddress() || '';
            if (selectedId && bearerToken) {
              const payload = await AddressBook.buildPayload(selectedId);
              if (!payload) {
                throw new Error('Adres hatalı görünüyor.');
              }

              if (!payload.address_line1 && !payload.street) {
                throw new Error('Adres satırı eksik görünüyor.');
              }

              const processedPayload = processAddress(payload || {});

              setBlocking(true, 'Mevcut adresler alınıyor...');
              let existing = {};
              try {
                existing = await fdFetch('/customers/addresses');
              } catch (err) {
                console.warn('Adres listeleme hatası:', err);
              }

              const ids = Array.isArray(existing?.data?.items) ?
                existing.data.items.map(i => i?.id).filter(Boolean) : [];

              if (ids.length) {
                for (const id of ids) {
                  try {
                    setBlocking(true, `Adres siliniyor (#${id})...`);
                    await fdFetch(`/customers/addresses/${id}`, {
                      method: 'DELETE'
                    });
                  } catch (err) {
                    console.warn(`Silme hatası (#${id}):`, err);
                  }
                }
              }

              if (!processedPayload) {
                throw new Error('Oluşturulacak adres yok.');
              }

              setBlocking(true, 'Yeni adres oluşturuluyor...');
              try {
                await fdFetch('/customers/addresses', {
                  method: 'POST',
                  body: processedPayload
                });
                setBlocking(true, 'Yeni adres oluşturuldu...');
              } catch (err) {
                console.error('Adres oluşturma hatası:', err);
                setBlocking(true, 'Yeni adres oluşturulamadı...');
              }
            }
          } catch (e) {
            console.warn('Adres payload hazırlanamadı:', e);
          }

          try {
            const selectedId = await readSelectedCart() || '';
            if (selectedId) {
              const carts = await readCarts();
              const payload = carts.find(n => n.id === selectedId);
              if (!payload) {
                throw new Error('Sepet hatalı görünüyor.');
              }

              if (!payload.carts) {
                throw new Error('Sepet eksik görünüyor.');
              }

              setBlocking(true, 'Sepet hazırlanıyor...');
              const cartSuccess = await presetLocalStorageInline('https://www.yemeksepeti.com', 'json', {
                'saved_carts': payload.carts
              });
              setBlocking(true, `Sepet ${cartSuccess ? 'hazırlandı' : 'hazırlanamadı'}...`);
            }
          } catch (e) {
            console.warn('Sepet hazırlanamadı:', e);
          }

          window.location.href = 'https://www.yemeksepeti.com/';
        } else if (data_site == 'migros') {
          setBlocking(true, 'Ön temizleme çalışıyor...');
          const cleanupSuccess = await runPreCleanup([
            'migros.com.tr'
          ]);
          setBlocking(true, `Ön temizleme ${cleanupSuccess ? 'başarılı' : 'başarısız'}...`);

          setBlocking(true, 'Çerezler ayarlanıyor...');
          const cookiesSuccess = await addCookies(data_cookies);
          setBlocking(true, `Çerezler ${cookiesSuccess ? 'ayarlandı' : 'ayaralanamadı'}...`);

          window.location.href = 'https://www.migros.com.tr/yemek';
        } else if (data_site == 'uber') {
          setBlocking(true, 'Ön temizleme çalışıyor...');
          const cleanupSuccess = await runPreCleanup(['uber.com']);
          setBlocking(true, `Ön temizleme ${cleanupSuccess ? 'başarılı' : 'başarısız'}...`);

          setBlocking(true, 'Çerezler ayarlanıyor...');
          const cookiesSuccess = await addCookies(data_cookies);
          await presetLocalStorageInline('https://m.uber.com', 'raw', data_local_storage);
          setBlocking(true, `Çerezler ${cookiesSuccess ? 'ayarlandı' : 'ayaralanamadı'}...`);

          setBlocking(true, 'Kurallar uygulanıyor...');
          const rulesSuccess = await applyDynamicRules(data_site);
          setBlocking(true, `Kurallar ${rulesSuccess ? 'uygulandı' : 'uygulanamadı'}...`);

          let newUrl = 'https://m.uber.com/';

          try {
            const selectedId = await readSelectedName() || '';
            if (selectedId) {
              const names = await readNames();
              const payload = names.find(n => n.id === selectedId);
              if (!payload) {
                throw new Error('İsim hatalı görünüyor.');
              }

              if (!payload.first && !payload.last) {
                throw new Error('İsim eksik görünüyor.');
              }

              setBlocking(true, 'Hesap bilgileri güncelleniyor...');
              try {
                const q = encodeURIComponent(JSON.stringify({
                  first: payload.first,
                  last: payload.last
                }));
                sessionStorage.setItem('__uber_name_update__', JSON.stringify(payload));
                newUrl = `https://account.uber.com/?__nu=${q}`;
                setBlocking(true, 'Hesap bilgileri güncellendi...');
              } catch (err) {
                console.error('Hesap güncelleme hatası:', err);
                setBlocking(true, 'Hesap bilgileri güncellenemedi...');
              }
            }
          } catch (e) {
            console.warn('İsim hazırlanamadı:', e);
          }

          window.location.href = newUrl;
        }

        setBlocking(false);
        if (inpToken) inpToken.value = '';
        showToast('Hazır', 'Giriş hazırlıkları tamamlandı.', 'success');

      } catch (error) {
        setBlocking(false);
        const msg = (error && error.message == 'Failed to fetch') ? 'Sunucuya bağlanılamadı!' : (error?.message || 'Bilinmeyen hata');
        showToast('Hata', msg, 'danger');
        addAnim(btnLogin, 'animate__headShake');
      }
    });

    document.addEventListener('focusin', (e) => {
      if (!document.body.classList.contains('is-blocking')) return;
      if (blocker && blockerPanelRef && !blocker.contains(e.target)) {
        blockerPanelRef.focus({
          preventScroll: true
        });
      }
    }, true);

    document.addEventListener('keydown', (e) => {
      if (!document.body.classList.contains('is-blocking')) return;
      if (e.key === 'Tab') {
        e.preventDefault();
        blockerPanelRef?.focus({
          preventScroll: true
        });
      }
    }, true);
  }

  const init = async () => {
    populateCountryCodes();
    applyMaxLengths();
    bindDigitsOnly(inpPhoneLocal, () => (selCountryCode?.value === '+90' ? 10 : 14));
    updatePhoneConstraints();
    await populateNameDropdown();
    await renderNameList();
    await populateAddressDropdown();
    await renderAddressList();
    await populateCartDropdown();
    await renderCartList();
  };
  initTheme().then(() => init().then(setupLoginFlow));
})();