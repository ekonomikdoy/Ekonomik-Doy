/*!
 * logger.js - universal colorful logger for background (importScripts) + content scripts + injected page scripts
 *
 * Usage:
 *   // Background / service worker:
 *   importScripts('logger.js');
 *   Logger.set({ tag: 'BG', level: 'debug', enabled: true });
 *   Logger.i('started');
 *
 *   // Content / page:
 *   Logger.set({ tag: 'YEMEKSEPETI', level: 'debug' });
 *   Logger.d('hello');                 // uses dynamic CONFIG.tag
 *   const log = Logger.child('MAIN');  // fixed tag for that logger
 *   log.i('hi');                       // uses 'MAIN'
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.Logger = factory();
  }
})(typeof globalThis !== 'undefined' ? globalThis : (typeof self !== 'undefined' ? self : this), function () {
  'use strict';

  // ===== Helpers =====
  const pad2 = (n) => String(n).padStart(2, '0');
  const pad3 = (n) => String(n).padStart(3, '0');

  function formatTS(d = new Date()) {
    // gg/aa/yyyy ss:dd:sn.mmm
    const dd = pad2(d.getDate());
    const mm = pad2(d.getMonth() + 1);
    const yyyy = d.getFullYear();
    const HH = pad2(d.getHours());
    const MM = pad2(d.getMinutes());
    const SS = pad2(d.getSeconds());
    const mmm = pad3(d.getMilliseconds());
    return `${dd}/${mm}/${yyyy} ${HH}:${MM}:${SS}.${mmm}`;
  }

  const LEVEL = {
    debug: 10,
    info: 20,
    warn: 30,
    error: 40,
    silent: 99
  };

  // ===== Theme =====
  const THEME = {
    base: 'font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; font-size: 12px;',
    time: 'color:#9CA3AF;',
    tag: 'background:#111827;color:#E5E7EB;padding:2px 6px;border-radius:999px;font-weight:700;',
    caller: 'color:#A78BFA;',
    debug: {
      pill: 'background:#1F2937;color:#93C5FD;padding:2px 6px;border-radius:8px;font-weight:700;',
      icon: '🔹',
      msg: 'color:#E5E7EB;'
    },
    info: {
      pill: 'background:#064E3B;color:#6EE7B7;padding:2px 6px;border-radius:8px;font-weight:700;',
      icon: '✅',
      msg: 'color:#ECFDF5;'
    },
    warn: {
      pill: 'background:#78350F;color:#FCD34D;padding:2px 6px;border-radius:8px;font-weight:700;',
      icon: '⚠️',
      msg: 'color:#FFFBEB;'
    },
    error: {
      pill: 'background:#7F1D1D;color:#FCA5A5;padding:2px 6px;border-radius:8px;font-weight:700;',
      icon: '🛑',
      msg: 'color:#FEF2F2;'
    },
  };

  // ===== Global Config =====
  const CONFIG = {
    enabled: true,
    level: 'debug', // debug|info|warn|error|silent
    tag: 'LOG',
    withTimestamp: true,
    withCaller: false,
    forceConsoleLog: false, // true => always console.log
  };

  function should(level) {
    if (!CONFIG.enabled) return false;
    const want = LEVEL[CONFIG.level] ?? 99;
    const got = LEVEL[level] ?? 99;
    return got >= want;
  }

  function getConsoleFn(level) {
    if (CONFIG.forceConsoleLog) return console.log.bind(console);
    if (level === 'error') return console.error.bind(console);
    if (level === 'warn') return console.warn.bind(console);
    if (level === 'info') return console.info.bind(console);
    return console.log.bind(console);
  }

  function getCaller() {
    try {
      const e = new Error();
      const s = String(e.stack || '');
      const lines = s.split('\n').map(x => x.trim());
      // 0: Error, 1: getCaller, 2: emit, 3: Logger.d, 4+: caller
      return lines[4] || lines[3] || '';
    } catch (_) {
      return '';
    }
  }

  function emit(level, tag, ...args) {
    if (!should(level)) return;

    const styleLevel = THEME[level] || THEME.debug;
    const fn = getConsoleFn(level);

    const parts = [];
    const styles = [];

    if (CONFIG.withTimestamp) {
      parts.push('%c' + formatTS());
      styles.push(THEME.base + THEME.time);
    }

    parts.push('%c' + (tag || CONFIG.tag));
    styles.push(THEME.base + THEME.tag);

    parts.push('%c' + level.toUpperCase());
    styles.push(THEME.base + styleLevel.pill);

    parts.push('%c' + (styleLevel.icon || '•'));
    styles.push(THEME.base);

    if (CONFIG.withCaller) {
      const caller = getCaller();
      if (caller) {
        parts.push('%c' + caller);
        styles.push(THEME.base + THEME.caller);
      }
    }

    const fmt = parts.join(' ') + '%c';
    styles.push(THEME.base + (styleLevel.msg || ''));
    fn(fmt, ...styles, ...args);
  }

  // ===== Child logger (fixed tag) =====
  function makeChild(fixedTag) {
    const t = fixedTag;
    return {
      d: (...a) => emit('debug', t, ...a),
      i: (...a) => emit('info', t, ...a),
      w: (...a) => emit('warn', t, ...a),
      e: (...a) => emit('error', t, ...a),
      child: (childTag) => makeChild(childTag),
    };
  }

  // ===== Public API (root logger uses dynamic CONFIG.tag) =====
  const Logger = {
    // Root: always uses current CONFIG.tag (dynamic)
    d: (...a) => emit('debug', CONFIG.tag, ...a),
    i: (...a) => emit('info', CONFIG.tag, ...a),
    w: (...a) => emit('warn', CONFIG.tag, ...a),
    e: (...a) => emit('error', CONFIG.tag, ...a),

    // Child: fixed tag
    child: (tag) => makeChild(tag),

    // Config ops
    set(partial) {
      if (!partial || typeof partial !== 'object') return;
      if ('enabled' in partial) CONFIG.enabled = !!partial.enabled;
      if ('level' in partial) CONFIG.level = partial.level;
      if ('tag' in partial) CONFIG.tag = partial.tag;
      if ('withTimestamp' in partial) CONFIG.withTimestamp = !!partial.withTimestamp;
      if ('withCaller' in partial) CONFIG.withCaller = !!partial.withCaller;
      if ('forceConsoleLog' in partial) CONFIG.forceConsoleLog = !!partial.forceConsoleLog;
    },
    enable() {
      CONFIG.enabled = true;
    },
    disable() {
      CONFIG.enabled = false;
    },
    level(lvl) {
      CONFIG.level = lvl;
    },
    tag(t) {
      CONFIG.tag = t;
    },
    config() {
      return {
        ...CONFIG
      };
    },

    // Optional: redirect console.* to Logger.*
    patchConsole() {
      if (Logger._patched) return;
      Logger._patched = true;
      Logger._orig = {
        log: console.log,
        info: console.info,
        warn: console.warn,
        error: console.error
      };
      console.log = (...a) => Logger.d(...a);
      console.info = (...a) => Logger.i(...a);
      console.warn = (...a) => Logger.w(...a);
      console.error = (...a) => Logger.e(...a);
    },
    unpatchConsole() {
      if (!Logger._patched || !Logger._orig) return;
      console.log = Logger._orig.log;
      console.info = Logger._orig.info;
      console.warn = Logger._orig.warn;
      console.error = Logger._orig.error;
      Logger._patched = false;
    },
  };

  return Logger;
});