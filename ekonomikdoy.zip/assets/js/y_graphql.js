(() => {
  if (window.__EKO_FD_PLATFORM_HOOK__) return;
  window.__EKO_FD_PLATFORM_HOOK__ = true;

  const TARGET = 'https://tr.fd-api.com/graphql';
  const HEADER_NAME = 'Platform';
  const HEADER_VALUE = 'android';

  const urlMatches = (url) => String(url || '').startsWith(TARGET);

  // -----------------------
  // fetch patch (güvenli)
  // -----------------------
  const origFetch = window.fetch;
  if (typeof origFetch === 'function') {
    window.fetch = function (input, init) {
      try {
        const url = typeof input === 'string' ? input : input?.url;
        const method =
          (init?.method || (typeof input !== 'string' ? input?.method : 'GET') || 'GET').toUpperCase();

        if (urlMatches(url) && method !== 'OPTIONS') {
          const headers = new Headers(
            init?.headers || (typeof input !== 'string' ? input?.headers : undefined) || {}
          );
          headers.set(HEADER_NAME, HEADER_VALUE);
          init = {
            ...(init || {}),
            headers
          };
        }
      } catch {}
      return origFetch.call(this, input, init);
    };
  }

  // -----------------------
  // XHR patch (constructor YOK, prototype patch VAR)
  // -----------------------
  const XHRProto = XMLHttpRequest && XMLHttpRequest.prototype;
  if (XHRProto && !XHRProto.__ekoPatched) {
    XHRProto.__ekoPatched = true;

    const origOpen = XHRProto.open;
    const origSend = XHRProto.send;

    XHRProto.open = function (method, url, ...rest) {
      try {
        this.__eko_url = String(url || '');
        this.__eko_method = String(method || 'GET').toUpperCase();
      } catch {}
      return origOpen.call(this, method, url, ...rest);
    };

    XHRProto.send = function (body) {
      try {
        if (urlMatches(this.__eko_url) && this.__eko_method !== 'OPTIONS') {
          this.setRequestHeader(HEADER_NAME, HEADER_VALUE);
        }
      } catch {}
      return origSend.call(this, body);
    };
  }
})();