(() => {
  const observer = new MutationObserver(() => {
    const elements = [
      ...document.evaluate('//*[@label="Hesabımı Sil"]', document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null),
      ...document.evaluate('//a[contains(text(),"Çıkış Yap")]', document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null),
      ...document.evaluate('//button[contains(@id,"signOut")]', document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null)
    ];

    elements.forEach(element => {
      if (element) {
        element.remove();
      }
    });
  });

  observer.observe(document, {
    attributes: true,
    childList: true,
    subtree: true
  });
})();