(function () {
  'use strict';

  var currentUrl = window.location.href;

  const androidAppVersion = '25.27.0';
  const androidBuildNumber = '252700274';

  Logger.set({
    tag: 'YEMEKSEPETI',
    level: 'debug',
    enabled: true,
    withTimestamp: true
  });

  function getExpiryEpochSec(t) {
    try {
      return JSON.parse(window.atob(t.split('.')[1])).expires;
    } catch (e) {
      return null;
    }
  }

  function isTokenExpired(token, skewSeconds = 10) {
    const exp = getExpiryEpochSec(token);
    if (!exp) return true;
    const nowSec = Math.floor(Date.now() / 1000);
    return nowSec >= (exp - skewSeconds);
  }

  function showTokenExpiredOverlay() {
    if (document.getElementById('token-expired-overlay')) return;
    const overlay = document.createElement('div');
    overlay.id = 'token-expired-overlay';
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.background = 'rgba(0,0,0,0.85)';
    overlay.style.color = 'white';
    overlay.style.fontSize = '22px';
    overlay.style.fontFamily = 'Arial, sans-serif';
    overlay.style.display = 'flex';
    overlay.style.alignItems = 'center';
    overlay.style.justifyContent = 'center';
    overlay.style.zIndex = '999999';
    overlay.style.padding = '20px';
    overlay.style.textAlign = 'center';

    overlay.innerText = '🔑 Tokeninizin süresi doldu. Lütfen hesaba token ile tekrar girin.';

    const mount = () => {
      const parent = document.body || document.documentElement;
      if (!parent) return;
      parent.appendChild(overlay);
    };

    if (document.body) {
      mount();
    } else {
      const onReady = () => {
        mount();
        document.removeEventListener('DOMContentLoaded', onReady);
      };
      document.addEventListener('DOMContentLoaded', onReady);
    }
  }

  function getAccessToken() {
    const cookies = document.cookie.split(';');
    for (let cookie of cookies) {
      const [name, value] = cookie.trim().split('=');
      if (name === 'ekonomik_doy_token') {
        return decodeURIComponent(value);
      }
    }
    return null;
  }

  function getSold() {
    const cookies = document.cookie.split(';');
    for (let cookie of cookies) {
      const [name, value] = cookie.trim().split('=');
      if (name === 'sold') {
        return new Date(decodeURIComponent(value));
      }
    }
    return null;
  }

  function convertToDate(dateInput) {
    try {
      const monthIndexMap = {
        'Oca': 0,
        'Ocak': 0,
        'Şub': 1,
        'Şubat': 1,
        'Mar': 2,
        'Mart': 2,
        'Nis': 3,
        'Nisan': 3,
        'May': 4,
        'Mayıs': 4,
        'Haz': 5,
        'Haziran': 5,
        'Tem': 6,
        'Temmuz': 6,
        'Ağu': 7,
        'Ağustos': 7,
        'Eyl': 8,
        'Eylül': 8,
        'Eki': 9,
        'Ekim': 9,
        'Kas': 10,
        'Kasım': 10,
        'Ara': 11,
        'Aralık': 11,

        // İngilizce gelebilirse:
        'Jan': 0,
        'Feb': 1,
        'Mar': 2,
        'Apr': 3,
        'May': 4,
        'Jun': 5,
        'Jul': 6,
        'Aug': 7,
        'Sep': 8,
        'Oct': 9,
        'Nov': 10,
        'Dec': 11
      };

      const now = new Date();
      let year = now.getFullYear();
      let day, monthIndex, hour, minute;

      const clean = dateInput.trim();

      if (clean.includes(',')) {
        // "Per, Tem 11, 12:25 PM" gibi
        const parts = clean.split(/[\s,]+/).filter(Boolean);
        // örn: ["Per","Tem","11","12:25","PM"]
        const monthText = parts[1];
        const dayStr = parts[2];
        const timeStr = parts[3];
        const meridian = parts[4];

        day = parseInt(dayStr, 10);
        monthIndex = monthIndexMap[monthText];
        [hour, minute] = timeStr.split(':').map(n => parseInt(n, 10));

        if (meridian === 'PM' && hour !== 12) hour += 12;
        if (meridian === 'AM' && hour === 12) hour = 0;
      } else {
        // "26 Şub Per 14:23" veya "11 Tem Sal 12:25"
        const parts = clean.split(/\s+/);
        // [day, month, weekday, time]
        day = parseInt(parts[0], 10);
        const monthText = parts[1];
        monthIndex = monthIndexMap[monthText];
        const timeStr = parts[3] || parts[2]; // bazen weekday olmayabilir
        [hour, minute] = timeStr.split(':').map(n => parseInt(n, 10));
      }

      if (monthIndex == null || Number.isNaN(day) || Number.isNaN(hour) || Number.isNaN(minute)) {
        return null;
      }

      let date = new Date(year, monthIndex, day, hour, minute, 0);

      // Sadece "bariz şekilde gelecekte" ise (örn. > 24 saat) yılı 1 geri al
      const ONE_DAY = 24 * 60 * 60 * 1000;
      if (date.getTime() - now.getTime() > ONE_DAY) {
        year -= 1;
        date = new Date(year, monthIndex, day, hour, minute, 0);
      }

      return date;
    } catch (e) {
      Logger.e('convertToDate error:', e);
      return null;
    }
  }

  function generateRandomEmail() {
    const characters = 'abcdefghijklmnopqrstuvwxyz1234567890';
    let email = '';
    for (let i = 0; i < 10; i++) {
      email += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return `${email}@gmail.com`;
  }

  function generateRandomGermanNumber() {
    const number = Math.floor(10000000000 + Math.random() * 90000000000);
    return `+49 ${number}`;
  }

  Logger.d('Request Interceptor başlatılıyor...');

  const accessToken = getAccessToken();

  if (!accessToken || isTokenExpired(accessToken)) {
    showTokenExpiredOverlay();
  } else {
    Logger.i('Geçerli token bulundu, süresi geçmemiş.');

    if (!window.ekonomikDoyYS) {
      window.ekonomikDoyYS = {
        xhrCallbacks: {},
        requestCounter: 0
      };
    }

    function generateRequestId() {
      return Date.now() + '_' + (++window.ekonomikDoyYS.requestCounter) + '_' + Math.random().toString(36).substr(2, 9);
    }

    function sendProxyRequest(requestData) {
      return new Promise((resolve, reject) => {
        const requestId = generateRequestId();

        window.ekonomikDoyYS.xhrCallbacks[requestId] = {
          resolve,
          reject
        };

        setTimeout(() => {
          if (window.ekonomikDoyYS.xhrCallbacks[requestId]) {
            delete window.ekonomikDoyYS.xhrCallbacks[requestId];
            reject(new Error('Request timeout'));
          }
        }, 30000);

        window.postMessage({
          source: 'EKO_YS',
          action: 'ysProxyRequest',
          requestId: requestId,
          url: requestData.url,
          method: requestData.method,
          headers: requestData.headers,
          body: requestData.body
        }, '*');
      });
    }

    window.addEventListener('message', function (event) {
      if (event.source !== window) return;

      if (event.data && event.data.source === 'EKO_YS_RESPONSE' &&
        event.data.action === 'proxyResponse') {

        const {
          requestId,
          response
        } = event.data;
        const callback = window.ekonomikDoyYS.xhrCallbacks[requestId];

        if (callback) {
          if (response.success) {
            callback.resolve(response);
          } else {
            callback.reject(new Error(response.error || 'Request failed'));
          }
          delete window.ekonomikDoyYS.xhrCallbacks[requestId];
        }
      }
    });

    const originalXHROpen = XMLHttpRequest.prototype.open;
    const originalXHRSend = XMLHttpRequest.prototype.send;
    const originalXHRSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;

    function isServiceWorkerFile(url) {
      return url && (
        url.includes('ngsw-worker.js') ||
        url.includes('/ngsw-worker.js') ||
        url.endsWith('ngsw-worker.js') ||
        url.includes('sw.js') ||
        url.includes('service-worker.js')
      );
    }

    function isPWAManifestFile(url) {
      return url && (
        url.includes('manifest.json') ||
        url.includes('/manifest.json') ||
        url.endsWith('manifest.json') ||
        url.includes('ngsw.json') ||
        url.includes('/ngsw.json') ||
        url.endsWith('ngsw.json') ||
        url.includes('ngsw.json?ngsw-cache-bust=') ||
        url.includes('cookie-settings')
      );
    }

    function isProfileIconFile(url) {
      return url && (
        url.includes('profilim_icon_s.webp') ||
        url.includes('/profilim_icon_s.webp') ||
        url.endsWith('profilim_icon_s.webp')
      );
    }

    function isCustomTextsEndpoint(url) {
      return url && (
        url.includes('custom-texts') ||
        url.includes('homepage/visibility')
      );
    }

    function isScreenViewsEndpoint(url) {
      return url && url.includes('screen-views');
    }

    function isLogoutEndpoint(url) {
      return url && (
        url.includes('auth/exit') ||
        url.includes('users/closed-accounts') ||
        url.includes('users/registration-blocks')
      );
    }

    function isAnalyticsOrTrackingEndpoint(url) {
      if (!url) return false;
      const blocked = [
        'px-cloud.net', 'sentry.io', 'usercentrics.eu', 'tvsquared.com',
        'icg-in.com', 'braze.com', 'api/v2/collector', 'trackjs.com',
        'xhr/b/s', 'cdn-cgi/rum', 'px-cdn.net', 'perseus-productanalytics',
        '/v5/action-log', 'pxchk.net', 'hotjar.io', 'hotjar.com',
        'datadoghq.eu', 'hexagon-analytics', 'qualtrics.com', 'datadog',
        'browser-intake-datadoghq.eu', 'deliveryhero.com/api/logs',
        'bruce-ys-tr.production.eu.fintech.deliveryhero.com/api/logs',
        'at-display-eu.deliveryhero.io', 'disco.deliveryhero.io/up-and-cross-sell',
        'action-log.yemeksepeti.com', '/v1/insert/pandora/hit', 'perseus-productanalytics.deliveryhero.net'
      ];
      return blocked.some(p => url.includes(p));
    }

    XMLHttpRequest.prototype.open = function (method, url, ...args) {
      this._requestUrl = url;
      this._requestMethod = method;
      this._requestHeaders = {};

      Logger.d('XHR Intercept - open', method, url);

      if (typeof url === 'string') {
        if (url.includes('users/tokens')) {
          this._isTokenEndpoint = true;
        }

        if (isLogoutEndpoint(url)) {
          this._isLogoutEndpoint = true;
        }

        if (isScreenViewsEndpoint(url)) {
          this._isScreenViewsEndpoint = true;
        }

        if (isCustomTextsEndpoint(url)) {
          this._isCustomTextsEndpoint = true;
        }

        if (isServiceWorkerFile(url)) {
          this._isServiceWorkerFile = true;
        }

        if (isPWAManifestFile(url)) {
          this._isPWAManifestFile = true;
        }

        if (isProfileIconFile(url)) {
          this._isProfileIconFile = true;
        }

        if (isAnalyticsOrTrackingEndpoint(url)) {
          this._isAnalyticsBlocked = true;
        }

        if (url.includes('tr.fd-api.com/api/v5/cart/checkout') ||
          url.includes('tr.fd-api.com/api/v5/purchase/intent') ||
          url.includes('tr.fd-api.com/api/v5/wallet/paymentinstruments') ||
          url.includes('tr.fd-api.com/api/v5/users/addresses') ||
          url.includes('tr.fd-api.com/api/v5/cart/calculate') ||
          url.includes('tr.fd-api.com/api/v6/incentives-wallet/vouchers')) {
          this._shouldProxy = true;
          Logger.d('Proxy isteği yakalandı:', method, url);
        }
      }

      return originalXHROpen.apply(this, [method, url, ...args]);
    };

    const FORBIDDEN_HEADERS = new Set([
      'accept-charset', 'accept-encoding', 'access-control-request-headers',
      'access-control-request-method', 'connection', 'content-length',
      'cookie', 'cookie2', 'date', 'dnt', 'expect', 'host', 'keep-alive',
      'origin', 'referer', 'te', 'trailer', 'transfer-encoding', 'upgrade',
      'via', 'user-agent'
    ]);

    XMLHttpRequest.prototype.setRequestHeader = function (header, value) {
      if (this._requestHeaders) {
        this._requestHeaders[header] = value;
      }

      Logger.d('XHR Intercept - setRequestHeader', header, value);
      const lc = header.toLowerCase();
      if (FORBIDDEN_HEADERS.has(lc) || lc.startsWith('sec-') || lc.startsWith('proxy-')) {
        return;
      }
      try {
        return originalXHRSetRequestHeader.apply(this, arguments);
      } catch (e) {}
    };

    XMLHttpRequest.prototype.send = function (body) {
      if (this._isTokenEndpoint) {
        Logger.d('Token isteği yakalandı ve engellendi:', this._requestUrl);
        const xhr = this;
        const fakeToken = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
          const r = Math.random() * 16 | 0;
          const v = c === 'x' ? r : (r & 0x3 | 0x8);
          return v.toString(16);
        });
        const responseData = JSON.stringify({
          token: fakeToken
        });

        setTimeout(() => {
          Object.defineProperty(xhr, 'readyState', {
            value: 4,
            configurable: true
          });
          Object.defineProperty(xhr, 'status', {
            value: 200,
            configurable: true
          });
          Object.defineProperty(xhr, 'statusText', {
            value: 'OK',
            configurable: true
          });
          Object.defineProperty(xhr, 'response', {
            value: responseData,
            configurable: true
          });
          Object.defineProperty(xhr, 'responseText', {
            value: responseData,
            configurable: true
          });

          if (typeof xhr.onreadystatechange === 'function') xhr.onreadystatechange();
          if (typeof xhr.onload === 'function') xhr.onload();
          if (typeof xhr.onloadend === 'function') xhr.onloadend();
          xhr.dispatchEvent(new Event('readystatechange'));
          xhr.dispatchEvent(new Event('load'));
          xhr.dispatchEvent(new Event('loadend'));
        }, 50);
        return;
      }

      if (this._isLogoutEndpoint && this._requestMethod === 'POST') {
        Logger.d('Logout isteği yakalandı ve engellendi:', this._requestUrl);
        const xhr = this;

        setTimeout(() => {
          Object.defineProperty(xhr, 'readyState', {
            value: 4,
            configurable: true
          });
          Object.defineProperty(xhr, 'status', {
            value: 500,
            configurable: true
          });
          Object.defineProperty(xhr, 'statusText', {
            value: 'Internal Server Error',
            configurable: true
          });
          Object.defineProperty(xhr, 'response', {
            value: '',
            configurable: true
          });
          Object.defineProperty(xhr, 'responseText', {
            value: '',
            configurable: true
          });

          if (typeof xhr.onreadystatechange === 'function') xhr.onreadystatechange();
          if (typeof xhr.onload === 'function') xhr.onload();
          if (typeof xhr.onloadend === 'function') xhr.onloadend();
          xhr.dispatchEvent(new Event('readystatechange'));
          xhr.dispatchEvent(new Event('load'));
          xhr.dispatchEvent(new Event('loadend'));
        }, 50);
        return;
      }

      if (this._isScreenViewsEndpoint) {
        Logger.d('Screen-views isteği engellendi:', this._requestUrl);
        const xhr = this;

        setTimeout(() => {
          Object.defineProperty(xhr, 'readyState', {
            value: 4,
            configurable: true
          });
          Object.defineProperty(xhr, 'status', {
            value: 200,
            configurable: true
          });
          Object.defineProperty(xhr, 'statusText', {
            value: 'OK',
            configurable: true
          });
          Object.defineProperty(xhr, 'response', {
            value: '{}',
            configurable: true
          });
          Object.defineProperty(xhr, 'responseText', {
            value: '{}',
            configurable: true
          });

          if (typeof xhr.onreadystatechange === 'function') xhr.onreadystatechange();
          if (typeof xhr.onload === 'function') xhr.onload();
          if (typeof xhr.onloadend === 'function') xhr.onloadend();
          xhr.dispatchEvent(new Event('readystatechange'));
          xhr.dispatchEvent(new Event('load'));
          xhr.dispatchEvent(new Event('loadend'));
        }, 50);
        return;
      }

      if (this._isCustomTextsEndpoint) {
        Logger.d('Custom-texts isteği engellendi:', this._requestUrl);
        const xhr = this;
        const customTextsResponse = JSON.stringify({
          "version": 1,
          "customTextMap": {}
        });

        setTimeout(() => {
          Object.defineProperty(xhr, 'readyState', {
            value: 4,
            configurable: true
          });
          Object.defineProperty(xhr, 'status', {
            value: 200,
            configurable: true
          });
          Object.defineProperty(xhr, 'statusText', {
            value: 'OK',
            configurable: true
          });
          Object.defineProperty(xhr, 'response', {
            value: customTextsResponse,
            configurable: true
          });
          Object.defineProperty(xhr, 'responseText', {
            value: customTextsResponse,
            configurable: true
          });

          if (typeof xhr.onreadystatechange === 'function') xhr.onreadystatechange();
          if (typeof xhr.onload === 'function') xhr.onload();
          if (typeof xhr.onloadend === 'function') xhr.onloadend();
          xhr.dispatchEvent(new Event('readystatechange'));
          xhr.dispatchEvent(new Event('load'));
          xhr.dispatchEvent(new Event('loadend'));
        }, 50);
        return;
      }

      if (this._isServiceWorkerFile) {
        this.abort();
        const xhr = this;
        Object.defineProperty(xhr, 'readyState', {
          value: 4,
          configurable: true
        });
        Object.defineProperty(xhr, 'status', {
          value: 404,
          configurable: true
        });
        Object.defineProperty(xhr, 'statusText', {
          value: 'Not Found',
          configurable: true
        });
        Object.defineProperty(xhr, 'responseText', {
          value: '',
          configurable: true
        });
        Object.defineProperty(xhr, 'response', {
          value: '',
          configurable: true
        });
        setTimeout(() => {
          if (typeof xhr.onerror === 'function') xhr.onerror();
          if (typeof xhr.onreadystatechange === 'function') xhr.onreadystatechange();
          if (typeof xhr.onloadend === 'function') xhr.onloadend();
          xhr.dispatchEvent(new Event('error'));
          xhr.dispatchEvent(new Event('readystatechange'));
          xhr.dispatchEvent(new Event('loadend'));
        }, 50);
        return;
      }

      if (this._isPWAManifestFile) {
        this.abort();
        const xhr = this;
        Object.defineProperty(xhr, 'readyState', {
          value: 4,
          configurable: true
        });
        Object.defineProperty(xhr, 'status', {
          value: 404,
          configurable: true
        });
        Object.defineProperty(xhr, 'statusText', {
          value: 'Not Found',
          configurable: true
        });
        Object.defineProperty(xhr, 'responseText', {
          value: '',
          configurable: true
        });
        Object.defineProperty(xhr, 'response', {
          value: '',
          configurable: true
        });
        setTimeout(() => {
          if (typeof xhr.onerror === 'function') xhr.onerror();
          if (typeof xhr.onreadystatechange === 'function') xhr.onreadystatechange();
          if (typeof xhr.onloadend === 'function') xhr.onloadend();
          xhr.dispatchEvent(new Event('error'));
          xhr.dispatchEvent(new Event('readystatechange'));
          xhr.dispatchEvent(new Event('loadend'));
        }, 50);
        return;
      }

      if (this._isProfileIconFile) {
        this.abort();
        const xhr = this;
        Object.defineProperty(xhr, 'readyState', {
          value: 4,
          configurable: true
        });
        Object.defineProperty(xhr, 'status', {
          value: 404,
          configurable: true
        });
        Object.defineProperty(xhr, 'statusText', {
          value: 'Not Found',
          configurable: true
        });
        Object.defineProperty(xhr, 'responseText', {
          value: '',
          configurable: true
        });
        Object.defineProperty(xhr, 'response', {
          value: '',
          configurable: true
        });
        setTimeout(() => {
          if (typeof xhr.onerror === 'function') xhr.onerror();
          if (typeof xhr.onreadystatechange === 'function') xhr.onreadystatechange();
          if (typeof xhr.onloadend === 'function') xhr.onloadend();
          xhr.dispatchEvent(new Event('error'));
          xhr.dispatchEvent(new Event('readystatechange'));
          xhr.dispatchEvent(new Event('loadend'));
        }, 50);
        return;
      }

      if (this._isAnalyticsBlocked) {
        this.abort();
        const xhr = this;
        Object.defineProperty(xhr, 'readyState', {
          value: 4,
          configurable: true
        });
        Object.defineProperty(xhr, 'status', {
          value: 0,
          configurable: true
        });
        Object.defineProperty(xhr, 'statusText', {
          value: '',
          configurable: true
        });
        Object.defineProperty(xhr, 'responseText', {
          value: '',
          configurable: true
        });
        Object.defineProperty(xhr, 'response', {
          value: null,
          configurable: true
        });
        setTimeout(() => {
          if (typeof xhr.onerror === 'function') xhr.onerror();
          if (typeof xhr.onreadystatechange === 'function') xhr.onreadystatechange();
          if (typeof xhr.onloadend === 'function') xhr.onloadend();
          xhr.dispatchEvent(new Event('error'));
          xhr.dispatchEvent(new Event('readystatechange'));
          xhr.dispatchEvent(new Event('loadend'));
        }, 0);
        return;
      }

      if (this._shouldProxy) {
        const originalXhr = this;

        this.abort();

        let finalBody = body;
        if (body && typeof body === 'string') {
          try {
            const requestBody = JSON.parse(body);

            if (this._requestUrl.includes('/cart/checkout')) {
              if (requestBody.platform && requestBody.platform === 'b2c') {
                requestBody.platform = `Android-app-${androidAppVersion}(${androidBuildNumber})`;
                Logger.d('Platform değiştirildi: b2c → Android-app');
              }

              if (requestBody.source) {
                const oldSource = requestBody.source;
                requestBody.source = 'android';
                Logger.d(`Source değiştirildi: ${oldSource} → android`);
              } else {
                requestBody.source = 'android';
              }

              finalBody = JSON.stringify(requestBody);
            }

            if (this._requestUrl.includes('/wallet/paymentinstruments') &&
              this._requestMethod.toUpperCase() === 'POST') {
              Logger.d('Kart kaydetme engellendi');

              setTimeout(() => {
                Object.defineProperty(originalXhr, 'readyState', {
                  value: 4,
                  configurable: true
                });
                Object.defineProperty(originalXhr, 'status', {
                  value: 200,
                  configurable: true
                });
                Object.defineProperty(originalXhr, 'statusText', {
                  value: 'OK',
                  configurable: true
                });
                Object.defineProperty(originalXhr, 'response', {
                  value: '{"success":true}',
                  configurable: true
                });
                Object.defineProperty(originalXhr, 'responseText', {
                  value: '{"success":true}',
                  configurable: true
                });

                if (typeof originalXhr.onreadystatechange === 'function') originalXhr.onreadystatechange();
                if (typeof originalXhr.onload === 'function') originalXhr.onload();
                if (typeof originalXhr.onloadend === 'function') originalXhr.onloadend();

                originalXhr.dispatchEvent(new Event('readystatechange'));
                originalXhr.dispatchEvent(new Event('load'));
                originalXhr.dispatchEvent(new Event('loadend'));
              }, 10);

              return;
            }

            if (this._requestUrl.includes('/users/addresses') &&
              (this._requestMethod.toUpperCase() === 'POST' || this._requestMethod.toUpperCase() === 'PUT')) {
              Logger.d('Adres kaydetme engellendi');

              setTimeout(() => {
                Object.defineProperty(originalXhr, 'readyState', {
                  value: 4,
                  configurable: true
                });
                Object.defineProperty(originalXhr, 'status', {
                  value: 200,
                  configurable: true
                });
                Object.defineProperty(originalXhr, 'statusText', {
                  value: 'OK',
                  configurable: true
                });
                Object.defineProperty(originalXhr, 'response', {
                  value: '{"success":true}',
                  configurable: true
                });
                Object.defineProperty(originalXhr, 'responseText', {
                  value: '{"success":true}',
                  configurable: true
                });

                if (typeof originalXhr.onreadystatechange === 'function') originalXhr.onreadystatechange();
                if (typeof originalXhr.onload === 'function') originalXhr.onload();
                if (typeof originalXhr.onloadend === 'function') originalXhr.onloadend();

                originalXhr.dispatchEvent(new Event('readystatechange'));
                originalXhr.dispatchEvent(new Event('load'));
                originalXhr.dispatchEvent(new Event('loadend'));
              }, 10);

              return;
            }

          } catch (e) {
            Logger.e('Body parse hatası:', e);
          }
        }

        sendProxyRequest({
          url: this._requestUrl,
          method: this._requestMethod,
          headers: this._requestHeaders,
          body: finalBody
        }).then(response => {
          const responseHeaders = response.headers || {};

          Object.defineProperty(originalXhr, 'readyState', {
            value: 4,
            configurable: true
          });
          Object.defineProperty(originalXhr, 'status', {
            value: response.status,
            configurable: true
          });
          Object.defineProperty(originalXhr, 'statusText', {
            value: response.statusText,
            configurable: true
          });
          Object.defineProperty(originalXhr, 'response', {
            value: response.data,
            configurable: true
          });
          Object.defineProperty(originalXhr, 'responseText', {
            value: response.data,
            configurable: true
          });

          originalXhr.getAllResponseHeaders = function () {
            if (!responseHeaders || typeof responseHeaders !== 'object') return '';
            return Object.entries(responseHeaders).map(([key, value]) => `${key}: ${value}`).join('\r\n');
          };
          originalXhr.getResponseHeader = function (name) {
            if (!responseHeaders || typeof responseHeaders !== 'object') return null;
            return responseHeaders[name.toLowerCase()] || null;
          };

          if (typeof originalXhr.onreadystatechange === 'function') originalXhr.onreadystatechange();
          if (typeof originalXhr.onload === 'function') originalXhr.onload();
          originalXhr.dispatchEvent(new Event('load'));
          if (typeof originalXhr.onloadend === 'function') originalXhr.onloadend();
          originalXhr.dispatchEvent(new Event('loadend'));

          Logger.d('XHR Proxy yanıt alındı:', response.status);
        }).catch(error => {
          Logger.e('XHR Proxy hatası:', error);

          Object.defineProperty(originalXhr, 'readyState', {
            value: 4,
            configurable: true
          });
          Object.defineProperty(originalXhr, 'status', {
            value: 0,
            configurable: true
          });
          Object.defineProperty(originalXhr, 'statusText', {
            value: 'Proxy Error',
            configurable: true
          });

          if (typeof originalXhr.onerror === 'function') originalXhr.onerror();
          originalXhr.dispatchEvent(new Event('error'));
          if (typeof originalXhr.onloadend === 'function') originalXhr.onloadend();
          originalXhr.dispatchEvent(new Event('loadend'));
        });

        return;
      }

      return originalXHRSend.apply(this, arguments);
    };

    const originalFetch = window.fetch;
    window.fetch = function (...args) {
      const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || '';
      const init = typeof args[0] === 'object' ? args[0] : args[1] || {};

      if (url.includes('users/tokens')) {
        Logger.d('Fetch: Token isteği engellendi:', url);
        const fakeToken = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
          const r = Math.random() * 16 | 0;
          const v = c === 'x' ? r : (r & 0x3 | 0x8);
          return v.toString(16);
        });
        return Promise.resolve(new Response(JSON.stringify({
          token: fakeToken
        }), {
          status: 200,
          statusText: 'OK',
          headers: {
            'Content-Type': 'application/json'
          }
        }));
      }

      if (init && init.method === 'POST' && (isLogoutEndpoint(url))) {
        Logger.d('Fetch: Logout isteği engellendi:', url);
        return Promise.resolve(new Response('', {
          status: 500,
          statusText: 'Internal Server Error'
        }));
      }

      if (isScreenViewsEndpoint(url)) {
        Logger.d('Fetch: Screen-views isteği engellendi:', url);
        return Promise.resolve(new Response('{}', {
          status: 200,
          statusText: 'OK',
          headers: {
            'Content-Type': 'application/json'
          }
        }));
      }

      if (isCustomTextsEndpoint(url)) {
        Logger.d('Fetch: Custom-texts isteği engellendi:', url);
        return Promise.resolve(new Response(JSON.stringify({
          "version": 1,
          "customTextMap": {}
        }), {
          status: 200,
          statusText: 'OK',
          headers: {
            'Content-Type': 'application/json',
            'Cache-Control': 'no-cache'
          }
        }));
      }

      if (isAnalyticsOrTrackingEndpoint(url)) {
        return Promise.reject(new TypeError('Failed to fetch'));
      }

      if (isServiceWorkerFile(url)) {
        return new Response('', {
          status: 404,
          statusText: 'Not Found',
          headers: {
            'Content-Type': 'text/plain'
          }
        });
      }

      if (isPWAManifestFile(url)) {
        return new Response('', {
          status: 404,
          statusText: 'Not Found',
          headers: {
            'Content-Type': 'application/json'
          }
        });
      }

      if (isProfileIconFile(url)) {
        return new Response('', {
          status: 404,
          statusText: 'Not Found',
          headers: {
            'Content-Type': 'image/webp'
          }
        });
      }

      if (url.includes('tr.fd-api.com/api/v5/cart/checkout') ||
        url.includes('tr.fd-api.com/api/v5/purchase/intent') ||
        url.includes('tr.fd-api.com/api/v5/wallet/paymentinstruments') ||
        url.includes('tr.fd-api.com/api/v5/users/addresses') ||
        url.includes('tr.fd-api.com/api/v5/cart/calculate') ||
        url.includes('tr.fd-api.com/api/v6/incentives-wallet/vouchers')) {

        Logger.d('Fetch API isteği yakalandı:', init.method || 'GET', url);

        if (url.includes('/wallet/paymentinstruments') &&
          (init.method?.toUpperCase() === 'POST' || !init.method)) {
          Logger.d('Kart kaydetme engellendi (Fetch)');
          return Promise.resolve(new Response('{"success":true}', {
            status: 200,
            statusText: 'OK',
            headers: {
              'Content-Type': 'application/json'
            }
          }));
        }

        if (url.includes('/users/addresses') &&
          (init.method?.toUpperCase() === 'POST' || init.method?.toUpperCase() === 'PUT')) {
          Logger.d('Adres kaydetme engellendi (Fetch)');
          return Promise.resolve(new Response('{"success":true}', {
            status: 200,
            statusText: 'OK',
            headers: {
              'Content-Type': 'application/json'
            }
          }));
        }

        let finalBody = init.body;
        if (url.includes('/cart/checkout') && init.body) {
          try {
            let requestBody;
            if (typeof init.body === 'string') {
              requestBody = JSON.parse(init.body);
            } else {
              requestBody = JSON.parse(String(init.body));
            }

            if (requestBody.platform && requestBody.platform === 'b2c') {
              requestBody.platform = `Android-app-${androidAppVersion}(${androidBuildNumber})`;
              Logger.d('Platform değiştirildi (Fetch): b2c → Android-app');
            }

            if (requestBody.source) {
              const oldSource = requestBody.source;
              requestBody.source = 'android';
              Logger.d(`Source değiştirildi (Fetch): ${oldSource} → android`);
            } else {
              requestBody.source = 'android';
            }

            finalBody = JSON.stringify(requestBody);
          } catch (error) {
            Logger.e('Fetch body parse hatası:', error);
          }
        }

        return sendProxyRequest({
          url: url,
          method: init.method || 'GET',
          headers: init.headers || {},
          body: finalBody
        }).then(response => {
          return new Response(response.data, {
            status: response.status,
            statusText: response.statusText,
            headers: response.headers
          });
        }).catch(error => {
          Logger.e('Fetch Proxy hatası:', error);
          return new Response(null, {
            status: 503,
            statusText: 'Proxy Service Unavailable'
          });
        });
      }

      return originalFetch.apply(this, args);
    };

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.getRegistrations().then(registrations => {
        registrations.forEach(registration => {
          registration.unregister().then(success => {
            if (success) {
              Logger.d('🚫 Service Worker kaydı kaldırıldı:', registration.scope);
            }
          });
        });
      });
    }

    Logger.d('Request Interceptor başlatıldı');
  }

  if (currentUrl.includes('/orders')) {
    const sold = getSold();

    if (sold) {
      const ordersObserver = new MutationObserver(() => {
        const orderBoxes = document.querySelectorAll('.order-item-container');
        orderBoxes.forEach(box => {
          const subtitle = box.querySelector('[data-testid="past-order-subtitle"]');
          if (!subtitle) return;

          let dateText = subtitle.innerText
            .replace(' tarihinde teslim edildi', '')
            .replace(' tarihinde iptal edildi', '')
            .replace('Delivered on ', '')
            .replace('Cancelled on ', '');
          const dateObj = convertToDate(dateText);

          if (dateObj && dateObj < sold) {
            box.remove();
          }
        });
      });

      ordersObserver.observe(document, {
        attributes: true,
        childList: true,
        subtree: true
      });
    }
  }

  if (currentUrl.includes('/cuzdan')) {
    const sold = getSold();

    if (sold) {
      const walletObserver = new MutationObserver(() => {
        const transactions = document.querySelectorAll('.wallet-transaction');
        transactions.forEach(item => {
          const label = item.getAttribute('aria-label');
          if (!label) return;

          const dateStr = label.split(' :')[0];
          const [day, month, year] = dateStr.includes('/') ?
            dateStr.split('/').map(Number) :
            dateStr.split('.').map(Number);
          const date = new Date(year, month - 1, day, 23, 59, 59);

          if (date < sold) {
            item.remove();
          }
        });
      });

      walletObserver.observe(document, {
        attributes: true,
        childList: true,
        subtree: true
      });
    }
  }

  if (currentUrl.includes('/checkout/')) {
    const email = generateRandomEmail();
    const phoneNumber = generateRandomGermanNumber();

    const checkoutObserver = new MutationObserver(() => {
      const personalDetailsContainer = document.querySelectorAll('div[data-testid="personal-details"]');

      if (personalDetailsContainer.length > 0 && !personalDetailsContainer[0].hasAttribute('data-modified')) {
        const editButtons = personalDetailsContainer[0].querySelector('button');

        if (editButtons) {
          editButtons.remove();
        }

        const personalDetails = personalDetailsContainer[0].querySelectorAll('div[class*="f-paragraph-small-font-size"]');

        if (personalDetails.length > 0) {
          personalDetails.forEach((div, index) => {
            if (index === 0) {
              div.textContent = email;
            } else {
              div.textContent = phoneNumber;
            }
          });

          personalDetailsContainer[0].setAttribute('data-modified', 'true');
        }
      }

      const paymentMenu = document.querySelector('[data-testid="cartlib-cart-title"]');
      if (paymentMenu) {
        const paymentMethods = document.querySelectorAll('[data-testid^="payment-method-item"]');

        const creditCardPaymentMethod = document.querySelector('[data-testid="payment-method-item-yemekpay_creditcard"]');

        if (paymentMethods.length > 0) {
          paymentMethods.forEach(paymentMethod => {
            if (paymentMethod !== creditCardPaymentMethod) {
              paymentMethod.style.display = 'none';
            }
          });
        }
      }

      const newUsers = document.evaluate('//*[@role="alert" and contains(.,"yeni kullanıcılar için")]', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
      if (newUsers) {
        if (!newUsers.hasAttribute('data-modified')) {
          Toast.show('Adresiniz veya ip adresinizden kaynaklı ban yemişsiniz, diğer eklentileri kapatıp hesaba token ile tekrar girin ve farklı bir adres girin.', {
            title: 'Hata Çözümü',
            duration: 10000,
            dismissible: false
          });
          newUsers.setAttribute('data-modified', 'true');
        }
      }

      const mustLogin = document.evaluate('//*[@role="alert" and contains(.,"giriş yapmalı veya hesap")]', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
      if (mustLogin) {
        if (!mustLogin.hasAttribute('data-modified')) {
          Toast.show('Bizim eklentimizden başka eklenti tarayıcınızda açık olduğu için bu hatayı alıyorsunuz, diğer eklentileri kapatıp hesaba token ile tekrar girin.', {
            title: 'Hata Çözümü',
            duration: 10000,
            dismissible: false
          });
          mustLogin.setAttribute('data-modified', 'true');
        }
      }

      const paymentDeclined = document.evaluate('//*[@role="banner" and contains(.,"Ödemeniz reddedildi")]', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
      if (paymentDeclined) {
        if (!paymentDeclined.hasAttribute('data-modified')) {
          Toast.warning('Kartınızdan kaynaklı ban yemişsiniz, farklı bir kart girin.', {
            title: 'Hata Çözümü',
            duration: 10000,
            dismissible: false
          });
          paymentDeclined.setAttribute('data-modified', 'true');
        }
      }

      const couldntProcess = document.evaluate('//*[@role="banner" and contains(.,"işleme alamadık")]', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
      if (couldntProcess) {
        if (!couldntProcess.hasAttribute('data-modified')) {
          Toast.show('Bizim eklentimizden başka eklenti tarayıcınızda açık olduğu için bu hatayı alıyorsunuz, diğer eklentileri kapatıp sepet sayfasını yenileyin. Devam ediyorsa kullandığınız kartı değiştirin.', {
            title: 'Hata Çözümü',
            duration: 10000,
            dismissible: false
          });
          couldntProcess.setAttribute('data-modified', 'true');
        }
      }
    });

    checkoutObserver.observe(document, {
      attributes: true,
      childList: true,
      subtree: true
    });
  }

  if (currentUrl.includes('/account')) {
    const accountObserver = new MutationObserver(() => {
      const testDataIds = ['contact-form-mobile-number-input', 'contact-form-birthdate-input'];

      testDataIds.forEach((testDataId) => {
        const divToDelete = document.querySelector(`[data-testid="${testDataId}"]`);
        if (divToDelete) {
          const parentDiv = divToDelete.parentNode;
          if (parentDiv) {
            parentDiv.remove();
          }
        }
      });

      const testDataIds2 = ['account-email', 'marketing-consent', 'password-form', 'social-accounts', 'account-deletion'];

      testDataIds2.forEach((testDataId) => {
        const divToDelete = document.querySelector(`[data-testid="${testDataId}"]`);
        if (divToDelete) {
          const hrElement = divToDelete.previousElementSibling;

          if (hrElement && hrElement.classList.contains('divider')) {
            hrElement.remove();
          }

          divToDelete.remove();
        }
      });
    });

    accountObserver.observe(document, {
      attributes: true,
      childList: true,
      subtree: true
    });
  }

  const observer = new MutationObserver(() => {
    const manifestLinks = document.querySelectorAll('link[rel="manifest"], link[href*="manifest.json"], link[href*="ngsw.json"]');

    if (manifestLinks.length > 0) {
      manifestLinks.forEach(link => {
        link.remove();
      });
    }

    const redirectionModal = document.querySelector('[data-testid="mweb-redirection-modal"]');
    if (redirectionModal) {
      const portalElement = redirectionModal.closest('.bds-c-portal');
      if (portalElement) {
        portalElement.remove();
      } else {
        redirectionModal.remove();
      }
    }

    const riderBanner = document.querySelector('[data-testid="wallet-rider-banners"]');
    if (riderBanner) {
      const topSlot = riderBanner.closest('.top-slot');
      if (topSlot) {
        topSlot.remove();
      } else {
        riderBanner.remove();
      }
    }

    const dropdownMenu = document.getElementsByClassName('account-link')[0];
    if (dropdownMenu) {
      dropdownMenu.addEventListener('click', () => {
        setTimeout(() => {
          const logoutLink = document.querySelector('a[href="/logout"]');
          if (logoutLink) {
            const liElement = logoutLink.closest('li');
            if (liElement) {
              liElement.remove();
            } else {
              logoutLink.remove();
            }
          }
        }, 5);
      });
    }

    const dropdownMenu2 = document.getElementById('menu-selector');
    if (dropdownMenu2) {
      dropdownMenu2.addEventListener('click', () => {
        setTimeout(() => {
          const logoutLink = document.querySelector('a[href="/logout"]');
          if (logoutLink) {
            const liElement = logoutLink.closest('li');
            if (liElement) {
              liElement.remove();
            } else {
              logoutLink.remove();
            }
          }
        }, 5);
      });
    }

    const accountMenu = document.getElementById('account-menu');
    if (accountMenu) {
      const logoutLink = accountMenu.querySelector('a[href="/logout"]');
      if (logoutLink) {
        const liElement = logoutLink.closest('li');
        if (liElement) {
          liElement.remove();
        } else {
          logoutLink.remove();
        }
      }
    }
  });

  observer.observe(document, {
    attributes: true,
    childList: true,
    subtree: true
  });
})();