/**
 * Browser API Compatibility Layer
 * Provides cross-browser support for Chrome and iOS Orion Browser
 * Automatically detects and uses the appropriate API (chrome or browser)
 */

(function() {
  'use strict';

  // Check if we're in a browser extension context
  if (typeof window === 'undefined' && typeof self !== 'undefined') {
    // Service Worker context
    if (typeof chrome === 'undefined' && typeof browser !== 'undefined') {
      self.chrome = browser;
    }
    return;
  }

  // Window/document context
  if (typeof window !== 'undefined') {
    // If chrome API doesn't exist but browser API does (Firefox, Orion)
    if (typeof window.chrome === 'undefined' && typeof window.browser !== 'undefined') {
      window.chrome = window.browser;
    }
    
    // If neither exists, create a minimal polyfill
    if (typeof window.chrome === 'undefined' && typeof window.browser === 'undefined') {
      console.warn('No browser extension API detected');
      return;
    }

    // Ensure chrome API exists for the rest of the code
    const api = window.chrome || window.browser;
    
    // Polyfill chrome.runtime if needed
    if (!api.runtime) {
      api.runtime = {};
    }
    
    // Polyfill getURL for both chrome.runtime and chrome.extension
    if (!api.runtime.getURL && api.extension && api.extension.getURL) {
      api.runtime.getURL = api.extension.getURL.bind(api.extension);
    }
    
    // Ensure backward compatibility
    if (api.runtime.getURL && !api.extension) {
      api.extension = { getURL: api.runtime.getURL };
    }

    window.chrome = api;
  }
})();

/**
 * Promise-based wrapper for chrome APIs that use callbacks
 * This ensures compatibility across different browser implementations
 */
if (typeof chrome !== 'undefined') {
  // Wrap storage APIs with promise support if needed
  if (chrome.storage && chrome.storage.local && chrome.storage.local.get) {
    const originalLocalGet = chrome.storage.local.get.bind(chrome.storage.local);
    const originalLocalSet = chrome.storage.local.set.bind(chrome.storage.local);
    const originalLocalRemove = chrome.storage.local.remove.bind(chrome.storage.local);
    
    // Only wrap if not already promise-based
    if (originalLocalGet.constructor.name !== 'AsyncFunction') {
      chrome.storage.local.get = function(keys) {
        return new Promise((resolve, reject) => {
          originalLocalGet(keys, (result) => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve(result);
            }
          });
        });
      };
    }
    
    if (originalLocalSet.constructor.name !== 'AsyncFunction') {
      chrome.storage.local.set = function(items) {
        return new Promise((resolve, reject) => {
          originalLocalSet(items, () => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve();
            }
          });
        });
      };
    }
    
    if (originalLocalRemove.constructor.name !== 'AsyncFunction') {
      chrome.storage.local.remove = function(keys) {
        return new Promise((resolve, reject) => {
          originalLocalRemove(keys, () => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve();
            }
          });
        });
      };
    }
  }

  // Wrap storage.sync APIs
  if (chrome.storage && chrome.storage.sync && chrome.storage.sync.get) {
    const originalSyncGet = chrome.storage.sync.get.bind(chrome.storage.sync);
    const originalSyncSet = chrome.storage.sync.set.bind(chrome.storage.sync);
    
    if (originalSyncGet.constructor.name !== 'AsyncFunction') {
      chrome.storage.sync.get = function(keys) {
        return new Promise((resolve, reject) => {
          originalSyncGet(keys, (result) => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve(result);
            }
          });
        });
      };
    }
    
    if (originalSyncSet.constructor.name !== 'AsyncFunction') {
      chrome.storage.sync.set = function(items) {
        return new Promise((resolve, reject) => {
          originalSyncSet(items, () => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve();
            }
          });
        });
      };
    }
  }

  // Wrap cookies API
  if (chrome.cookies && chrome.cookies.get) {
    const originalCookiesGet = chrome.cookies.get.bind(chrome.cookies);
    const originalCookiesGetAll = chrome.cookies.getAll.bind(chrome.cookies);
    const originalCookiesSet = chrome.cookies.set.bind(chrome.cookies);
    const originalCookiesRemove = chrome.cookies.remove.bind(chrome.cookies);
    
    // Always support both callback and promise style for cookies API
    chrome.cookies.get = function(details, callback) {
      if (callback) {
        return originalCookiesGet(details, callback);
      }
      return new Promise((resolve) => {
        originalCookiesGet(details, (cookie) => {
          resolve(cookie);
        });
      });
    };
    
    chrome.cookies.getAll = function(details, callback) {
      if (callback) {
        return originalCookiesGetAll(details, callback);
      }
      return new Promise((resolve) => {
        originalCookiesGetAll(details, (cookies) => {
          resolve(cookies);
        });
      });
    };
    
    chrome.cookies.set = function(details, callback) {
      if (callback) {
        return originalCookiesSet(details, callback);
      }
      return new Promise((resolve, reject) => {
        originalCookiesSet(details, (cookie) => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve(cookie);
          }
        });
      });
    };
    
    chrome.cookies.remove = function(details, callback) {
      if (callback) {
        return originalCookiesRemove(details, callback);
      }
      return new Promise((resolve) => {
        originalCookiesRemove(details, (details) => {
          resolve(details);
        });
      });
    };
  }

  // Wrap tabs API
  if (chrome.tabs) {
    if (chrome.tabs.create) {
      const originalTabsCreate = chrome.tabs.create.bind(chrome.tabs);
      if (originalTabsCreate.constructor.name !== 'AsyncFunction') {
        chrome.tabs.create = function(createProperties) {
          return new Promise((resolve) => {
            originalTabsCreate(createProperties, (tab) => {
              resolve(tab);
            });
          });
        };
      }
    }
    
    if (chrome.tabs.update) {
      const originalTabsUpdate = chrome.tabs.update.bind(chrome.tabs);
      if (originalTabsUpdate.constructor.name !== 'AsyncFunction') {
        chrome.tabs.update = function(tabId, updateProperties) {
          return new Promise((resolve) => {
            if (typeof tabId === 'object') {
              // tabId is actually updateProperties, no tabId specified
              originalTabsUpdate(tabId, (tab) => {
                resolve(tab);
              });
            } else {
              originalTabsUpdate(tabId, updateProperties, (tab) => {
                resolve(tab);
              });
            }
          });
        };
      }
    }
    
    if (chrome.tabs.query) {
      const originalTabsQuery = chrome.tabs.query.bind(chrome.tabs);
      if (originalTabsQuery.constructor.name !== 'AsyncFunction') {
        chrome.tabs.query = function(queryInfo) {
          return new Promise((resolve) => {
            originalTabsQuery(queryInfo, (tabs) => {
              resolve(tabs);
            });
          });
        };
      }
    }
    
    if (chrome.tabs.remove) {
      const originalTabsRemove = chrome.tabs.remove.bind(chrome.tabs);
      if (originalTabsRemove.constructor.name !== 'AsyncFunction') {
        chrome.tabs.remove = function(tabIds) {
          return new Promise((resolve) => {
            originalTabsRemove(tabIds, () => {
              resolve();
            });
          });
        };
      }
    }
    
    if (chrome.tabs.reload) {
      const originalTabsReload = chrome.tabs.reload.bind(chrome.tabs);
      if (originalTabsReload.constructor.name !== 'AsyncFunction') {
        chrome.tabs.reload = function(tabId, reloadProperties) {
          return new Promise((resolve) => {
            if (typeof tabId === 'function') {
              // No arguments, just callback
              originalTabsReload(() => {
                resolve();
              });
            } else if (typeof reloadProperties === 'function') {
              // tabId and callback
              originalTabsReload(tabId, () => {
                resolve();
              });
            } else {
              // All arguments
              originalTabsReload(tabId, reloadProperties, () => {
                resolve();
              });
            }
          });
        };
      }
    }
  }

  // Wrap declarativeNetRequest API (may not be available in all browsers)
  if (chrome.declarativeNetRequest && chrome.declarativeNetRequest.updateSessionRules) {
    const originalUpdateSessionRules = chrome.declarativeNetRequest.updateSessionRules.bind(chrome.declarativeNetRequest);
    if (originalUpdateSessionRules.constructor.name !== 'AsyncFunction') {
      chrome.declarativeNetRequest.updateSessionRules = function(options) {
        return new Promise((resolve, reject) => {
          originalUpdateSessionRules(options, () => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve();
            }
          });
        });
      };
    }
  }

  if (chrome.declarativeNetRequest && chrome.declarativeNetRequest.updateDynamicRules) {
    const originalUpdateDynamicRules = chrome.declarativeNetRequest.updateDynamicRules.bind(chrome.declarativeNetRequest);
    if (originalUpdateDynamicRules.constructor.name !== 'AsyncFunction') {
      chrome.declarativeNetRequest.updateDynamicRules = function(options) {
        return new Promise((resolve, reject) => {
          originalUpdateDynamicRules(options, () => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve();
            }
          });
        });
      };
    }
  }

  // Wrap browsingData API (may not be available in all browsers)
  if (chrome.browsingData && chrome.browsingData.remove) {
    const originalBrowsingDataRemove = chrome.browsingData.remove.bind(chrome.browsingData);
    if (originalBrowsingDataRemove.constructor.name !== 'AsyncFunction') {
      chrome.browsingData.remove = function(options, dataToRemove) {
        return new Promise((resolve, reject) => {
          originalBrowsingDataRemove(options, dataToRemove, () => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve();
            }
          });
        });
      };
    }
  }

  // Wrap scripting API
  if (chrome.scripting && chrome.scripting.executeScript) {
    const originalExecuteScript = chrome.scripting.executeScript.bind(chrome.scripting);
    if (originalExecuteScript.constructor.name !== 'AsyncFunction') {
      chrome.scripting.executeScript = function(injection) {
        return new Promise((resolve, reject) => {
          originalExecuteScript(injection, (results) => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve(results);
            }
          });
        });
      };
    }
  }
}

// Export for use in modules if needed
if (typeof module !== 'undefined' && module.exports) {
  module.exports = chrome;
}
