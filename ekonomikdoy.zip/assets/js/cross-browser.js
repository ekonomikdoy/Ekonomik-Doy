/**
 * Browser API Compatibility Layer
 * - chrome.* / browser.* namespace uyumluluğu
 * - Callback ve Promise kullanımını birlikte destekler
 * - Chrome, Firefox, Orion iOS gibi ortamlarda daha güvenli çalışacak şekilde tasarlanmıştır
 */

(function initBrowserCompat() {
  'use strict';

  const root =
    typeof globalThis !== 'undefined' ? globalThis :
    typeof self !== 'undefined' ? self :
    typeof window !== 'undefined' ? window : {};

  const hasChrome = typeof root.chrome !== 'undefined';
  const hasBrowser = typeof root.browser !== 'undefined';

  // browser.* varsa ama chrome.* yoksa alias oluştur
  if (!hasChrome && hasBrowser) {
    root.chrome = root.browser;
  }

  if (typeof root.chrome === 'undefined') {
    console.warn('[browser-compat] No extension API detected');
    return;
  }

  const chromeApi = root.chrome;

  // runtime / extension.getURL uyumluluğu
  if (!chromeApi.runtime) {
    chromeApi.runtime = {};
  }

  if (!chromeApi.runtime.getURL && chromeApi.extension && chromeApi.extension.getURL) {
    chromeApi.runtime.getURL = chromeApi.extension.getURL.bind(chromeApi.extension);
  }

  if (chromeApi.runtime.getURL && !chromeApi.extension) {
    chromeApi.extension = {
      getURL: chromeApi.runtime.getURL.bind(chromeApi.runtime)
    };
  }

  function isFn(value) {
    return typeof value === 'function';
  }

  function isThenable(value) {
    return !!value && (typeof value === 'object' || typeof value === 'function') && typeof value.then === 'function';
  }

  /**
   * Aynı methodu hem callback hem Promise modunda güvenli çalıştırır.
   * - Callback verilirse callback stilini korur
   * - Callback verilmezse Promise döner
   * - Promise-native browser.* ve callback-native chrome.* arasında köprü kurar
   */
  function invokeDualMode(original, thisArg, args, callback, options = {}) {
    const {
      useLastError = true
    } = options;

    if (isFn(callback)) {
      let called = false;

      const once = (value) => {
        if (called) return;
        called = true;
        callback(value);
      };

      try {
        const returned = original.apply(thisArg, args.concat(once));

        // Promise-native API ise callback'i Promise sonucundan tetikle
        if (isThenable(returned)) {
          returned.then(once).catch((error) => {
            console.error('[browser-compat]', error);
            once(undefined);
          });
        }

        return returned;
      } catch (error) {
        // Bazı Promise-native API'ler callback argümanını kabul etmez; callback'siz retry
        try {
          const returned = original.apply(thisArg, args);

          if (isThenable(returned)) {
            returned.then(once).catch((err) => {
              console.error('[browser-compat]', err);
              once(undefined);
            });
            return returned;
          }
        } catch (retryError) {
          console.error('[browser-compat]', retryError);
          once(undefined);
          return;
        }

        console.error('[browser-compat]', error);
        once(undefined);
        return;
      }
    }

    // Callback yoksa Promise dön
    return new Promise((resolve, reject) => {
      let settled = false;

      const finish = (value) => {
        if (settled) return;
        settled = true;

        const lastError =
          useLastError &&
          chromeApi.runtime &&
          chromeApi.runtime.lastError ?
          chromeApi.runtime.lastError :
          null;

        if (lastError) reject(lastError);
        else resolve(value);
      };

      try {
        const returned = original.apply(thisArg, args.concat(finish));

        if (isThenable(returned)) {
          returned.then(finish).catch((error) => {
            if (settled) return;
            settled = true;
            reject(error);
          });
        }
      } catch (error) {
        // Promise-native API callback'i kabul etmediyse callback'siz retry
        try {
          const returned = original.apply(thisArg, args);

          if (isThenable(returned)) {
            returned.then(finish).catch((err) => {
              if (settled) return;
              settled = true;
              reject(err);
            });
            return;
          }
        } catch (retryError) {
          if (!settled) {
            settled = true;
            reject(retryError);
          }
          return;
        }

        if (!settled) {
          settled = true;
          reject(error);
        }
      }
    });
  }

  function wrapMethod(obj, methodName, options = {}) {
    if (!obj || !isFn(obj[methodName])) return;
    if (obj[methodName].__compatWrapped) return;

    const original = obj[methodName].bind(obj);

    const wrapped = function (...incomingArgs) {
      const maybeCallback = incomingArgs[incomingArgs.length - 1];
      const hasCallback = isFn(maybeCallback);
      const callback = hasCallback ? maybeCallback : null;
      const args = hasCallback ? incomingArgs.slice(0, -1) : incomingArgs;

      return invokeDualMode(original, obj, args, callback, options);
    };

    wrapped.__compatWrapped = true;
    obj[methodName] = wrapped;
  }

  /**
   * tabs.reload overload düzeltmesi:
   * - reload()
   * - reload(tabId)
   * - reload({ bypassCache: true })
   * - reload(tabId, { bypassCache: true })
   * - hepsinde callback ve Promise desteği
   */
  function wrapTabsReload(tabsObj) {
    if (!tabsObj || !isFn(tabsObj.reload)) return;
    if (tabsObj.reload.__compatWrapped) return;

    const original = tabsObj.reload.bind(tabsObj);

    const wrapped = function (...incomingArgs) {
      const maybeCallback = incomingArgs[incomingArgs.length - 1];
      const hasCallback = isFn(maybeCallback);
      const callback = hasCallback ? maybeCallback : null;
      const args = hasCallback ? incomingArgs.slice(0, -1) : incomingArgs;

      let normalizedArgs;

      if (args.length === 0) {
        normalizedArgs = [undefined, undefined];
      } else if (args.length === 1) {
        if (typeof args[0] === 'number') {
          normalizedArgs = [args[0], undefined];
        } else {
          normalizedArgs = [undefined, args[0]];
        }
      } else {
        normalizedArgs = [args[0], args[1]];
      }

      return invokeDualMode(original, tabsObj, normalizedArgs, callback, {
        useLastError: true
      });
    };

    wrapped.__compatWrapped = true;
    tabsObj.reload = wrapped;
  }

  // storage
  if (chromeApi.storage) {
    if (chromeApi.storage.local) {
      wrapMethod(chromeApi.storage.local, 'get');
      wrapMethod(chromeApi.storage.local, 'set');
      wrapMethod(chromeApi.storage.local, 'remove');
      wrapMethod(chromeApi.storage.local, 'clear');
    }

    if (chromeApi.storage.sync) {
      wrapMethod(chromeApi.storage.sync, 'get');
      wrapMethod(chromeApi.storage.sync, 'set');
      wrapMethod(chromeApi.storage.sync, 'remove');
      wrapMethod(chromeApi.storage.sync, 'clear');
    }
  }

  // cookies
  if (chromeApi.cookies) {
    wrapMethod(chromeApi.cookies, 'get');
    wrapMethod(chromeApi.cookies, 'getAll');
    wrapMethod(chromeApi.cookies, 'set');
    wrapMethod(chromeApi.cookies, 'remove');
    wrapMethod(chromeApi.cookies, 'getAllCookieStores');
  }

  // tabs
  if (chromeApi.tabs) {
    wrapMethod(chromeApi.tabs, 'create');
    wrapMethod(chromeApi.tabs, 'query');
    wrapMethod(chromeApi.tabs, 'remove');
    wrapMethod(chromeApi.tabs, 'get');
    wrapMethod(chromeApi.tabs, 'update');
    wrapMethod(chromeApi.tabs, 'sendMessage');
    wrapTabsReload(chromeApi.tabs);
  }

  // runtime
  if (chromeApi.runtime) {
    wrapMethod(chromeApi.runtime, 'sendMessage');
  }

  // declarativeNetRequest
  if (chromeApi.declarativeNetRequest) {
    wrapMethod(chromeApi.declarativeNetRequest, 'updateSessionRules');
    wrapMethod(chromeApi.declarativeNetRequest, 'updateDynamicRules');
    wrapMethod(chromeApi.declarativeNetRequest, 'getDynamicRules');
    wrapMethod(chromeApi.declarativeNetRequest, 'getSessionRules');
  }

  // browsingData
  if (chromeApi.browsingData) {
    wrapMethod(chromeApi.browsingData, 'remove');
  }

  // scripting
  if (chromeApi.scripting) {
    wrapMethod(chromeApi.scripting, 'executeScript');
  }

  // windows
  if (chromeApi.windows) {
    wrapMethod(chromeApi.windows, 'update');
    wrapMethod(chromeApi.windows, 'get');
    wrapMethod(chromeApi.windows, 'getAll');
    wrapMethod(chromeApi.windows, 'create');
  }

  // alarms
  if (chromeApi.alarms) {
    wrapMethod(chromeApi.alarms, 'get');
    wrapMethod(chromeApi.alarms, 'getAll');
    wrapMethod(chromeApi.alarms, 'clear');
    wrapMethod(chromeApi.alarms, 'clearAll');
  }

  // management
  if (chromeApi.management) {
    wrapMethod(chromeApi.management, 'getAll');
    wrapMethod(chromeApi.management, 'get');
    wrapMethod(chromeApi.management, 'setEnabled');
  }

  // downloads
  if (chromeApi.downloads) {
    wrapMethod(chromeApi.downloads, 'download');
    wrapMethod(chromeApi.downloads, 'search');
    wrapMethod(chromeApi.downloads, 'erase');
    wrapMethod(chromeApi.downloads, 'removeFile');
  }

  // CommonJS export gerekiyorsa
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = chromeApi;
  }
})();