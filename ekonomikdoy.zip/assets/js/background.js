importScripts('./cross-browser.js');
importScripts('./platform-bridge.js');
importScripts('./logger.js');
importScripts('./crypto-js.min.js');
importScripts('./generate-rsig.js');

const androidAppVersion = '25.27.0';
const androidBuildNumber = '252700274';

let accessTokenGlobal = '';
let ysDeviceInfo = null;
let ysAdjustAdId = null;
let ysWidevineId = null;
let ysEmRequestIdentifier = null;

Logger.set({
  tag: 'BG',
  level: 'debug',
  enabled: true,
  withTimestamp: true
});

const isIOSOrWebKit = __im_isIOSOrWebKit();

chrome.action.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL('index.html');
  const existing = await chrome.tabs.query({
    url
  });
  if (existing.length) chrome.tabs.update(existing[0].id, {
    active: true
  });
  else chrome.tabs.create({
    url
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message?.action === 'checkExtensions') {
      try {
        const result = await checkBlockedExtensions();
        sendResponse(result);
      } catch (error) {
        sendResponse({
          blocked: [],
          blockedNames: '',
          error: error.message
        });
      }
      return;
    }

    if (message?.action === 'nukeCleanup') {
      try {
        const result = await nukeCleanupJob(message);
        sendResponse(result);
      } catch (error) {
        sendResponse({
          ok: false,
          error: error?.message || String(error)
        });
      }
      return;
    }

    if (message?.action === 'setCookies' && Array.isArray(message.cookies)) {
      try {
        const summary = await setCookiesSequential(message.cookies);
        sendResponse({
          ok: summary.success,
          ...summary
        });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error?.message || String(error)
        });
      }
      return;
    }

    if (message?.action === 'presetLocalStorageInline' && typeof message.origin === 'string') {
      try {
        const origin = message.origin.replace(/\/+$/, '');
        const mode = (message.mode === 'raw' || message.mode === 'json') ? message.mode : 'json';
        const kv = (message.kv && typeof message.kv === 'object') ? message.kv : {};

        const timeoutId = setTimeout(() => {
          try {
            chrome.webNavigation.onCommitted.removeListener(handler);
          } catch (_) {}
        }, 30000);

        const handler = (details) => {
          try {
            if (details.frameId !== 0) return;
            if (!details.url || !details.url.startsWith(origin)) return;

            chrome.webNavigation.onCommitted.removeListener(handler);
            clearTimeout(timeoutId);

            const injectFn = (pairs, writeMode) => {
              try {
                for (const [k, v] of Object.entries(pairs || {})) {
                  if (writeMode === 'raw') {
                    localStorage.setItem(k, typeof v === 'string' ? v : String(v));
                  } else {
                    localStorage.setItem(k, JSON.stringify(v));
                  }
                }
              } catch (_) {}
            };

            chrome.scripting.executeScript({
              target: {
                tabId: details.tabId,
                allFrames: false
              },
              injectImmediately: true,
              world: 'MAIN',
              func: injectFn,
              args: [kv, mode],
            }).catch(() => chrome.scripting.executeScript({
              target: {
                tabId: details.tabId,
                allFrames: false
              },
              func: injectFn,
              args: [kv, mode],
            })).catch(err => Logger.w('localStorage inline inject failed:', err));
          } catch (e) {
            Logger.e('presetLocalStorageInline handler error:', e);
          }
        };

        chrome.webNavigation.onCommitted.addListener(handler);
        sendResponse({
          ok: true
        });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error?.message || String(error)
        });
      }
      return true;
    }

    if (message?.action === 'applyDynamicRules' && typeof message.site === 'string') {
      try {
        const site = message.site;

        if (site == 'yemeksepeti') {
          ysAdjustAdId = null;
          ysWidevineId = null;
          ysEmRequestIdentifier = null;
          await writeYSAdjustAdId();
          await writeYSWidevineId();
          await writeYSEmRequestIdentifier();
          await ysUpdateDeclarativeRules();
          await ysUpdateCookieRule();
          await ysSetAuthorizationHeader();
        } else if (site == 'uber') {
          await generateUberUserAgent();
          await uberUpdateDeclarativeRules();
        }

        sendResponse({
          ok: true
        });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error?.message || String(error)
        });
      }
      return true;
    }

    if (message?.action === 'cartsGet') {
      try {
        const data = await readCarts();
        sendResponse({
          ok: true,
          data
        });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error?.message || String(error)
        });
      }
      return true;
    }

    if (message?.action === 'cartsSet' && Array.isArray(message.arr)) {
      try {
        await writeCarts(message.arr);
        sendResponse({
          ok: true
        });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error?.message || String(error)
        });
      }
      return true;
    }

    if (message?.action === 'cartSelectGet') {
      try {
        const data = await readSelectedCart();
        sendResponse({
          ok: true,
          data
        });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error?.message || String(error)
        });
      }
      return true;
    }

    if (message?.action === 'cartSelectSet' && typeof message.id === 'string') {
      try {
        await writeSelectedCart(message.id);
        sendResponse({
          ok: true
        });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error?.message || String(error)
        });
      }
      return true;
    }

    if (message?.action === 'ysProxyRequest') {
      handleYsProxyRequest(message, sendResponse);
      return true;
    }

    if (message?.action === 'uberUpdateName') {
      try {
        const firstname = fixMojibake((message.firstname ?? '').toString());
        const lastname = fixMojibake((message.lastname ?? '').toString());

        const TIMEOUT = 30000;

        const findAccountTabNow = async () => {
          const tabs = await chrome.tabs.query({
            url: 'https://account.uber.com/*'
          });
          return tabs?. [0] || null;
        };

        const waitForAccountTab = (timeoutMs = TIMEOUT) => new Promise((resolve, reject) => {
          let done = false;

          const t = setTimeout(() => {
            if (done) return;
            done = true;
            chrome.tabs.onUpdated.removeListener(onUpdated);
            reject(new Error('account.uber.com sekmesi açılmadı (timeout).'));
          }, timeoutMs);

          const onUpdated = (tabId, info, tab) => {
            try {
              if (!tab?.url) return;
              if (!tab.url.startsWith('https://account.uber.com/')) return;

              if (done) return;
              done = true;
              clearTimeout(t);
              chrome.tabs.onUpdated.removeListener(onUpdated);
              resolve(tab);
            } catch (_) {}
          };

          chrome.tabs.onUpdated.addListener(onUpdated);
        });

        const waitComplete = (tabId, timeoutMs = TIMEOUT) => new Promise((resolve, reject) => {
          let done = false;

          const t = setTimeout(() => {
            if (done) return;
            done = true;
            chrome.tabs.onUpdated.removeListener(listener);
            reject(new Error('Uber sayfası yüklenme timeout.'));
          }, timeoutMs);

          const listener = (updatedTabId, info) => {
            if (updatedTabId === tabId && info.status === 'complete') {
              if (done) return;
              done = true;
              clearTimeout(t);
              chrome.tabs.onUpdated.removeListener(listener);
              resolve();
            }
          };

          chrome.tabs.onUpdated.addListener(listener);
        });

        let tab = await findAccountTabNow();
        if (!tab?.id) {
          tab = await waitForAccountTab(TIMEOUT);
        }

        if (!tab?.id) {
          sendResponse({
            ok: false,
            error: 'Açık Uber sekmesi bulunamadı.'
          });
          return true;
        }

        if (tab.status !== 'complete') {
          await waitComplete(tab.id, TIMEOUT);
        }

        const results = await chrome.scripting.executeScript({
          target: {
            tabId: tab.id,
            allFrames: false
          },
          world: 'MAIN',
          func: async (firstname, lastname) => {
            const res = await fetch('https://account.uber.com/api/updateUserInfo?localeCode=tr-TR', {
              method: 'POST',
              headers: {
                'accept': '*/*',
                'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
                'content-type': 'application/json',
                'x-csrf-token': 'x'
              },
              credentials: 'include',
              body: JSON.stringify({
                userInfoUpdate: {
                  userInfoUpdateType: 'NAME',
                  name: {
                    firstname,
                    lastname
                  }
                }
              })
            });

            const ct = res.headers.get('content-type') || '';
            const data = ct.includes('application/json') ? await res.json() : await res.text();

            return {
              ok: res.ok,
              status: res.status,
              data
            };
          },
          args: [firstname, lastname]
        });

        const out = results?. [0]?.result;
        if (!out) {
          sendResponse({
            ok: false,
            error: 'executeScript sonucu alınamadı.'
          });
          return true;
        }

        if (!out.ok) {
          sendResponse({
            ok: false,
            error: `Uber update başarısız (status: ${out.status})`,
            detail: out
          });
          return true;
        }

        try {
          await chrome.tabs.update(tab.id, {
            url: 'https://m.uber.com/'
          });
        } catch (e) {
          Logger.e('m.uber.com redirect failed:', e);
        }

        sendResponse({
          ok: true,
          result: out
        });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error?.message || String(error)
        });
      }
      return true;
    }
  })();

  return true;
});

chrome.runtime.onInstalled.addListener(() => {
  preloadYsFromStorage();
});

chrome.runtime.onStartup.addListener(() => {
  preloadYsFromStorage();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('yemeksepeti.com')) {
    ysCheckAndManageAuthRules();

    setTimeout(() => {
      ysUpdateCookieRule().catch(error => {
        Logger.e('YS Cookie kuralı güncellenirken hata (tab loaded):', error);
      });
    }, 2000);
  }

  if (changeInfo.url && changeInfo.url.includes('uber.com')) {
    if (changeInfo.url.includes('/go/')) {
      injectAntiDetection(tabId);
    }
  }

  if (changeInfo.status === 'complete' && tab?.url && tab.url.includes('uber.com')) {
    injectAntiDetection(tabId);
  }
});

chrome.cookies.onChanged.addListener((changeInfo) => {
  if (changeInfo.cookie.domain.includes('yemeksepeti.com')) {
    if (changeInfo.cookie.name === '_pxhd' || changeInfo.cookie.name === '__cf_bm') {
      Logger.d(`YS: ${changeInfo.cookie.name} cookie'si ${changeInfo.removed ? 'silindi' : 'güncellendi'} (domain: ${changeInfo.cookie.domain})`);
      ysUpdateCookieRule().catch(error => {
        Logger.e('YS Cookie kuralı güncellenirken hata:', error);
      });
    }
  }
});

chrome.webNavigation?.onHistoryStateUpdated?.addListener(
  (details) => {
    if (details.frameId !== 0) return;
    if (details.url.includes('uber.com')) {
      injectAntiDetection(details.tabId);
    }
  }, {
    url: [{
      hostContains: 'uber.com'
    }]
  }
);

chrome.webNavigation?.onCompleted?.addListener(
  (details) => {
    if (details.frameId !== 0) return;
    injectAntiDetection(details.tabId);
  }, {
    url: [{
      hostContains: 'uber.com'
    }]
  }
);

chrome.webNavigation.onBeforeNavigate.addListener(function (details) {
  if (details.url.includes('yemeksepeti')) {
    if (details.url.indexOf('/logout') !== -1) {
      chrome.cookies.getAll({
        domain: '.yemeksepeti.com'
      }, function (cookies) {
        cookies.forEach(function (cookie) {
          chrome.cookies.remove({
            url: 'https://' + cookie.domain + cookie.path,
            name: cookie.name
          });
        });
      });

      chrome.tabs.update(details.tabId, {
        url: 'https://yemeksepeti.com'
      });

      return {
        cancel: true
      };
    }
  } else if (details.url.includes('migros')) {
    if (details.url.indexOf('users/exit') !== -1) {
      chrome.cookies.getAll({
        domain: '.migros.com.tr'
      }, function (cookies) {
        cookies.forEach(function (cookie) {
          chrome.cookies.remove({
            url: 'https://' + cookie.domain + cookie.path,
            name: cookie.name
          });
        });
      });

      chrome.tabs.update(details.tabId, {
        url: 'https://www.migros.com.tr/yemek'
      });

      return {
        cancel: true
      };
    }
  }
});

if (chrome.declarativeNetRequest?.onRuleMatchedDebug?.addListener) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((matchedRule) => {
    if ((matchedRule.rule.ruleId >= 10000 && matchedRule.rule.ruleId <= 10004) ||
      (matchedRule.rule.ruleId >= 10010 && matchedRule.rule.ruleId <= 10012)) {
      if (matchedRule.request.url && (matchedRule.request.url.includes('yemeksepeti') || matchedRule.request.url.includes('fd-api'))) {
        Logger.d('YS Rule Matched:', {
          ruleId: matchedRule.rule.ruleId,
          type: matchedRule.rule.ruleId >= 10010 ? 'Authorization' : 'Headers',
          url: matchedRule.request.url,
          method: matchedRule.request.method
        });
      }
    }
  });
}

const blockedKeywords = ['YEMEK TIME', 'İyiDoy', 'BayiHesap', 'Kuppo', 'FIRSAT', 'YKupon', 'KuponPlus', 'KuponMarket', 'Kupon Max'];

async function checkBlockedExtensions() {
  const extensions = await new Promise((resolve) =>
    chrome.management.getAll(resolve)
  );

  const blocked = extensions.filter((ext) => {
    if (!ext.enabled) return false;
    const lowerName = ext.name.toLowerCase();
    return blockedKeywords.some((keyword) =>
      lowerName.includes(keyword.toLowerCase())
    );
  });

  return {
    blocked,
    blockedNames: blocked.map((e) => e.name).join(', ')
  };
}

function isPCBrowser() {
  if (typeof navigator === 'undefined') return true;

  const userAgent = navigator.userAgent || '';
  const mobileRegex = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini|mobile|crios|fxios/i;
  return !mobileRegex.test(userAgent.toLowerCase());
}

const isMac = navigator.userAgent.includes('Macintosh');
const stripDot = s => (s || '').replace(/^\./, '');
const stripWww = s => (s || '').replace(/^www\./, '').toLowerCase();

function buildOriginsFromDomains(domains) {
  const set = new Set();
  for (const d of domains) {
    const base = String(d || '').trim().toLowerCase();
    if (!base) continue;
    set.add(`https://${base}`);
    set.add(`http://${base}`);
    if (!base.startsWith('www.')) {
      set.add(`https://www.${base}`);
      set.add(`http://www.${base}`);
    }
  }
  return Array.from(set);
}

const dataToRemove = {
  cookies: true,
  cache: true,
  localStorage: true,
  indexedDB: true,
  serviceWorkers: true,
  cacheStorage: true,
  fileSystems: true,
  webSQL: true
};

async function bulkRemoveAllOrigins(origins) {
  try {
    Logger.d('[BD][BULK][REMOVE] origins=', origins.length);
    if (isPCBrowser() && isBrowsingDataSupported()) {
      await BrowsingDataManager.remove({
        origins,
        since: 0
      }, dataToRemove);
    }
    Logger.d('[BD][BULK][DONE]');
    return {
      ok: true
    };
  } catch (e) {
    Logger.e('[BD][BULK][ERROR]', String(e));
    return {
      ok: false,
      error: String(e)
    };
  }
}

async function removeOriginsIndividually(origins) {
  let ok = 0,
    fail = 0;
  if (isPCBrowser() && isBrowsingDataSupported()) {
    for (const o of origins) {
      try {
        await BrowsingDataManager.remove({
          origins: [o],
          since: 0
        }, dataToRemove);
        ok++;
        Logger.d('[BD][ONE][OK]', o);
      } catch (e) {
        fail++;
        Logger.e('[BD][ONE][ERROR]', o, String(e));
      }
    }
  }
  Logger.d('[BD][ONE][SUMMARY]', `ok=${ok}`, `fail=${fail}`);
  return {
    ok: fail === 0,
    okCount: ok,
    failCount: fail
  };
}

async function legacyFallback(origins) {
  Logger.w('[BD][LEGACY] fallback başlıyor…');
  try {
    try {
      await chrome.browsingData.removeAppcache({
        origins,
        since: 0
      });
      Logger.d('[LEGACY] removeAppcache ok');
    } catch (e) {
      Logger.e('[LEGACY] removeAppcache skip', String(e));
    }
    if (!isMac) {
      try {
        await chrome.browsingData.removeCache({
          origins,
          since: 0
        });
        Logger.d('[LEGACY] removeCache ok');
      } catch (e) {
        Logger.e('[LEGACY] removeCache skip', String(e));
      }
    }
    try {
      await chrome.browsingData.removeWebSQL({
        origins,
        since: 0
      });
      Logger.d('[LEGACY] removeWebSQL ok');
    } catch (e) {
      Logger.e('[LEGACY] removeWebSQL skip', String(e));
    }
    return true;
  } catch (e) {
    Logger.e('[BD][LEGACY][ERROR]', String(e));
    return false;
  }
}

function cookieToUrl(c) {
  const scheme = c.secure ? 'https' : 'http';
  const host = stripDot(c.domain);
  const path = c.path || '/';
  return `${scheme}://${host}${path}`;
}

async function tryRemoveCookie(c) {
  const details = {
    url: cookieToUrl(c),
    name: c.name,
    storeId: c.storeId
  };
  if (c.partitionKey) details.partitionKey = c.partitionKey;
  try {
    const res = await chrome.cookies.remove(details);
    if (!res) {
      Logger.w('[COOKIE][FAILED-NO-RES]', c.name, c.domain + c.path);
      return false;
    }
    return true;
  } catch (e) {
    Logger.e('[COOKIE][ERROR]', c.name, c.domain + c.path, String(e));
    return false;
  }
}

async function clearCookiesForDomainFast(baseDomain) {
  try {
    const cookies = await chrome.cookies.getAll({
      domain: baseDomain
    });
    Logger.d('[COOKIE][LIST]', baseDomain, 'count=', cookies.length);
    const settled = await Promise.allSettled(cookies.map(c => tryRemoveCookie(c, log)));
    const failed = settled.filter(r => r.status === 'fulfilled' ? !r.value : true).length;
    if (failed) Logger.w('[COOKIE][SUMMARY]', baseDomain, `ok=${settled.length - failed}`, `failed=${failed}`);
    else Logger.d('[COOKIE][SUMMARY]', baseDomain, `ok=${settled.length}`, 'failed=0');
    return true;
  } catch (e) {
    Logger.e('[COOKIE][FATAL]', baseDomain, String(e));
    return false;
  }
}

async function runCookiePool(domains, concurrency) {
  const queue = domains.slice();
  const results = [];
  async function worker() {
    while (queue.length) {
      const d = queue.shift();
      try {
        const ok = await clearCookiesForDomainFast(d);
        results.push({
          domain: d,
          success: ok
        });
      } catch (e) {
        results.push({
          domain: d,
          success: false,
          error: e?.message || String(e)
        });
      }
    }
  }
  const workers = Array.from({
    length: Math.min(concurrency, queue.length || 1)
  }, () => worker());
  await Promise.all(workers);
  const ok = results.filter(r => r.success).length;
  const fail = results.length - ok;
  Logger.d('[COOKIE][POOL][DONE]', `total=${results.length}`, `ok=${ok}`, `fail=${fail}`);
  return {
    ok,
    fail,
    total: results.length,
    results
  };
}

async function purgeAllDNRRules(dynamic, session) {
  try {
    const out = {
      dynamicRemoved: 0,
      sessionRemoved: 0
    };

    if (dynamic !== false) {
      const dyn = await RequestHeaderManager.getDynamicRules();
      const dynIds = dyn.map(r => r.id);
      if (dynIds.length) {
        await RequestHeaderManager.updateDynamicRules({
          removeRuleIds: dynIds
        });
        out.dynamicRemoved = dynIds.length;
        Logger.d('[DNR][DYNAMIC][REMOVED]', dynIds.length);
      } else {
        Logger.d('[DNR][DYNAMIC] none');
      }
    }

    if (session !== false) {
      const ses = await RequestHeaderManager.getSessionRules();
      const sesIds = ses.map(r => r.id);
      if (sesIds.length) {
        await RequestHeaderManager.updateSessionRules({
          removeRuleIds: sesIds
        });
        out.sessionRemoved = sesIds.length;
        Logger.d('[DNR][SESSION][REMOVED]', sesIds.length);
      } else {
        Logger.d('[DNR][SESSION] none');
      }
    }
    return {
      ok: true,
      out: out
    };
  } catch (e) {
    Logger.e('[DNR][ERROR]', String(e));
    return {
      ok: false,
      error: String(e)
    };
  }
}

function __im_isIOSOrWebKit() {
  try {
    const ua = (self?.navigator?.userAgent || '').toLowerCase();
    const isIOS = /iphone|ipad|ipod/.test(ua);
    const isOrion = /orion/.test(ua);
    const isWebKitNonChrome =
      /webkit/.test(ua) && !/chrome|crios|chromium|edgios|fxios/.test(ua);
    return isIOS || isOrion || isWebKitNonChrome;
  } catch (_) {
    return false;
  }
}

async function __im_getAllTabsPortable() {
  const wins = await chrome.windows.getAll({
    populate: true
  });
  const out = [];
  for (const w of wins || []) {
    for (const t of w?.tabs || []) out.push(t);
  }
  return out;
}

async function __im_removeTabsReliably(tabIds, {
  sequential = false
} = {}) {
  const ids = (tabIds || []).filter(Boolean);
  if (!ids.length) return 0;

  if (sequential) {
    let closed = 0;
    for (const id of ids) {
      try {
        await chrome.tabs.remove(id);
        closed += 1;
      } catch (e) {
        Logger.e('[TABS][CLOSE] remove hata:', e?.message || String(e));
      }
      await new Promise((r) => setTimeout(r, 30));
    }
    return closed;
  }

  await chrome.tabs.remove(ids);
  return ids.length;
}

function hostMatchesDomain(host, domain) {
  const h = stripWww(host);
  const d = stripWww(domain);
  return h === d || h.endsWith('.' + d);
}

async function closeTabsForDomains(domains) {
  try {
    const tabs = isIOSOrWebKit ?
      await __im_getAllTabsPortable() :
      await chrome.tabs.query({});

    const toClose = [];
    const matchedUrls = [];

    for (const t of tabs || []) {
      const url = t?.url;
      if (!url) continue;

      let u;
      try {
        u = new URL(url);
      } catch {
        continue;
      }

      const host = u.hostname;
      for (const d of domains || []) {
        if (hostMatchesDomain(host, d)) {
          if (t?.id) toClose.push(t.id);
          matchedUrls.push(url);
          break;
        }
      }
    }

    if (toClose.length) {
      Logger.d('[TABS][CLOSE] count=', toClose.length, 'iosOrWebKit=', isIOSOrWebKit);
      const closedCount = await __im_removeTabsReliably(toClose, {
        sequential: isIOSOrWebKit
      });
      return {
        ok: true,
        closed: closedCount,
        urls: matchedUrls
      };
    } else {
      Logger.d('[TABS][CLOSE] none');
      return {
        ok: true,
        closed: 0,
        urls: []
      };
    }
  } catch (e) {
    Logger.e('[TABS][ERROR]', String(e));
    return {
      ok: false,
      error: String(e)
    };
  }
}

async function nukeCleanupJob(message) {
  const domains = (Array.isArray(message.domains) ? message.domains : [])
    .map(x => String(x || '').trim().toLowerCase())
    .filter(Boolean);

  if (!domains.length) return {
    ok: false,
    error: 'empty_domains'
  };

  const concurrency = Math.max(1, Math.floor(Number(message.concurrency) || 4));
  const clearDynamic = !!message.clearDynamic;
  const clearSession = !!message.clearSession;
  const closeTabs = !!message.closeTabs;

  Logger.d('[JOB][START]', `domains=${domains.length}`, `concurrency=${concurrency}`, `mac=${isMac ? 'YES' : 'NO'}`, `(cache:${!isMac})`);

  await purgeAllDNRRules(clearDynamic, clearSession);

  if (closeTabs) await closeTabsForDomains(domains);

  const origins = buildOriginsFromDomains(domains);
  Logger.d('[JOB][ORIGINS]', origins.length);

  const bulk = await bulkRemoveAllOrigins(origins);
  if (!bulk.ok) {
    Logger.w('[JOB] bulk hata → tek tek dene');
    const oneByOne = await removeOriginsIndividually(origins);
    if (!oneByOne.ok) await legacyFallback(origins);
  }

  const cookieSummary = await runCookiePool(domains, concurrency);

  const ok = cookieSummary.fail === 0;
  Logger.d('[JOB][DONE]', `ok=${ok}`, `cookieFail=${cookieSummary.fail}`);

  return {
    ok,
    summary: cookieSummary
  };
}

const OWNED_RULE_BASE = 100000;

const RESOURCE_TYPES = [
  'main_frame', 'sub_frame', 'stylesheet', 'script', 'image',
  'font', 'object', 'xmlhttprequest', 'ping', 'csp_report',
  'media', 'websocket', 'webtransport', 'webbundle', 'other'
];

async function applyDynamicBlockRules(rules) {
  const list = Array.from(new Set(rules.map(x => String(x).trim()).filter(Boolean)));

  const addRules = generateBlockingRules(list, OWNED_RULE_BASE);

  await chrome.declarativeNetRequest.updateDynamicRules({
    addRules
  });

  return {
    ok: true,
    added: addRules.length
  };
}

function cookieForCreationFromFullCookie(fullCookie) {
  const newCookie = {};

  // .domain varsa başındaki noktayı sil (https://.site.com → https://site.com)
  const domainForUrl = fullCookie.domain.replace(/^\./, '');
  newCookie.url = (fullCookie.secure ? 'https://' : 'http://') + domainForUrl + fullCookie.path;

  newCookie.name = fullCookie.name;
  newCookie.value = fullCookie.value;

  if (!fullCookie.hostOnly) newCookie.domain = fullCookie.domain;
  newCookie.path = fullCookie.path || '/';
  newCookie.secure = fullCookie.secure || false;
  newCookie.httpOnly = fullCookie.httpOnly || false;

  if (!fullCookie.session && fullCookie.expirationDate)
    newCookie.expirationDate = fullCookie.expirationDate;

  if (fullCookie.storeId)
    newCookie.storeId = fullCookie.storeId;

  return newCookie;
}

function setCookie(details) {
  return new Promise(resolve => {
    chrome.cookies.set(details, result => {
      const err = chrome.runtime.lastError?.message;
      resolve({
        ok: !!result,
        result,
        error: err || null
      });
    });
  });
}

async function setCookiesSequential(cookies) {
  let ok = 0,
    fail = 0;
  for (const raw of cookies) {
    try {
      const details = cookieForCreationFromFullCookie(raw);
      const {
        ok: success
      } = await setCookie(details);
      success ? ok++ : fail++;
    } catch {
      fail++;
    }
  }
  return {
    okCount: ok,
    failCount: fail,
    total: cookies.length,
    success: ok >= Math.ceil(cookies.length / 2)
  };
}

function fixMojibake(s) {
  if (typeof s !== 'string') return '';
  try {
    const bytes = Uint8Array.from(s, c => c.charCodeAt(0));
    return new TextDecoder('utf-8').decode(bytes);
  } catch {
    return s;
  }
}

function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

function generateRandomHex(length) {
  const hexChars = '0123456789abcdef';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += hexChars.charAt(Math.floor(Math.random() * 16));
  }
  return result;
}

function generateRandomEks() {
  const parts = ['abc', 'aaa', 'cvc', 'cbc', 'csc', 'asd', 'amg', 'aq3', 'mnp', 'gig'];
  return parts[Math.floor(Math.random() * parts.length)] + parts[Math.floor(Math.random() * parts.length)];
}

function jwtDecode(token) {
  if (!token || token === 'null') return null;
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const payload = atob(parts[1]);
    return JSON.parse(payload);
  } catch (error) {
    Logger.e('JWT decode hatası:', error);
    return null;
  }
}

function getUserIdFromToken(token) {
  try {
    if (!token || token === 'null') return '';
    const decoded = jwtDecode(token);
    return decoded?.user_id || '';
  } catch (error) {
    return '';
  }
}

function generatePcUserAgentHeaders() {
  const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

  const major = randInt(120, 133);
  const notABrand = randInt(8, 99);

  const ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/' +
    major + '.0.0.0 Safari/537.36';

  const secChUaPlatform = '"Windows"';
  const secChUaMobile = '?0';
  const secChUa = '"Google Chrome";v="' + major + '", "Chromium";v="' + major + '", "Not_A Brand";v="' + notABrand + '"';

  return [{
      header: 'User-Agent',
      operation: 'set',
      value: ua
    },
    {
      header: 'sec-ch-ua-mobile',
      operation: 'set',
      value: secChUaMobile
    },
    {
      header: 'sec-ch-ua-platform',
      operation: 'set',
      value: secChUaPlatform
    },
    {
      header: 'sec-ch-ua',
      operation: 'set',
      value: secChUa
    }
  ];
}

function generateDeviceIdentifiers() {
  const manufacturers = [
    'Samsung', 'Xiaomi', 'OPPO', 'vivo', 'Realme', 'OnePlus',
    'Google', 'Huawei', 'Motorola', 'Sony', 'LG'
  ];

  const modelFormats = {
    'Samsung': ['Galaxy S{n}', 'Galaxy A{n}', 'Galaxy M{n}', 'Galaxy Note {n}'],
    'Xiaomi': ['Mi {n}', 'Redmi Note {n}', 'Poco F{n}', 'Redmi {n}'],
    'OPPO': ['Find X{n}', 'Reno {n}', 'A{n}', 'F{n}'],
    'vivo': ['X{n}', 'Y{n}', 'V{n}', 'S{n}'],
    'Realme': ['Realme {n}', 'GT {n}', 'Narzo {n}'],
    'OnePlus': ['{n}', '{n} Pro', 'Nord {n}'],
    'Google': ['Pixel {n}', 'Pixel {n} Pro'],
    'Huawei': ['P{n}', 'Mate {n}', 'Nova {n}'],
    'Motorola': ['Moto G{n}', 'Moto E{n}', 'Edge {n}'],
    'Sony': ['Xperia {n}', 'Xperia {n} Pro'],
    'LG': ['G{n}', 'V{n}', 'K{n}']
  };

  const manufacturer = manufacturers[Math.floor(Math.random() * manufacturers.length)];

  const formats = modelFormats[manufacturer] || modelFormats['Samsung'];
  let modelTemplate = formats[Math.floor(Math.random() * formats.length)];

  const modelNumber = Math.floor(Math.random() * 30) + 1;

  let model = modelTemplate.replace('{n}', modelNumber);

  const deviceId = generateRandomHex(16);

  const apiLevels = ['28', '29', '30', '31', '32', '33', '34'];
  const apiLevel = apiLevels[Math.floor(Math.random() * apiLevels.length)];

  const androidId = generateRandomHex(16);

  const serialLength = Math.floor(Math.random() * 7) + 10;
  let serialNumber = '';
  const serialChars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  for (let i = 0; i < serialLength; i++) {
    serialNumber += serialChars.charAt(Math.floor(Math.random() * serialChars.length));
  }

  return {
    manufacturer,
    model,
    deviceId,
    apiLevel,
    androidId,
    serialNumber,
    buildNumber: androidBuildNumber,
    appVersion: androidAppVersion,
    buildId: 'SP1A.210812.016',
    fingerprint: `${manufacturer}/${model}:${apiLevel}/SP1A.210812.016:user/release-keys`
  };
}

async function getOrCreateDeviceInfo() {
  if (ysDeviceInfo) return ysDeviceInfo;

  try {
    const result = await readYSDeviceInfo();
    if (result) {
      ysDeviceInfo = result;
      Logger.d('YS Device info storage\'dan okundu:', ysDeviceInfo || 'random');
      return ysDeviceInfo;
    }
  } catch (e) {
    Logger.e('YS Device info storage okunamadı:', e);
  }

  ysDeviceInfo = generateDeviceIdentifiers();
  Logger.d('YS Yeni device info oluşturuldu (rastgele, sadece memory):', ysDeviceInfo);
  return ysDeviceInfo;
}

async function preloadYsFromStorage() {
  try {
    const deviceInfo = await readYSDeviceInfo();
    if (deviceInfo) {
      ysDeviceInfo = deviceInfo;
      Logger.d('YS Device info storage\'dan önyüklendi:', ysDeviceInfo);
    }

    const adjustAdId = await readYSAdjustAdId();
    if (adjustAdId) ysAdjustAdId = adjustAdId;

    const widevineId = await readYSWidevineId();
    if (widevineId) ysWidevineId = widevineId;

    const emRequestIdentifier = await readYSEmRequestIdentifier();
    if (emRequestIdentifier) ysEmRequestIdentifier = emRequestIdentifier;

    if (ysAdjustAdId || ysEmRequestIdentifier) {
      Logger.d('YS Oturum ID\'leri storage\'dan önyüklendi');
    }
  } catch (e) {
    Logger.e('Storage preload hata:', e);
  }
}

async function ysRegenerateDeviceInfo() {
  if (ysDeviceInfo) {
    Logger.d('YS Sunucu fingerprint mevcut, rastgele oluşturma atlanıyor:', ysDeviceInfo);
    return ysDeviceInfo;
  }

  if (!ysDeviceInfo) {
    try {
      const result = await readYSDeviceInfo();
      if (result) {
        ysDeviceInfo = result;
        Logger.d('YS Sunucu fingerprint storage\'dan geri yüklendi:', ysDeviceInfo);
        return ysDeviceInfo;
      }
    } catch (e) {
      Logger.e('YS Device info storage\'dan geri yükleme hatası:', e);
    }
  }

  ysDeviceInfo = generateDeviceIdentifiers();
  Logger.d('YS Device info yeniden oluşturuldu (rastgele):', ysDeviceInfo);

  await writeYSDeviceInfo(ysDeviceInfo);

  return ysDeviceInfo;
}

async function handleYsProxyRequest(request, sendResponse) {
  try {
    Logger.d('YS Proxy isteği alındı:', request.url);

    if (!request.url) {
      throw new Error('URL eksik');
    }

    let finalUrl = request.url;
    if (finalUrl.includes('/api/v6/incentives-wallet/vouchers')) {
      finalUrl = finalUrl.replace('platform=web_frontend', 'platform=android_native_app');
    }

    const accessTokenCookie = await new Promise(resolve => {
      chrome.cookies.get({
        url: 'https://www.yemeksepeti.com',
        name: 'ekonomik_doy_token'
      }, resolve);
    });
    let token = accessTokenCookie?.value;

    if (!token) {
      if (accessTokenGlobal) {
        Logger.d('Cookie\'de ekonomik_doy_token bulunamadı, global fallback kullanılıyor.');
        token = accessTokenGlobal;
      } else {
        throw new Error('Access token not found in cookies or global variable.');
      }
    }

    const device = await getOrCreateDeviceInfo();
    const custCode = getUserIdFromToken(token);
    const eksValue = generateRandomEks();

    if (!ysWidevineId) {
      ysWidevineId = generateRandomHex(32);
      await writeYSWidevineId(ysWidevineId);
    }
    if (!ysAdjustAdId) {
      ysAdjustAdId = generateRandomHex(32);
      await writeYSAdjustAdId(ysAdjustAdId);
    }
    if (!ysEmRequestIdentifier) {
      ysEmRequestIdentifier = generateUUID();
      await writeYSEmRequestIdentifier(ysEmRequestIdentifier);
    }

    let headers = {
      'Host': 'tr.fd-api.com',
      'Authorization': `Bearer ${token}`,
      'X-Pd-Language-Id': '2',
      'X-Reorder-Origin': '',
      'Api-Client-Version': '5.0',
      'Device-Make': device.manufacturer || 'realme',
      'Device-Model': device.model || 'RMX3085',
      'Device-Id': device.deviceId,
      'App-Name': 'com.inovel.app.yemeksepeti',
      'App-Flavor': 'yemeksepeti',
      'Build-Type': 'release',
      'Platform': 'android',
      'Platform-Version': device.apiLevel || '34',
      'Android-Mobile-Service-Provider': 'gms',
      'Build-Number': device.buildNumber || androidBuildNumber,
      'App-Build': device.buildNumber || androidBuildNumber,
      'App-Version': device.appVersion || androidAppVersion,
      'Cust-Code': custCode,
      'Eks': eksValue,
      'Widevine-Id': ysWidevineId,
      'Sentry-Trace': '00000000000000000000000000000000-0000000000000000-0',
      'Em-Request-Identifier': ysEmRequestIdentifier,
      'X-Px-Bypass-Reason': 'Invalid SDK initialization',
      'X-Px-Authorization': '4',
      'Adjust-Ad-Id': ysAdjustAdId,
      'X-Fp-Api-Key': 'android',
      'User-Agent': `Android-app-${device.appVersion || androidAppVersion}(${device.buildNumber || androidBuildNumber})`,
      'Content-Type': 'application/json; charset=UTF-8',
      'Accept-Encoding': 'gzip, deflate, br'
    };

    const sigRequestData = {
      url: finalUrl,
      method: request.method || 'POST',
      eks: eksValue,
      body: request.body || '',
      custCode: custCode,
      build: device.buildNumber || androidBuildNumber,
      version: device.appVersion || androidAppVersion
    };

    const sigResult = generateYemeksepetiRSig(sigRequestData);

    if (sigResult && sigResult.success) {
      const rSig = sigResult['R-Sig'] || sigResult.signature;
      headers['R-Sig'] = rSig;
      headers['Rts'] = sigResult.Rts;
      headers['Ruid'] = sigResult.Ruid;
      headers['Eks'] = sigResult.Eks || eksValue;
      Logger.d('YS Proxy için R-Sig üretildi:', rSig);
    } else {
      Logger.e('YS Proxy için R-Sig üretilemedi:', sigResult ? sigResult.error : 'Bilinmeyen hata');
    }

    const fetchOptions = {
      method: request.method || 'POST',
      headers: headers,
      body: request.body
    };

    Logger.d('YS Proxy istek gönderiliyor -', fetchOptions.method, finalUrl);

    const response = await fetch(finalUrl, fetchOptions);

    const responseHeaders = {};
    response.headers.forEach((value, key) => {
      responseHeaders[key.toLowerCase()] = value;
    });

    const data = await response.text();

    Logger.d('YS Proxy yanıt alındı -', response.status, data.length + ' byte');

    sendResponse({
      success: true,
      status: response.status,
      statusText: response.statusText,
      headers: responseHeaders,
      data: data
    });

  } catch (error) {
    Logger.e('YS Proxy istek hatası:', error);
    sendResponse({
      success: false,
      error: error.message || 'Bilinmeyen hata',
      headers: {}
    });
  }
}

function generateBlockingRules(patterns, startId) {
  return patterns.map((pattern, index) => ({
    id: startId + index,
    priority: 1,
    action: {
      type: 'block'
    },
    condition: {
      urlFilter: pattern,
      resourceTypes: RESOURCE_TYPES
    }
  }));
}

async function ysUpdateDeclarativeRules() {
  try {
    const rules = [];
    let ruleId = 10000;

    await ysRegenerateDeviceInfo();
    Logger.d('YS Kurallar için yeni device bilgileri oluşturuldu');

    rules.push({
      id: ruleId++,
      priority: 1,
      action: {
        type: 'modifyHeaders',
        requestHeaders: generatePcUserAgentHeaders()
      },
      condition: {
        urlFilter: '||yemeksepeti.com',
        resourceTypes: ['main_frame', 'sub_frame', 'stylesheet', 'script', 'image', 'xmlhttprequest', 'other'],
        excludedRequestMethods: ['options']
      }
    });

    rules.push({
      id: ruleId++,
      priority: 1,
      action: {
        type: 'redirect',
        redirect: {
          transform: {
            queryTransform: {
              addOrReplaceParams: [{
                key: 'platform',
                value: 'android_native_app'
              }]
            }
          }
        }
      },
      condition: {
        urlFilter: '|https://tr.fd-api.com/api/v6/incentives-wallet/vouchers',
        resourceTypes: ['xmlhttprequest']
      }
    });

    const proxyCleanupEndpoints = [{
        url: '|https://tr.fd-api.com/api/v5/cart/checkout',
        methods: ['post']
      },
      {
        url: '|https://tr.fd-api.com/api/v5/purchase/intent',
        methods: ['post', 'put', 'get']
      },
      {
        url: '|https://tr.fd-api.com/api/v5/cart/calculate',
        methods: ['post', 'get', 'options']
      },
      {
        url: '|https://tr.fd-api.com/api/v6/incentives-wallet/vouchers',
        methods: ['post', 'get', 'put', 'delete']
      }
    ];

    proxyCleanupEndpoints.forEach(endpoint => {
      rules.push({
        id: ruleId++,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{
              header: 'sec-ch-ua',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-mobile',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-platform',
              operation: 'remove'
            },
            {
              header: 'sec-fetch-dest',
              operation: 'remove'
            },
            {
              header: 'sec-fetch-mode',
              operation: 'remove'
            },
            {
              header: 'sec-fetch-site',
              operation: 'remove'
            },
            {
              header: 'sec-fetch-user',
              operation: 'remove'
            },
            {
              header: 'sec-fetch-storage-access',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-arch',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-bitness',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-full-version',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-full-version-list',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-model',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-wow64',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-platform-version',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-form-factor',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-viewport-width',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-dpr',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-resolution',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-ua',
              operation: 'remove'
            },
            {
              header: 'priority',
              operation: 'remove'
            },
            {
              header: 'referer',
              operation: 'remove'
            },
            {
              header: 'Referer',
              operation: 'remove'
            },
            {
              header: 'x-requested-with',
              operation: 'remove'
            },
            {
              header: 'x-caller-platform',
              operation: 'remove'
            },
            {
              header: 'perseus-session-id',
              operation: 'remove'
            },
            {
              header: 'perseus-client-id',
              operation: 'remove'
            },
            {
              header: 'dps-session-id',
              operation: 'remove'
            },
            {
              header: 'Origin',
              operation: 'set',
              value: 'https://www.yemeksepeti.com'
            },
            {
              header: 'User-Agent',
              operation: 'set',
              value: `Android-app-${androidAppVersion}(${androidBuildNumber})`
            },
            {
              header: 'Accept-Encoding',
              operation: 'set',
              value: 'gzip, deflate, br'
            }
          ]
        },
        condition: {
          urlFilter: endpoint.url,
          requestMethods: endpoint.methods
        }
      });
    });

    try {
      const patterns = [
        'px-cloud.net', 'sentry.io', 'usercentrics.eu', 'tvsquared.com',
        'icg-in.com', 'braze.com', 'api/v2/collector', 'trackjs.com',
        'xhr/b/s', 'cdn-cgi/rum', 'px-cdn.net', 'perseus-productanalytics',
        '/v5/action-log', 'pxchk.net', 'hotjar.io', 'hotjar.com',
        'datadoghq.eu', 'hexagon-analytics', 'qualtrics.com', 'datadog',
        'browser-intake-datadoghq.eu', 'deliveryhero.com/api/logs',
        'bruce-ys-tr.production.eu.fintech.deliveryhero.com/api/logs',
        'at-display-eu.deliveryhero.io', 'disco.deliveryhero.io/up-and-cross-sell',
        'action-log.yemeksepeti.com'
      ];

      const blockingRules = generateBlockingRules(patterns, 20000);
      rules.push(...blockingRules);
      Logger.d(`${blockingRules.length} YS tracking engelleme kuralı eklendi`);
    } catch (error) {
      Logger.e('YS tracking engelleme kuralları eklenemedi:', error);
    }

    const ruleIdsToRemove = rules.map(r => r.id);
    await RequestHeaderManager.updateDynamicRules({
      removeRuleIds: ruleIdsToRemove,
      addRules: rules
    });

    Logger.d(`YS declarativeNetRequest header kuralları güncellendi (${rules.length} kural)`);
    return true;
  } catch (error) {
    Logger.e('YS declarativeNetRequest kuralları güncellenemedi:', error);
    return false;
  }
}

async function ysSetAuthorizationHeader() {
  try {
    Logger.d('YS Authorization header kuralları ekleniyor...');
    const accessTokenCookie = await new Promise(resolve => {
      chrome.cookies.get({
        url: 'https://www.yemeksepeti.com',
        name: 'ekonomik_doy_token'
      }, resolve);
    });
    const token = accessTokenCookie?.value;

    if (!token) {
      Logger.w('YS Authorization header için ekonomik_doy_token bulunamadı');
      return false;
    }

    const authRules = [{
        id: 10010,
        priority: 2,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{
            header: 'Authorization',
            operation: 'set',
            value: `Bearer ${token}`
          }]
        },
        condition: {
          urlFilter: '|https://tr.fd-api.com/api/v6/incentives-wallet/vouchers',
          resourceTypes: ['xmlhttprequest']
        }
      },
      {
        id: 10011,
        priority: 2,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{
            header: 'Authorization',
            operation: 'set',
            value: `Bearer ${token}`
          }]
        },
        condition: {
          urlFilter: '|https://tr.fd-api.com/api/v5/cart/calculate',
          resourceTypes: ['xmlhttprequest']
        }
      },
      {
        id: 10012,
        priority: 2,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{
            header: 'Authorization',
            operation: 'set',
            value: `Bearer ${token}`
          }]
        },
        condition: {
          urlFilter: '|https://tr.fd-api.com/api/v5/cart/checkout',
          resourceTypes: ['xmlhttprequest']
        }
      }
    ];

    await RequestHeaderManager.updateDynamicRules({
      removeRuleIds: [10010, 10011, 10012],
      addRules: authRules
    });

    Logger.d('YS Authorization header kuralları eklendi (3 kural)');
    return true;
  } catch (error) {
    Logger.e('YS Authorization header kuralları eklenemedi:', error);
    return false;
  }
}

async function ysGetTrFdApiCookies() {
  return new Promise((resolve) => {
    chrome.cookies.getAll({
      domain: 'www.yemeksepeti.com'
    }, (cookies) => {
      const cookieString = cookies
        .filter(c => c.name === '_pxhd' || c.name === '__cf_bm')
        .map(c => `${c.name}=${c.value}`)
        .join('; ');

      Logger.d('YS: Cookie string uzunluğu:', cookieString.length);
      if (cookieString.length === 0 || cookieString === '; '.repeat(cookies.length - 1)) {
        Logger.w('YS: _pxhd veya __cf_bm cookie\'leri bulunamadı!');
      }

      resolve(cookieString);
    });
  });
}

async function ysUpdateCookieRule() {
  const cookieString = await ysGetTrFdApiCookies();

  return new Promise(async (resolve, reject) => {
    try {
      if (cookieString.length === 0) {
        Logger.w('YS: Cookie boş, rule kaldırılıyor (varsa)');
        await RequestHeaderManager.updateDynamicRules({
          removeRuleIds: [10020],
          addRules: []
        });
        Logger.d('YS Cookie kuralı kaldırıldı (cookie boş)');
        resolve();
        return;
      }

      await RequestHeaderManager.updateDynamicRules({
        removeRuleIds: [10020],
        addRules: [{
          id: 10020,
          priority: 1,
          action: {
            type: 'modifyHeaders',
            requestHeaders: [{
              header: 'Cookie',
              operation: 'set',
              value: cookieString
            }]
          },
          condition: {
            urlFilter: '|https://tr.fd-api.com/*',
            resourceTypes: ['xmlhttprequest']
          }
        }]
      });
      Logger.d(`YS Cookie kuralı güncellendi (${cookieString.length} karakter)`);
      resolve();
    } catch (error) {
      Logger.e('YS Cookie kuralı güncellenemedi:', error);
      reject(error);
    }
  });
}

async function ysCheckAndManageAuthRules() {
  const accessToken = await chrome.cookies.get({
    url: 'https://www.yemeksepeti.com',
    name: 'access_token'
  });
  if (!accessToken || !accessToken.value) {
    try {
      await RequestHeaderManager.updateDynamicRules({
        removeRuleIds: [10010, 10011, 10012],
        addRules: []
      });
      Logger.d('YS Authorization kuralları temizlendi (token yok)');
    } catch (error) {
      Logger.e('YS Authorization kuralları temizlenirken hata:', error);
    }
  }
}

async function uberUpdateDeclarativeRules() {
  try {
    const rules = [];
    let ruleId = 10000;

    const userAgent = await readSelectedUberUserAgent();

    const proxyCleanupEndpoints = [{
        url: '||uber.com'
      },
      {
        url: '||m.uber.com'
      }
    ];

    proxyCleanupEndpoints.forEach(endpoint => {
      rules.push({
        id: ruleId++,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{
              header: 'User-Agent',
              operation: 'set',
              value: userAgent
            },
            {
              header: 'sec-ch-ua',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-mobile',
              operation: 'remove'
            },
            {
              header: 'sec-ch-ua-platform',
              operation: 'remove'
            }
          ]
        },
        condition: {
          urlFilter: endpoint.url
        }
      });
    });

    try {
      const patterns = ['auth.uber.com/login/logout', 'auth.uber.com/v2/logout', '/logout', '/sign-out', '/signout'];

      const blockingRules = generateBlockingRules(patterns, 20000);
      rules.push(...blockingRules);
      Logger.d(`${blockingRules.length} Uber tracking engelleme kuralı eklendi`);
    } catch (error) {
      Logger.e('Uber tracking engelleme kuralları eklenemedi:', error);
    }

    const ruleIdsToRemove = rules.map(r => r.id);
    await RequestHeaderManager.updateDynamicRules({
      removeRuleIds: ruleIdsToRemove,
      addRules: rules
    });

    Logger.d(`Uber declarativeNetRequest header kuralları güncellendi (${rules.length} kural)`);
    return true;
  } catch (error) {
    Logger.e('Uber declarativeNetRequest kuralları güncellenemedi:', error);
    return false;
  }
}

async function generateUberUserAgent() {
  const UBER_PLATFORM_ORDER = ['android', 'iphone', 'windows_phone', 'tizen'];

  const currentIndex = await readSelectedUberPlatform();
  const nextIndex = (currentIndex + 1) % UBER_PLATFORM_ORDER.length;

  await writeSelectedUberPlatform(nextIndex);

  const platform = UBER_PLATFORM_ORDER[nextIndex];
  const userAgent = generateRandomUAForPlatform(platform);

  Logger.d('Uber UA rotate edildi:', platform, '-', userAgent.substring(0, 60) + '...');

  await writeSelectedUberUserAgent(userAgent);
}

function generateRandomUAForPlatform(platform) {
  switch (platform) {
    case 'android': {
      const androidVersion = 10 + Math.floor(Math.random() * 5); // 10-14
      const chromeVersion = 115 + Math.floor(Math.random() * 11); // 115-125

      const devices = [
        'Pixel ' + (6 + Math.floor(Math.random() * 3)),
        'SM-S9' + (10 + Math.floor(Math.random() * 10)) + 'B',
        'SM-A' + (50 + Math.floor(Math.random() * 10)) + '5F',
        'CPH' + (2200 + Math.floor(Math.random() * 100)),
        'RMX' + (3600 + Math.floor(Math.random() * 100)),
        'M2101K' + (6 + Math.floor(Math.random() * 4)) + 'G',
        'V' + (2100 + Math.floor(Math.random() * 100))
      ];

      const device = devices[Math.floor(Math.random() * devices.length)];

      return (
        'Mozilla/5.0 (Linux; Android ' +
        androidVersion +
        '; ' +
        device +
        ') AppleWebKit/537.36 (KHTML, like Gecko) Chrome/' +
        chromeVersion +
        '.0.0.0 Mobile Safari/537.36'
      );
    }

    case 'iphone': {
      const iosMajor = 15 + Math.floor(Math.random() * 3); // 15-17
      const iosMinor = Math.floor(Math.random() * 7); // 0-6
      const safariVersion = iosMajor;

      return (
        'Mozilla/5.0 (iPhone; CPU iPhone OS ' +
        iosMajor +
        '_' +
        iosMinor +
        ' like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/' +
        safariVersion +
        '.0 Mobile/15E148 Safari/604.1'
      );
    }

    case 'windows_phone': {
      const uas = [
        'Mozilla/5.0 (Windows Phone 10.0; Android 6.0.1; Microsoft; Lumia 950) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Mobile Safari/537.36 Edge/15.15254',
        'Mozilla/5.0 (Windows Phone 8.1; ARM; Trident/7.0; Touch; rv:11.0; IEMobile/11.0; NOKIA; Lumia 635) like Gecko',
        'Mozilla/5.0 (Windows Phone 8.1; ARM; Trident/7.0; Touch; WebView/2.0; rv:11.0; IEMobile/11.0; NOKIA; Lumia 525) like Gecko',
        'Mozilla/5.0 (Windows Phone 10.0; Android 4.2.1; Microsoft; Lumia 640 LTE) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Mobile Safari/537.36 Edge/13.10586'
      ];

      return uas[Math.floor(Math.random() * uas.length)];
    }

    case 'tizen': {
      const versions = ['2.0', '2.3', '3.0', '4.0', '5.0'];
      const tizenVersion = versions[Math.floor(Math.random() * versions.length)];

      const uas = [
        'Mozilla/5.0 (Linux; U; Tizen ' +
        tizenVersion +
        '; en-us) AppleWebKit/537.1 (KHTML, like Gecko) Mobile TizenBrowser/' +
        tizenVersion,
        'Mozilla/5.0 (Linux; Tizen ' +
        tizenVersion +
        ') AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.0 Mobile Safari/537.36'
      ];

      return uas[Math.floor(Math.random() * uas.length)];
    }

    default:
      return generateRandomUAForPlatform('android');
  }
}

async function injectAntiDetection(tabId, userAgentOverride) {
  try {
    if (!chrome?.scripting?.executeScript) return;

    let userAgent = userAgentOverride;

    if (!userAgent) {
      userAgent = await readSelectedUberUserAgent();
    }

    if (!userAgent) {
      userAgent =
        'Mozilla/5.0 (Windows Phone 8.1; ARM; Trident/7.0; Touch; WebView/2.0; rv:11.0; IEMobile/11.0; NOKIA; Lumia 525) like Gecko';
    }

    Logger.d('Anti-detection için UA:', userAgent);

    const isIPhone = userAgent.includes('iPhone');
    const isAndroid = userAgent.includes('Android');
    const isMac = userAgent.includes('Macintosh');

    const platform = isIPhone ? 'iPhone' : isAndroid ? 'Linux armv8l' : isMac ? 'MacIntel' : 'Win32';
    const vendor = isIPhone || isMac ? 'Apple Computer, Inc.' : isAndroid ? 'Google Inc.' : '';
    const maxTouchPoints = isIPhone || isAndroid ? 5 : 1;

    await chrome.scripting
      .executeScript({
        target: {
          tabId
        },
        world: 'MAIN',
        args: [userAgent, platform, vendor, maxTouchPoints],
        func: (ua, plt, vnd, touchPoints) => {
          try {
            Object.defineProperty(navigator, 'webdriver', {
              get: () => false,
              configurable: true,
            });
          } catch {}

          try {
            if (!window.chrome) window.chrome = {};
            window.chrome.runtime = {
              connect() {},
              sendMessage() {},
            };
          } catch {}

          try {
            Object.defineProperty(navigator, 'languages', {
              get: () => ['tr-TR', 'tr', 'en-US', 'en'],
              configurable: true,
            });
          } catch {}

          try {
            Object.defineProperty(navigator, 'userAgent', {
              get: () => ua,
              configurable: true,
            });
          } catch {}

          try {
            Object.defineProperty(navigator, 'platform', {
              get: () => plt,
              configurable: true,
            });
          } catch {}

          try {
            Object.defineProperty(navigator, 'vendor', {
              get: () => vnd,
              configurable: true,
            });
          } catch {}

          try {
            Object.defineProperty(navigator, 'maxTouchPoints', {
              get: () => touchPoints,
              configurable: true,
            });
          } catch {}

          try {
            Object.defineProperty(navigator, 'plugins', {
              get: () => [],
              configurable: true,
            });
          } catch {}
        },
      })
      .catch(() => {
        return chrome.scripting.executeScript({
          target: {
            tabId
          },
          func: () => {
            try {
              Object.defineProperty(navigator, 'webdriver', {
                get: () => false
              });
            } catch {}
          },
        });
      });
  } catch (err) {
    Logger.e('Anti-detection inject hatası:', err);
  }
}

const SKEY = {
  CARTS: 'ekonomik_doy_carts',
  CART_SELECT: 'ekonomik_doy_selected_cart',
  YS_DEVICE_INFO: 'ekonomik_doy_ys_device_info',
  YS_ADJUST_AD_ID: 'ekonomik_doy_ys_adjust_ad_id',
  YS_WIDEVINE_ID: 'ekonomik_doy_ys_widevine_id',
  YS_EM_REQUEST_IDENTIFIER: 'ekonomik_doy_ys_em_request_id',
  UBER_PLATFORM: 'ekonomik_doy_uber_platform',
  UBER_USER_AGENT: 'ekonomik_doy_uber_user_agent'
};

const getLocal = async (key) => {
  const o = await chrome.storage.local.get(key); // key string de olur
  return o?. [key];
};

async function removeLocal(key) {
  await chrome.storage.local.remove(key);
  return true;
}

async function setLocal(obj) {
  await chrome.storage.local.set(obj);
  return true;
}
async function storageGet(key, defVal) {
  const v = await getLocal(key);
  return v ?? defVal;
}

async function storageSet(key, value) {
  await setLocal({
    [key]: value
  }).catch((e) => {
    Logger.e('storageSet local error:', e);
    throw new Error('storageSet failed');
  });
  return true;
}

async function storageSetMany(obj) {
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) {
    throw new Error('storageSetMany expects a plain object');
  }
  try {
    await setLocal(obj);
    return true;
  } catch (e) {
    Logger.e('storageSetMany local error:', e);
    throw new Error('storageSetMany failed');
  }
}

async function storageRemove(key) {
  return await removeLocal(key);
}

const readCarts = async () => await storageGet(SKEY.CARTS, []);
const writeCarts = async (arr) => (Array.isArray(arr) && arr.length) ?
  storageSet(SKEY.CARTS, arr) :
  storageRemove(SKEY.CARTS);

const readSelectedCart = async () => await storageGet(SKEY.CART_SELECT, '');
const writeSelectedCart = async (id) => id ?
  storageSet(SKEY.CART_SELECT, id) :
  storageRemove(SKEY.CART_SELECT);

const readYSDeviceInfo = async () => await storageGet(SKEY.YS_DEVICE_INFO, null);
const writeYSDeviceInfo = async (info) => info ?
  storageSet(SKEY.YS_DEVICE_INFO, info) :
  storageRemove(SKEY.YS_DEVICE_INFO);

const readYSAdjustAdId = async () => await storageGet(SKEY.YS_ADJUST_AD_ID, null);
const writeYSAdjustAdId = async (id) => id ?
  storageSet(SKEY.YS_ADJUST_AD_ID, id) :
  storageRemove(SKEY.YS_ADJUST_AD_ID);

const readYSWidevineId = async () => await storageGet(SKEY.YS_WIDEVINE_ID, null);
const writeYSWidevineId = async (id) => id ?
  storageSet(SKEY.YS_WIDEVINE_ID, id) :
  storageRemove(SKEY.YS_WIDEVINE_ID);

const readYSEmRequestIdentifier = async () => await storageGet(SKEY.YS_EM_REQUEST_IDENTIFIER, null);
const writeYSEmRequestIdentifier = async (id) => id ?
  storageSet(SKEY.YS_EM_REQUEST_IDENTIFIER, id) :
  storageRemove(SKEY.YS_EM_REQUEST_IDENTIFIER);

const readSelectedUberPlatform = async () => await storageGet(SKEY.UBER_PLATFORM, -1);
const writeSelectedUberPlatform = async (platform) => platform ?
  storageSet(SKEY.UBER_PLATFORM, platform) :
  storageRemove(SKEY.UBER_PLATFORM);

const readSelectedUberUserAgent = async () => await storageGet(SKEY.UBER_USER_AGENT, '');
const writeSelectedUberUserAgent = async (ua) => ua ?
  storageSet(SKEY.UBER_USER_AGENT, ua) :
  storageRemove(SKEY.UBER_USER_AGENT);